import flet as ft

def main(page: ft.Page):
    page.title = "Test"
    page.add(ft.Text("Привет, Flet работает!"))

ft.app(target=main)