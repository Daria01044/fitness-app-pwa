"""
Патч PWA после flet build web.
Использование:
    python patch_web.py
или:
    python patch_web.py --build   (сначала flet build web, потом патч)
"""
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent.resolve()
WEB = ROOT / "build" / "web"

PYTHON_WORKER = """\
importScripts("https://cdn.jsdelivr.net/pyodide/v0.27.2/full/pyodide.js");

self.pythonModuleName = null;
self.initialized = false;
self.flet_js = {};
self._receiveCallback = null;

self.jsConnect = async function (receiveCallback) {
    console.log("WORKER jsConnect called");
    self._receiveCallback = receiveCallback;
    self.postMessage("initialized");
    return true;
};

self.jsSend = function (data) {
    self.postMessage(data);
};

self.receiveCallback = (message) => {
    self.postMessage(message);
};

self.initPyodide = async function () {
    self.pyodide = await loadPyodide();

    self.flet_js = {
        documentUrl: self.documentUrl,
        start_connection: self.jsConnect,
        send: self.jsSend,
        receiveCallback: self.receiveCallback,
    };
    self.pyodide.registerJsModule("flet_js", self.flet_js);

    await self.pyodide.runPythonAsync(`
    import sys, runpy, traceback
    from pyodide.http import pyfetch
    sys.path.append("__pypackages__")
    sys.path.append("__pypackages__/lib")
    response = await pyfetch("assets/app/app.zip")
    await response.unpack_archive()
    try:
        runpy.run_module("${self.pythonModuleName}", run_name="__main__")
    except BaseException:
        traceback.print_exc()
  `);
};

self.onmessage = async (event) => {
    if (!self.initialized) {
        self.initialized = true;
        self.documentUrl = event.data.documentUrl;
        self.pythonModuleName = event.data.pythonModuleName;
        await self.initPyodide();
    } else {
        if (self._receiveCallback) {
            self._receiveCallback(event.data);
        }
    }
};
"""

PYTHON_JS = """\
const pythonWorker = new Worker("python-worker.js");

let _onPythonInitialized = null;
let pythonInitialized = new Promise((onSuccess) => _onPythonInitialized = onSuccess);
let _onReceivedCallback = null;

pythonWorker.onmessage = (event) => {
    if (event.data == "initialized") {
        _onPythonInitialized();
    } else {
        if (_onReceivedCallback) {
            _onReceivedCallback(event.data);
        }
    }
};

documentUrl = document.URL;

pythonWorker.postMessage({ documentUrl, pythonModuleName });

async function jsConnect(receiveCallback) {
    _onReceivedCallback = receiveCallback;
    await pythonInitialized;
    return true;
}

async function jsSend(data) {
    pythonWorker.postMessage(data);
}

var flet_js = {
    start_connection: jsConnect,
    send: jsSend,
};
"""


def patch_worker():
    p = WEB / "python-worker.js"
    p.write_text(PYTHON_WORKER, encoding="utf-8")
    print(f"[OK] patched {p}")


def patch_js():
    p = WEB / "python.js"
    p.write_text(PYTHON_JS, encoding="utf-8")
    print(f"[OK] patched {p}")


def copy_app_zip():
    src = ROOT / "build" / "flutter" / "app" / "app.zip"
    dst_dir = WEB / "assets" / "app"
    if not src.exists():
        print(f"[SKIP] {src} not found")
        return
    dst_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst_dir / "app.zip")
    print(f"[OK] copied app.zip ({src.stat().st_size} bytes) -> {dst_dir}")


def run_build():
    print("[BUILD] flet build web ...")
    scripts = Path(sys.executable).parent / "Scripts" / "flet.exe"
    if not scripts.exists():
        scripts = shutil.which("flet")
    if not scripts:
        print("[ERROR] flet.exe не найден")
        sys.exit(1)
    cmd = [str(scripts), "build", "web"]
    subprocess.run(cmd, check=True, cwd=ROOT)


def patch_index_html():
    p = WEB / "index.html"
    content = p.read_text(encoding="utf-8")

    content = content.replace(
        '<script src="flutter_bootstrap.js" async=""></script>',
        '<script src="flutter_bootstrap.js"></script>'
    )

    insert_after = '<script src="flutter_bootstrap.js"></script>'
    manual_script = '''
  <script>
    window.addEventListener("load", function () {
        setTimeout(function () {
            if (window._flutter && window._flutter.loader && typeof window._flutter.loader.load === "function") {
                if (!window._flutter.loader._scriptLoaded) {
                    console.log("MANUAL load() call");
                    window._flutter.loader.load({
                        onEntrypointLoaded: async function (engineInitializer) {
                            console.log("ENTRYPOINT LOADED!");
                            try {
                                const appRunner = await engineInitializer.initializeEngine({useColorEmoji: false});
                                console.log("ENGINE INITIALIZED");
                                await appRunner.runApp();
                                console.log("APP RUNNING");
                            } catch (e) {
                                console.error("FLUTTER ERROR:", e);
                            }
                        }
                    });
                }
            }
        }, 100);
    });
  </script>'''

    if insert_after in content and "MANUAL load() call" not in content:
        content = content.replace(insert_after, insert_after + manual_script, 1)

    p.write_text(content, encoding="utf-8")
    print(f"[OK] patched {p}")


def main():
    if "--build" in sys.argv:
        run_build()
    if not WEB.exists():
        print(f"[ERROR] {WEB} not found. Run: python patch_web.py --build")
        sys.exit(1)
    patch_worker()
    patch_js()
    copy_app_zip()
    patch_index_html()   # <-- ВОТ ЭТОЙ СТРОКИ НЕ ХВАТАЛО
    print("\n[DONE] PWA ready. Run:")
    print(f"  python -m http.server --directory {WEB} 8090")


if __name__ == "__main__":
    main()  