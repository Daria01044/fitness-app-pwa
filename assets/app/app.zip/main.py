import flet as ft
import json
import os
import httpx
import logging
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
from datetime import datetime, timedelta

import sys

# Универсальный префикс для assets (APK vs Web)
if sys.platform == "emscripten":  # web (Pyodide)
    ASSETS_PREFIX = ""
else:
    ASSETS_PREFIX = "assets/"

# === АДРЕС СЕРВЕРА ==127.0.0.1=
# Пока тестируем локально. Потом заменим на адрес Amvera.
SERVER_URL = "https://fitness-server-1wfz.onrender.com"

APP_DATA_DIR = os.getenv("FLET_APP_STORAGE_DATA", os.path.dirname(os.path.abspath(__file__)))
DATA_FILE = os.path.join(APP_DATA_DIR, "data.json")
USERS_FILE = os.path.join(APP_DATA_DIR, "users.json")

# === ЦВЕТА ===
BG = "#111214"
CARD = "#1a1c21"
CARD_SOFT = "#22242c"
BORDER = "#26282e"
TEXT = "#fbfaf7"
TEXT_MUTED = "#b8bcc7"
PRIMARY = "#8fc1ff"
PRIMARY_FG = "#0e1626"
BLUSH = "#f5c6d6"
MINT = "#b8e6d2"
PEACH = "#fad8b0"
DANGER = "#ff8a8a"

ADMIN_FIRST = "Ламия"
ADMIN_LAST = "кызы Бабаева"
PAYMENT_PHONE = "89307178896"
THEORY_ITEMS = [
    {
        "title": "Инвентарь",
        "subtitle": "Что нужно для тренировок",
        "video_url": "",
        "checklist": True,
        "links": [
            {"title": "Коврик (Wildberries)", "url": "https://www.wildberries.ru/catalog/790946862/detail.aspx?size=1170853217"},
            {"title": "Фитнес-резинки (Wildberries)", "url": "https://www.wildberries.ru/catalog/495654581/detail.aspx?size=689294650"},
            {"title": "Фитнес-резинки (Яндекс.Маркет) · промокод CULTNN52", "url": "https://market.yandex.ru/cc/Ayuswq"},
            {"title": "Скакалка (Wildberries)", "url": "https://www.wildberries.ru/catalog/110346745/detail.aspx?size=200443461"},
            {"title": "Гантели 2 кг (Wildberries)", "url": "https://www.wildberries.ru/catalog/369549197/detail.aspx?size=540479304"},
            {"title": "Гиря 4 кг (Wildberries)", "url": "https://www.wildberries.ru/catalog/729353344/detail.aspx?size=1030333670"},
        ],
        "note_after_checklist": "Со временем вы сами можете пополнять свой инвентарь и переходить на более тяжелые веса.",
        "note_after_links": "Это пример того, что нам нужно. Если найдёшь дешевле или на свой вкус — пожалуйста! 💜 Также мы будем стараться находить для вас промокоды.",
    },
    {
        "title": "АМРАП",
        "subtitle": "As Many Rounds As Possible",
         "video_url": "https://vkvideo.ru/video-242113399_456239039",
        "text": "«Как можно больше раундов за отведённое время». Ты выполняешь круг упражнений снова и снова, пока не выйдет время. Главное — не спешить, а делать качественно.\n\nПример: 10 минут. Круг: 10 приседаний + 5 отжиманий + 10 скручиваний. За 10 минут ты успеваешь сделать столько кругов, сколько сможешь. Сколько получилось — то и твой результат.",
    },
    {
        "title": "ЕМОМ",
        "subtitle": "Every Minute On the Minute",
         "video_url": "https://vkvideo.ru/video-242113399_456239039",
        "text": "«Каждую минуту — новое упражнение». Ты начинаешь минуту с упражнения, а остаток минуты отдыхаешь. Как только минута заканчивается — начинаешь следующее упражнение.\n\nПример: 10 минут. 1-я минута: 10 приседаний. 2-я минута: 8 отжиманий. 3-я минута: 12 скручиваний. И так далее. Отдых — это время, которое осталось до конца минуты.",
    },
    {
        "title": "Круговая тренировка",
        "subtitle": "Circuit Training",
         "video_url": "https://vkvideo.ru/video-242113399_456239039",
        "text": "Несколько упражнений выполняются подряд, одно за другим, без остановки. После полного круга — короткий отдых, и снова по кругу.\n\nПример: 3 круга. В каждом круге: 15 приседаний → 10 отжиманий → 20 секунд планки → 15 подъёмов таза. Между кругами отдых 1 минута.",
    },
    {
        "title": "Табата",
        "subtitle": "Высокоинтенсивный интервальный тренинг",
         "video_url": "https://vkvideo.ru/video-242113399_456239039",
        "text": "Это 4-минутные блоки: 20 секунд работаем на максимум, 10 секунд отдыхаем. Повторяем 8 раз — получается один круг Табаты.\n\nПример: 20 секунд приседаний с выпрыгиванием → 10 секунд отдыха → 20 секунд отжиманий → 10 секунд отдыха. И так 8 раз. Обычно делают 3–5 таких кругов.",
    },
]
QUOTES = [
    "Когда ты поймёшь, что хорошая физическая форма — это путь длиною в жизнь, тебя перестанет волновать, сколько времени на это потребуется.",
    "Ты не обязана быть идеальной. Ты обязана быть последовательной.",
    "Маленькие шаги каждый день — это большие перемены через год.",
    "Твоё тело слышит всё, что ты говоришь. Говори с ним с любовью.",
    "Начать — это уже половина успеха.",
    "Ты сильнее, чем думаешь. И красивее, чем веришь.",
    "Забота о себе — это не эгоизм. Это необходимость.",
    "Не сравнивай себя с другими. Сравнивай себя с собой вчерашней.",
    "Тренировка — это подарок, который ты делаешь себе.",
    "Дисциплина — это любовь к себе в действии.",
    "Каждый день — новая возможность стать лучше.",
    "Твоё тело — твой дом. Заботься о нём.",
    "Усталость проходит, а результат остаётся.",
    "Не жди понедельника. Начни сегодня.",
    "Ты можешь всё, но не всё сразу. Шаг за шагом.",
    "Сила — это не про мышцы. Это про дух.",
    "Ты — автор своей истории. Сделай её красивой.",
    "Лучшее время начать — сейчас.",
    "Твоя единственная конкуренция — это ты вчерашняя.",
    "Позаботься о себе сегодня — скажи себе спасибо завтра.",
    "Движение — это жизнь. Двигайся с радостью.",
    "Ты достойна заботы и внимания. Особенно от себя самой.",
    "Не бойся начинать с нуля. Это шанс сделать всё правильно.",
    "Твои усилия не напрасны. Даже если результат не виден сразу.",
    "Каждый раз, когда ты выбираешь себя — ты побеждаешь.",
    "Быть здоровой — это роскошь, которую ты можешь себе позволить.",
    "Ты не одна. Мы идём вместе.",
    "Сделай это для себя. Не для кого-то другого.",
    "Твоё тело — твой лучший проект.",
    "Всё получится. Просто не останавливайся.",
]

# --- Серверные функции ---

def server_get_inventory():
    try:
        r = httpx.get(f"{SERVER_URL}/inventory", timeout=10)
        if r.status_code == 200:
            return r.json()
    except Exception as e:
        print(f"[SERVER ERROR] get_inventory: {e}")
    return None


def server_save_inventory(data):
    try:
        r = httpx.post(f"{SERVER_URL}/inventory", json=data, timeout=10)
        return r.status_code == 200
    except Exception as e:
        print(f"[SERVER ERROR] save_inventory: {e}")
        return False
        
def get_recommendations(goals, frequency, activity, time_pref, hobbies):
    """Возвращает текст рекомендаций на основе ответов."""
    # Определяем тип рекомендаций по целям
    wants_slim = "Похудеть" in goals
    wants_muscle = "Рельеф" in goals or "мышц" in goals or "Набор" in goals
    wants_shape = "Подтянуть" in goals
    
    recs = []
    
    if wants_slim and not wants_muscle:
        recs.append({
            "title": "Если цель — похудеть",
            "items": [
                "Прогулки 4000–8000 шагов в день в темпе чуть выше спокойного",
                "5 тренировок в неделю",
                "Рассчитай свою норму КБЖУ в калькуляторе — там будут точные цифры.",
            ],
            "links": [
                {"title": "Записать вес →", "screen": "weight"},
                {"title": "Рассчитать КБЖУ →", "screen": "calculator"},
            ],
        })
    elif wants_muscle:
        recs.append({
            "title": "Если цель — рельеф и мышцы",
            "items": [
                "5 тренировок в неделю + растяжка",
                "Рассчитай свою норму КБЖУ в калькуляторе — там будут точные цифры.",
            ],
            "links": [
                {"title": "Записать вес →", "screen": "weight"},
                {"title": "Рассчитать КБЖУ →", "screen": "calculator"},
            ],
        })
    else:
        recs.append({
            "title": "Если цель — подтянуть фигуру",
            "items": [
                "Прогулки 4000–8000 шагов в день",
                "5 тренировок в неделю",
                "Рассчитай свою норму КБЖУ в калькуляторе — там будут точные цифры.",
            ],
            "links": [
                {"title": "Записать вес →", "screen": "weight"},
                {"title": "Рассчитать КБЖУ →", "screen": "calculator"},
            ],
        })
    
    # Совет про прогресс — вместо времени и активности
    recs.append({
        "title": "Отслеживай прогресс",
        "items": [
            "Снимай замеры каждый месяц в одно и то же время.",
            "Взвешивайся 2 раза в неделю: понедельник и четверг/пятница.",
            "Придерживайся своей суточной нормы КБЖУ.",            
            "Записывай всё в приложении — так ты увидишь динамику.",
        ],
        "links": [
            {"title": "Записать замеры →", "screen": "measures"},
        ],
    })

    # Питание и КБЖУ
    recs.append({
        "title": "Питание и КБЖУ",
        "items": [
            "Белок: мясо, курица, рыба, творог, яйца.",
            "Углеводы: макароны твёрдых сортов, гречка, овсянка, рис, картофель, бананы.",
            "Жиры: рыбий жир, авокадо, оливковое масло, яйца, семечки, орехи.",
            "Со временем норму можно корректировать — если нет результата, пересмотри продукты.",
        ],
        "links": [
            {"title": "Открыть дневник питания →", "screen": "calculator"},
        ],
    })
    
    return recs

def server_get_data():
    """Получает data.json с сервера."""
    try:
        r = httpx.get(f"{SERVER_URL}/data", timeout=10)
        print(f"[DEBUG] server_get_data: статус {r.status_code}")
        if r.status_code == 200:
            return r.json()
    except Exception as e:
        print(f"[SERVER ERROR] get_data: {e}")
        import traceback
        traceback.print_exc()
    return None


def server_get_users():
    """Получает users.json с сервера."""
    try:
        r = httpx.get(f"{SERVER_URL}/users", timeout=10)
        if r.status_code == 200:
            return r.json()
    except Exception as e:
        print(f"[SERVER ERROR] get_users: {e}")
    return None


def server_save_users(users_data):
    """Отправляет users.json на сервер."""
    try:
        r = httpx.post(f"{SERVER_URL}/users", json=users_data, timeout=10)
        return r.status_code == 200
    except Exception as e:
        print(f"[SERVER ERROR] save_users: {e}")
        return False


def server_register_user(first_name, last_name):
    """Регистрирует пользователя на сервере."""
    try:
        r = httpx.post(
            f"{SERVER_URL}/user/register",
            json={"id": 0, "first_name": first_name, "last_name": last_name,
                  "start_date": "", "last_payment_date": "", "payment_due_date": ""},
            timeout=10,
        )
        if r.status_code == 200:
            return r.json().get("user")
    except Exception as e:
        print(f"[SERVER ERROR] register: {e}")
    return None


def server_update_user(user):
    """Обновляет данные пользователя на сервере."""
    try:
        r = httpx.post(f"{SERVER_URL}/user/update", json=user, timeout=10)
        return r.status_code == 200
    except Exception as e:
        print(f"[SERVER ERROR] update_user: {e}")
        return False

def server_get_exercises():
    """Получает exercises.json с сервера."""
    try:
        r = httpx.get(f"{SERVER_URL}/exercises", timeout=10)
        if r.status_code == 200:
            return r.json()
    except Exception as e:
        print(f"[SERVER ERROR] get_exercises: {e}")
    return None


def server_save_exercises(data):
    """Отправляет exercises.json на сервер."""
    try:
        r = httpx.post(f"{SERVER_URL}/exercises", json=data, timeout=10)
        return r.status_code == 200
    except Exception as e:
        print(f"[SERVER ERROR] save_exercises: {e}")
        return False

def server_upload_exercise_video(exercise_key, file_path, file_name):
    try:
        with open(file_path, "rb") as f:
            files = {"file": (file_name, f, "video/mp4")}
            r = httpx.post(
                f"{SERVER_URL}/upload/exercise_video?exercise_key={exercise_key}",
                files=files,
                timeout=120,
            )
        if r.status_code == 200:
            return r.json().get("path", "")
    except Exception as e:
        print(f"[SERVER ERROR] upload_exercise_video: {e}")
    return None
        
def server_save_workout(block_id, number, text, video_url="", audio_url=""):
    """Сохраняет тренировку на сервере."""
    try:
        r = httpx.post(
            f"{SERVER_URL}/workout/save",
            json={"block_id": block_id, "number": number, "text": text, "video_url": video_url, "audio_url": audio_url},
            timeout=10,
        )
        if r.status_code == 200:
            return r.json()
    except Exception as e:
        print(f"[SERVER ERROR] save_workout: {e}")
    return None

def server_save_bonus_workout(bonus_id, title, text, video_url, audio_url):
    try:
        r = httpx.post(
            f"{SERVER_URL}/bonus/save",
            json={
                "id": bonus_id,
                "title": title,
                "text": text,
                "video_url": video_url,
                "audio_url": audio_url,
            },
            timeout=10,
        )
        return r.status_code == 200
    except Exception as e:
        print(f"[SERVER ERROR] save_bonus_workout: {e}")
        return False

def server_delete_bonus_workout(bonus_id):
    try:
        r = httpx.post(
            f"{SERVER_URL}/bonus/delete",
            json={"id": bonus_id},
            timeout=10,
        )
        return r.status_code == 200
    except Exception as e:
        print(f"[SERVER ERROR] delete_bonus_workout: {e}")
        return False

def server_delete_workout(block_id, number):
    """Удаляет тренировку с сервера."""
    try:
        r = httpx.post(
            f"{SERVER_URL}/workout/delete",
            json={"block_id": block_id, "number": number},
            timeout=10,
        )
        return r.status_code == 200
    except Exception as e:
        print(f"[SERVER ERROR] delete_workout: {e}")
        return False
        
def server_add_block():
    """Создаёт новый блок на сервере."""
    try:
        r = httpx.post(f"{SERVER_URL}/block/add", timeout=10)
        if r.status_code == 200:
            return r.json().get("block")
    except Exception as e:
        print(f"[SERVER ERROR] add_block: {e}")
    return None
    
def server_delete_block(block_id):
    """Удаляет блок на сервере."""
    try:
        r = httpx.post(
            f"{SERVER_URL}/block/delete",
            json={"block_id": block_id},
            timeout=10,
        )
        return r.status_code == 200
    except Exception as e:
        print(f"[SERVER ERROR] delete_block: {e}")
        return False

def server_add_exercise(name, video_url):
    """Добавляет упражнение на сервер."""
    try:
        r = httpx.post(
            f"{SERVER_URL}/exercise/add",
            json={"name": name, "video_url": video_url},
            timeout=10,
        )
        return r.status_code == 200
    except Exception as e:
        print(f"[SERVER ERROR] add_exercise: {e}")
        return False


def server_delete_exercise(key):
    """Удаляет упражнение на сервере."""
    try:
        r = httpx.post(
            f"{SERVER_URL}/exercise/delete",
            json={"key": key},
            timeout=10,
        )
        return r.status_code == 200
    except Exception as e:
        print(f"[SERVER ERROR] delete_exercise: {e}")
        return False

def server_rename_exercise(key, new_name):
    """Переименовывает упражнение на сервере."""
    try:
        r = httpx.post(
            f"{SERVER_URL}/exercise/rename",
            json={"key": key, "new_name": new_name},
            timeout=10,
        )
        return r.status_code == 200
    except Exception as e:
        print(f"[SERVER ERROR] rename_exercise: {e}")
        return False
 
def months_since(start_date_str):
    """Сколько полных месяцев прошло с даты начала."""
    try:
        start = datetime.strptime(start_date_str, "%Y-%m-%d")
    except Exception:
        return 0
    
    today = datetime.now()
    months = (today.year - start.year) * 12 + (today.month - start.month)
    
    if today.day < start.day:
        months -= 1
    
    return max(0, months)
 
def server_update_intro(text, video_url, audio_url, title):
    """Обновляет вводную тренировку на сервере."""
    try:
        r = httpx.post(
            f"{SERVER_URL}/intro/update",
            json={"text": text, "video_url": video_url, "audio_url": audio_url, "title": title},
            timeout=10,
        )
        return r.status_code == 200
    except Exception as e:
        print(f"[SERVER ERROR] update_intro: {e}")
        return False

def server_get_foods():
    try:
        r = httpx.get(f"{SERVER_URL}/foods", timeout=10)
        if r.status_code == 200:
            return r.json()
    except Exception as e:
        print(f"[SERVER ERROR] get_foods: {e}")
    return None

def server_set_current_block(block_id):
    try:
        r = httpx.post(
            f"{SERVER_URL}/block/set_current",
            json={"block_id": block_id},
            timeout=10,
        )
        return r.status_code == 200
    except Exception as e:
        print(f"[SERVER ERROR] set_current_block: {e}")
        return False

def today_str():
    return datetime.now().strftime("%Y-%m-%d")
    
    
def main(page: ft.Page):
    page.title = "5 КРУГОВ"
    page.bgcolor = BG
    page.scroll = ft.ScrollMode.AUTO
    page.padding = 0  

    comment_picker = ft.FilePicker()
    page.overlay.append(comment_picker)
    
    
    # Загружаем данные с сервера
    data = server_get_data()
    if data is None:
        # Если сервер недоступен — пустые данные
        data = {"intro_workout": {}, "blocks": []}
        print("[INFO] Сервер недоступен, данные пустые")
    intro = data.get("intro_workout", {})
    blocks = data.get("blocks", [])

    users_data = server_get_users()
    if users_data is None:
        users_data = {"users": [], "current_user": None}
        print("[INFO] Сервер недоступен, пользователи пустые")
    users = users_data["users"]

    exercises_data = server_get_exercises()
    if exercises_data is None:
        exercises_data = {"exercises": {}}
        print("[INFO] Не удалось загрузить упражнения")
    exercises = exercises_data.get("exercises", {})

    inventory_data = server_get_inventory()
    if inventory_data is None:
        inventory_data = {"items": [], "note": ""}
    inventory_items = inventory_data.get("items", [])
    
    state = {"tab": "home", "user": None, "screen": "auto", "is_admin": False, "logged_in": False}

    def on_swipe(e):
        """Свайп вправо = кнопка Назад."""
        # Проверяем, что это именно свайп вправо
        if e.primary_velocity and e.primary_velocity > 200:
            back_to = state.get("back_to", "")
            if back_to:
                target = back_to
                state["back_to"] = ""
                if target.startswith("tab:"):
                    state["screen"] = "auto"
                    state["tab"] = target.replace("tab:", "")
                else:
                    state["screen"] = target
                render()
            else:
                # Если некуда возвращаться — ничего не делаем
                # (можно отправить на Главную — см. ниже)
                pass

    content_area = ft.Column(spacing=0, expand=True, scroll=ft.ScrollMode.AUTO)
    nav_area = ft.Container()

    foods_data = server_get_foods()
    if foods_data is None:
        foods_data = {"foods": []}
    foods_list = foods_data.get("foods", [])

    def card_container(content, padding=20):
        return ft.Container(
            content=content, padding=padding, border_radius=18,
            bgcolor=CARD, border=ft.border.all(1, BORDER),
        )

    def back_button(default_screen="auto", default_tab=None):
        """Кнопка «Назад». Ведёт туда, откуда пришли, или на default."""
        def go_back(e):
            back_to = state.get("back_to", "")
            if back_to:
                # Возвращаемся туда, откуда пришли
                target = back_to
                state["back_to"] = ""
                if target.startswith("tab:"):
                    state["screen"] = "auto"
                    state["tab"] = target.replace("tab:", "")
                else:
                    state["screen"] = target
            else:
                # По умолчанию
                state["screen"] = default_screen
                if default_tab:
                    state["tab"] = default_tab
            render()
        
        return ft.Container(
            content=ft.Row([
                ft.IconButton(
                    ft.Icons.ARROW_BACK,
                    icon_color=TEXT,
                    icon_size=22,
                    on_click=go_back,
                ),
                ft.Text("Назад", size=15, color=TEXT_MUTED),
            ], spacing=0),
            padding=ft.padding.only(left=10, right=20, top=10, bottom=5),
        )

    def find_user(fn, ln):
        for u in users:
            if u["first_name"].lower() == fn.lower() and u["last_name"].lower() == ln.lower():
                return u
        return None

    def get_block(block_id):
        for b in blocks:
            if b["id"] == block_id:
                return b
        return None

    def is_week_missed(user):
        if user.get("level") != "advanced":
            return False
        last = user.get("last_done_date", "")
        if not last:
            last = user.get("start_date", "")
        if not last:
            return False
        try:
            last_date = datetime.strptime(last, "%Y-%m-%d").date()
        except Exception:
            return False
        today = datetime.now().date()
        days = (today - last_date).days
        print(f"[DEBUG is_week_missed] last={last}, days={days}, result={days >= 7}")
        return days >= 7

    def get_missed_advanced(user):
        """Пропущенные для продвинутых: все невыполненные тренировки
        по дням недели с start_date по сегодня."""
        import datetime as dt

        start_str = user.get("start_date", "")
        if not start_str:
            return []

        try:
            start = dt.datetime.strptime(start_str, "%Y-%m-%d").date()
        except Exception:
            return []

        today = dt.date.today()
        done_map = user.get("done", {})

        # Текущий блок
        current_block_id = get_current_block_id()
        block = get_block(current_block_id)
        if not block:
            return []

        workouts = block.get("workouts", [])

        # Словарь: день недели -> тренировка
        day_names = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        day_map = {}
        for w in workouts:
            d = w.get("day", "")
            if d:
                day_map[d] = w

        missed = []
        seen = set()
        current = start
        while current < today:
            day_name = day_names[current.weekday()]
            w = day_map.get(day_name)
            if w:
                wid = str(w["id"])
                if not done_map.get(wid, False):
                    missed.append({
                        "block_id": current_block_id,
                        "block_title": block.get("title", ""),
                        "workout": w,
                        "workout_id": wid,
                        "workout_number": w.get("number", 0),
                        "day": day_name,
                        "date": current.strftime("%Y-%m-%d"),
                    })
            current += dt.timedelta(days=1)

        # Убираем дубликаты (одна тренировка за разные недели)
        seen = set()
        unique = []
        for m in missed:
            if m["workout_id"] not in seen:
                seen.add(m["workout_id"])
                unique.append(m)

        return unique

    def get_missed_workouts(user):
        level = user.get("level", "beginner")

        if level == "advanced":
            return get_missed_advanced(user)
        current_block_id = user.get("current_block", 1)
        current_index = user.get("current_index", 0)
        done_map = user.get("done", {})

        missed = []

        all_blocks = sorted(data.get("blocks", []), key=lambda b: b["id"])
        for b in all_blocks:
            b_id = b["id"]
            if b_id > current_block_id:
                break

            # Продвинутые — только advanced-блоки
            if level == "advanced" and b.get("level") != "advanced":
                continue
            # Начинающие — только beginner-блоки
            if level == "beginner" and b.get("level") != "beginner":
                continue

            workouts = b.get("workouts", [])

            for idx, w in enumerate(workouts):
                wid = str(w["id"])

                # Определяем, "дошли ли" до этой тренировки
                if b_id < current_block_id:
                    passed = True
                elif b_id == current_block_id:
                    passed = idx < current_index
                else:
                    passed = False

                if not passed:
                    continue

                if user.get("skipped", {}).get(wid, False):
                    missed.append({
                        "block_id": b_id,
                        "block_title": b["title"],
                        "workout": w,
                        "workout_id": wid,
                        "workout_number": w.get("number", idx + 1),
                        "day": w.get("day", ""),
                    })

        # Сортируем: по блоку, потом по номеру тренировки
        missed.sort(key=lambda m: (m["block_id"], m["workout_number"]))
        return missed

    def get_current_block_id():
        # Ищем блок с флагом is_current
        for b in data.get("blocks", []):
            if b.get("is_current"):
                return b["id"]
        # Fallback — максимальный id
        all_blocks = data.get("blocks", [])
        if not all_blocks:
            return 1
        return max(b["id"] for b in all_blocks)


    def get_block_for_level(level):
        if level == "beginner":
            beginner_blocks = [b for b in data.get("blocks", []) if b.get("level") == "beginner"]
            if beginner_blocks:
                return min(b["id"] for b in beginner_blocks)
            return 1
        else:  # advanced
            return get_current_block_id()


    def get_next_block_id(current_id, level):
        """
        Следующий блок для пользователя:
        - beginner: идёт по порядку 1..8 (beginner-блоки), потом → текущий.
        - advanced: если появился блок новее — переходим в него, иначе остаёмся.
        """
        all_blocks = sorted(data.get("blocks", []), key=lambda b: b["id"])
        ids = [b["id"] for b in all_blocks]

        if not ids:
            return current_id

        if level == "beginner":
            # Следующий beginner-блок после текущего
            beginner_ids = sorted(b["id"] for b in all_blocks if b.get("level") == "beginner")
            for bid in beginner_ids:
                if bid > current_id:
                    return bid
            # Beginner-блоки кончились → в текущий
            return get_current_block_id()
        else:
            # advanced: если есть блок новее текущего — идём туда
            newer = [bid for bid in ids if bid > current_id]
            if newer:
                return max(newer)
            return current_id


    def is_access_active(user):
        if not user.get("is_active", True):
            return False
        due = user.get("payment_due_date")
        if due is None:
            return True
        try:
            due_date = datetime.strptime(due, "%Y-%m-%d")
        except ValueError:
            return True
        return datetime.now() <= due_date


    def trained_today(user):
        """Проверяем, отмечала ли сегодня что-то."""
        today = today_str()
        marks = user.get("done_dates", {})
        return any(v == today for v in marks.values())

    def nav_button(label, icon_name, tab_key):
        is_active = state["tab"] == tab_key
        color = PRIMARY if is_active else TEXT_MUTED
        return ft.Container(
            content=ft.Column([
                ft.Icon(icon_name, color=color, size=20),
                ft.Text(
                    label, size=9, color=color,
                    weight=ft.FontWeight.BOLD if is_active else ft.FontWeight.NORMAL,
                    text_align=ft.TextAlign.CENTER,
                    no_wrap=True,
                ),
            ], spacing=1, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
            padding=ft.padding.symmetric(vertical=6, horizontal=4),
            border_radius=12, bgcolor=CARD_SOFT if is_active else None,
            on_click=lambda e: switch_tab(tab_key),
            expand=True,
        )

    def switch_tab(tab_key):
        state["tab"] = tab_key
        state["screen"] = "auto"
        state["from_block"] = False
        state["just_done"] = None
        render()

    # ---------- Оплата ----------

    def payment_banner(user):
        """Баннер «Доступ приостановлен»."""
        request = user.get("payment_request")
        status = request.get("status") if request else None

        if status == "pending":
            info_text = "Заявка отправлена. Доступ откроется после подтверждения тренером."
            button = None
        else:
            info_text = (
                "Доступ временно приостановлен. Если вы планируете оставаться с нами дальше, "
                f"прошу сегодня осуществить перевод по номеру {PAYMENT_PHONE}. "
                "Кто решил закончить — спасибо, что были с нами 💜"
            )

            def on_paid(e):
                user["payment_request"] = {
                    "requested_at": today_str(),
                    "status": "pending",
                }
                server_save_users(users_data)
                render()

            button = ft.Button(
                content=ft.Text("Я оплатила", size=16, weight=ft.FontWeight.BOLD),
                on_click=on_paid,
                style=ft.ButtonStyle(bgcolor=PRIMARY, color=PRIMARY_FG, shape=ft.RoundedRectangleBorder(radius=12), padding=ft.padding.symmetric(vertical=16)),
            )

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Icon(ft.Icons.LOCK_OUTLINE, color=BLUSH, size=36),
                    ft.Text("Доступ временно приостановлен", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Text(info_text, size=15, color=TEXT_MUTED),
                    ft.Container(height=10),
                    button if button else ft.Text("Ожидает подтверждения…", size=15, color=PRIMARY, weight=ft.FontWeight.BOLD),
                ], spacing=12, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=30,
                margin=ft.margin.symmetric(horizontal=20, vertical=20),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BLUSH),
            )
        )

    # ---------- Регистрация ----------

    def render_registration():
        content_area.controls.clear()
        fn_field = ft.TextField(label="Имя", width=300, bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT, label_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12)
        ln_field = ft.TextField(label="Фамилия", width=300, bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT, label_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12)

        async def on_start(e):
            fn = fn_field.value.strip()
            ln = ln_field.value.strip()
            if not fn or not ln:
                snack = ft.SnackBar(ft.Text("Заполните имя и фамилию"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return

            # Получаем ID устройства
            device_id = ""
            try:
                device_info = await page.get_device_info()
                if device_info:
                    device_id = device_info.fingerprint or ""
            except Exception as ex:
                print(f"[DEVICE INFO ERROR] {ex}")

            # Админ?
            if fn.lower() == ADMIN_FIRST.lower() and ln.lower() == ADMIN_LAST.lower():
                state["is_admin"] = True
                state["admin_section"] = "users"
                state["screen"] = "admin"
                state["user"] = {"first_name": ADMIN_FIRST, "last_name": ADMIN_LAST}
                render()
                return

            # Проверяем привязку устройства
            try:
                check_result = httpx.post(
                    f"{SERVER_URL}/user/check_device",
                    json={"first_name": fn, "last_name": ln, "device_id": device_id},
                    timeout=10,
                ).json()

                if check_result.get("status") == "blocked":
                    snack = ft.SnackBar(ft.Text("Этот аккаунт привязан к другому устройству. Обратитесь к тренеру."))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    return
            except Exception as ex:
                print(f"[CHECK DEVICE ERROR] {ex}")

            user = find_user(fn, ln)
            if user is None:
                now = datetime.now()
                user = {
                    "id": len(users) + 1,
                    "first_name": fn, "last_name": ln,
                    "device_id": device_id,   # ← сохраняем device_id
                    "level": None,
                    "intro_done": False,
                    "current_block": None,
                    "current_index": 0,
                    "done": {}, "comments": {},
                    "done_dates": {},
                    "start_date": now.strftime("%Y-%m-%d"),
                    "last_payment_date": now.strftime("%Y-%m-%d"),
                    "payment_due_date": (now + timedelta(days=7)).strftime("%Y-%m-%d"),
                    "is_active": True,
                    "payment_request": None,
                }
                users.append(user)
                users_data["users"] = users
                server_save_users(users_data)
            users_data["current_user"] = user["id"]
            server_save_users(users_data)
            state["user"] = user
            state["logged_in"] = True
            state["tab"] = "home"

            if user.get("intro_done"):
                state["screen"] = "auto"
            else:
                state["screen"] = "welcome"

            render()

        start_button = ft.Button(
            content=ft.Text("Начать", size=16, weight=ft.FontWeight.BOLD),
            on_click=on_start,
            style=ft.ButtonStyle(bgcolor=PRIMARY, color=PRIMARY_FG, shape=ft.RoundedRectangleBorder(radius=12), padding=ft.padding.symmetric(vertical=16, horizontal=32)),
        )
        def reset_all(e):
            """ВРЕМЕННАЯ КНОПКА ДЛЯ ТЕСТА. Удалить перед релизом."""
            users_data["users"] = []
            users_data["current_user"] = None
            server_save_users(users_data)
            state["user"] = None
            state["is_admin"] = False
            state["logged_in"] = False
            state["tab"] = "home"
            state["screen"] = "auto"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("Добро пожаловать!", size=28, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Text("Введи имя и фамилию, чтобы начать", size=16, color=TEXT_MUTED),
                    ft.Container(height=20),
                    fn_field, ln_field,
                    ft.Container(height=10),
                    start_button,
                    ft.Container(height=30),
                    ft.TextButton(
                        content=ft.Text("⚠ Сбросить всё (тест)", size=13, color=BLUSH),
                        on_click=reset_all,
                    ),
                ], spacing=15, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=30,
            )
        )
    def render_welcome(user):
        content_area.controls.clear()
        state["screen"] = "welcome"   # ← ДОБАВИТЬ

        def on_next(e):
            state["screen"] = "onboarding"
            render()

        # Карточка "Как всё устроено"
        plan_card = ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Icon(ft.Icons.AUTO_AWESOME, color=PRIMARY, size=22),
                    ft.Text("Как всё устроено", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                ], spacing=8),
                ft.Container(height=10),
                ft.Text(
                    "Первая неделя — бесплатно",
                    size=16, weight=ft.FontWeight.BOLD, color=PRIMARY,
                ),
                ft.Container(height=6),
                ft.Text(
                    "Пока приобретаешь инвентарь — уже можешь тренироваться! ",
                    size=14, color=TEXT_MUTED,
                ),
                ft.Container(height=8),
                ft.Text(
                    "Далее — 1000 ₽ в месяц.",
                    size=15, color=TEXT, weight=ft.FontWeight.BOLD,
                ),
                ft.Divider(color=BORDER),
                ft.Container(height=8),
                ft.Text("Что входит в стоимость:", size=15, weight=ft.FontWeight.BOLD, color=TEXT),
                ft.Container(height=8),
                ft.Row([
                    ft.Text("🏋️", size=18),
                    ft.Column([
                        ft.Text("5 тренировок в неделю", size=14, color=TEXT, weight=ft.FontWeight.BOLD),
                        ft.Text("Силовые · кардио · интервальные · функциональные · растяжка", size=12, color=TEXT_MUTED),
                    ], spacing=2, expand=True),
                ], spacing=10),
                ft.Container(height=10),
                ft.Row([
                    ft.Icon(ft.Icons.CHAT_BUBBLE_OUTLINE, color=MINT, size=18),
                    ft.Text("Всегда на связи — тренер ответит на любые вопросы", size=13, color=TEXT_MUTED, expand=True),
                ], spacing=8),
                ft.Container(height=6),
                ft.Row([
                    ft.Icon(ft.Icons.SCHEDULE, color=MINT, size=18),
                    ft.Text("Занимайся в любое удобное время", size=13, color=TEXT_MUTED, expand=True),
                ], spacing=8),
            ]),
            padding=20,
            margin=ft.margin.symmetric(horizontal=20, vertical=8),
            border_radius=18,
            bgcolor=CARD,
            border=ft.border.all(1, BORDER),
        )

        next_button = ft.Button(
            content=ft.Text("Далее →", size=16, weight=ft.FontWeight.BOLD),
            on_click=on_next,
            style=ft.ButtonStyle(
                bgcolor=PRIMARY, color=PRIMARY_FG,
                shape=ft.RoundedRectangleBorder(radius=12),
                padding=ft.padding.symmetric(vertical=18, horizontal=24),
            ),
            width=340,
        )

        # --- Собираем контент ---
        content_column = ft.Column([
            ft.Container(height=30),
            ft.Text(
                f"Привет, {user['first_name']}!",
                size=28, weight=ft.FontWeight.BOLD, color=TEXT,
                text_align=ft.TextAlign.CENTER,
            ),
            ft.Container(height=6),
            ft.Text(
                "Рады видеть тебя в проекте 5 КРУГОВ.",
                size=17, color=PRIMARY, weight=ft.FontWeight.BOLD,
                text_align=ft.TextAlign.CENTER,
            ),
            ft.Container(height=10),
            ft.Text(
                "Занимайся дома, в своём ритме. 30 минут в день!",
                size=15, color=TEXT,
                text_align=ft.TextAlign.CENTER,
            ),
            ft.Container(height=20),
            plan_card,
            ft.Container(height=15),
            ft.Row([next_button], alignment=ft.MainAxisAlignment.CENTER),
            ft.Container(height=30),
        ], spacing=0, horizontal_alignment=ft.CrossAxisAlignment.CENTER)

        # Просто контент, без фона
        content_area.controls.append(
            ft.Container(content=content_column, expand=True)
        )
        
    def render_onboarding(user):
        content_area.controls.clear()

        content_area.controls.append(back_button("welcome"))

        def on_next(e):
            state["screen"] = "questions"
            render()

        # Заголовок + текст
        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Icon(ft.Icons.AUTO_AWESOME, color=PRIMARY, size=56),
                    ft.Text(
                        "Твоё пространство для тренировок",
                        size=26, weight=ft.FontWeight.BOLD, color=TEXT,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    ft.Container(height=8),
                    ft.Text(
                        "Приложение состоит из 6 разделов. "
                        "Давай коротко расскажем, что где находится.",
                        size=15, color=TEXT_MUTED,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ], spacing=8, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.padding.only(left=20, right=20, top=30, bottom=20),
            )
        )

        # Карточки разделов
        sections = [
            (ft.Icons.HOME_ROUNDED, "Главная",
             "Здесь ты видишь свой прогресс, рекомендации, пропущенные тренировки, рейтинг и дни до оплаты."),
            (ft.Icons.PLAY_CIRCLE_OUTLINE, "Тренировки",
             "Все твои тренировки, разбитые по блокам. Здесь же — текущая тренировка дня и разминка перед ней."),
            (ft.Icons.STAR_OUTLINE, "Бонус",
             "Дополнительные тренировки: растяжка, табата и необычные упражнения. Заходи, когда хочется чего-то особенного."),
            (ft.Icons.CHAT_BUBBLE_OUTLINE, "Чат",
             "Общайся с теми, кто тоже тренируется с нами. Поддерживай, делись успехами, задавай вопросы."),
            (ft.Icons.MENU_BOOK, "Теория",
             "Виды тренировок (АМРАП, ЕМОМ, круговая, Табата), их описание и список инвентаря со ссылками."),
            (ft.Icons.ACCOUNT_CIRCLE, "Профиль",
             "Твои замеры, вес, фото до/после, КБЖУ и дневник питания."),             
        ]

        for icon, title, text in sections:
            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Icon(icon, color=PRIMARY, size=26),
                            width=48, height=48, border_radius=24,
                            bgcolor=CARD_SOFT,
                            alignment=ft.alignment.center,
                        ),
                        ft.Column([
                            ft.Text(title, size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                            ft.Text(text, size=13, color=TEXT_MUTED),
                        ], spacing=4, expand=True),
                    ], spacing=14),
                    padding=16,
                    margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                )
            )

        # Финальный текст
        content_area.controls.append(
            ft.Container(
                content=ft.Text(
                    "Всё просто 💜 Занимайся в своём ритме — приложение подскажет, что делать.",
                    size=14, color=PRIMARY, weight=ft.FontWeight.BOLD,
                    text_align=ft.TextAlign.CENTER,
                ),
                padding=ft.padding.symmetric(horizontal=20, vertical=15),
                alignment=ft.alignment.center,
            )
        )

        # Кнопка
        next_button = ft.Button(
            content=ft.Text("Далее", size=16, weight=ft.FontWeight.BOLD),
            on_click=on_next,
            style=ft.ButtonStyle(
                bgcolor=PRIMARY, color=PRIMARY_FG,
                shape=ft.RoundedRectangleBorder(radius=12),
                padding=ft.padding.symmetric(vertical=18, horizontal=24),
            ),
            width=340,
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Row([next_button], alignment=ft.MainAxisAlignment.CENTER),
                padding=ft.padding.only(top=10, bottom=30),
            )
        )

    def render_recommendations(user):
        content_area.controls.clear()
        
        content_area.controls.append(back_button("auto", "home"))  

        def on_next(e):
            state["screen"] = "inventory"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.RECOMMEND, color=PRIMARY, size=56),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Row([
                        ft.Text(
                            "Твои рекомендации",
                            size=26, weight=ft.FontWeight.BOLD, color=TEXT,
                        ),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Row([
                        ft.Text(
                            "На основе твоих ответов мы подобрали советы.",
                            size=15, color=TEXT_MUTED,
                        ),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                ], spacing=8),
                padding=ft.padding.only(left=20, right=20, top=30, bottom=20),
            )
        )

        recs = get_recommendations(
            user.get("goals", []),
            user.get("frequency", ""),
            user.get("activity", ""),
            user.get("time_pref", ""),
            user.get("hobbies", ""),
        )

        for rec in recs:
            items_widgets = []
            for item in rec["items"]:
                items_widgets.append(
                    ft.Row([
                        ft.Icon(ft.Icons.CHECK_CIRCLE, color=PRIMARY, size=18),
                        ft.Text(item, size=14, color=TEXT, expand=True),
                    ], spacing=8)
                )

            # --- Ссылки на разделы ---
            links_widgets = []
            if rec.get("links"):
                links_widgets.append(ft.Container(height=10))
                for link in rec["links"]:
                    def make_open(target_screen):
                        def open_screen(e):
                            state["back_to"] = "recommendations"
                            state["screen"] = target_screen
                            render()
                        return open_screen

                    links_widgets.append(
                        ft.Button(
                            content=ft.Text(link["title"], size=14, weight=ft.FontWeight.BOLD),
                            on_click=make_open(link["screen"]),
                            style=ft.ButtonStyle(
                                bgcolor=PRIMARY, color=PRIMARY_FG,
                                shape=ft.RoundedRectangleBorder(radius=12),
                                padding=ft.padding.symmetric(vertical=12, horizontal=20),
                            ),
                        )
                    )

            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text(rec["title"], size=16, weight=ft.FontWeight.BOLD, color=PRIMARY),
                        ft.Container(height=8),
                    ] + items_widgets + links_widgets, spacing=4),
                    padding=16,
                    margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=16, bgcolor=CARD, border=ft.border.all(1, BORDER),
                )
            )

        # --- Подсказка про профиль ---
        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.INFO_OUTLINE, color=PRIMARY, size=18),
                    ft.Text(
                        "Контролировать свои замеры, вес и питание ты можешь в профиле — "
                        "иконка в правом верхнем углу на Главной.",
                        size=13, color=TEXT_MUTED, expand=True,
                    ),
                ], spacing=8),
                padding=ft.padding.symmetric(horizontal=20, vertical=15),
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=14, bgcolor=CARD_SOFT, border=ft.border.all(1, BORDER),
            )
        )

    def render_questions(user):
        content_area.controls.clear()
        
        content_area.controls.append(back_button("onboarding"))        

        # --- Заголовок ---
        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.QUESTION_ANSWER, color=PRIMARY, size=56),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Text(
                        "Расскажи о себе",
                        size=26, weight=ft.FontWeight.BOLD, color=TEXT,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    ft.Text(
                        "Ответь на 5 вопросов — персональные рекомендации появятся на Главной",
                        size=15, color=TEXT_MUTED,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ], spacing=8, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.padding.only(left=20, right=20, top=30, bottom=20),
            )
        )

        # --- Вопрос 1: Цели (мультивыбор) ---
        goals_list = ["Похудеть", "Подтянуть фигуру", "Рельеф", "Набор мышечной массы"]
        selected_goals = state.setdefault("q_goals", [])

        def toggle_goal(g):
            if g in selected_goals:
                selected_goals.remove(g)
            else:
                selected_goals.append(g)
            render()

        goal_buttons = []
        for g in goals_list:
            is_active = g in selected_goals
            goal_buttons.append(
                ft.Button(
                    content=ft.Text(g, size=13, weight=ft.FontWeight.BOLD),
                    on_click=lambda e, goal=g: toggle_goal(goal),
                    style=ft.ButtonStyle(
                        bgcolor=PRIMARY if is_active else CARD_SOFT,
                        color=PRIMARY_FG if is_active else TEXT,
                        shape=ft.RoundedRectangleBorder(radius=10),
                        padding=ft.padding.symmetric(vertical=12, horizontal=14),
                    ),
                )
            )

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("1. Какие у тебя цели?", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Text("Можно выбрать несколько", size=12, color=TEXT_MUTED),
                    ft.Container(height=8),
                    ft.Row(goal_buttons, spacing=8, wrap=True),
                ], spacing=4),
                padding=16,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=16, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )

        # --- Вопрос 2: Частота ---
        freq_list = ["2 раза", "3 раза", "3–5 раз", "5 раз"]
        selected_freq = state.get("q_freq", "")

        def select_freq(f):
            state["q_freq"] = f
            render()

        freq_buttons = []
        for f in freq_list:
            is_active = selected_freq == f
            freq_buttons.append(
                ft.Button(
                    content=ft.Text(f, size=13, weight=ft.FontWeight.BOLD),
                    on_click=lambda e, fr=f: select_freq(fr),
                    style=ft.ButtonStyle(
                        bgcolor=PRIMARY if is_active else CARD_SOFT,
                        color=PRIMARY_FG if is_active else TEXT,
                        shape=ft.RoundedRectangleBorder(radius=10),
                        padding=ft.padding.symmetric(vertical=12, horizontal=14),
                    ),
                )
            )

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("2. Сколько раз в неделю планируешь тренироваться?", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Container(height=8),
                    ft.Row(freq_buttons, spacing=8, wrap=True),
                ], spacing=4),
                padding=16,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=16, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )

        # --- Вопрос 3: Активность ---
        activity_list = [
            "Высокий — много двигаюсь",
            "Средний — 50 на 50",
            "Низкий — малоподвижный образ жизни",
        ]
        selected_activity = state.get("q_activity", "")

        def select_activity(a):
            state["q_activity"] = a
            render()

        activity_buttons = []
        for a in activity_list:
            is_active = selected_activity == a
            activity_buttons.append(
                ft.Button(
                    content=ft.Text(a, size=12, weight=ft.FontWeight.BOLD),
                    on_click=lambda e, act=a: select_activity(act),
                    style=ft.ButtonStyle(
                        bgcolor=PRIMARY if is_active else CARD_SOFT,
                        color=PRIMARY_FG if is_active else TEXT,
                        shape=ft.RoundedRectangleBorder(radius=10),
                        padding=ft.padding.symmetric(vertical=12, horizontal=12),
                    ),
                )
            )

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("3. Какой уровень активности в течение дня?", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Container(height=8),
                    ft.Column(activity_buttons, spacing=6),
                ], spacing=4),
                padding=16,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=16, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )

        # --- Вопрос 4: Время ---
        time_list = ["С 7 до 12", "С 12 до 18", "С 18 до 21"]
        selected_time = state.get("q_time", "")

        def select_time(t):
            state["q_time"] = t
            render()

        time_buttons = []
        for t in time_list:
            is_active = selected_time == t
            time_buttons.append(
                ft.Button(
                    content=ft.Text(t, size=13, weight=ft.FontWeight.BOLD),
                    on_click=lambda e, tm=t: select_time(tm),
                    style=ft.ButtonStyle(
                        bgcolor=PRIMARY if is_active else CARD_SOFT,
                        color=PRIMARY_FG if is_active else TEXT,
                        shape=ft.RoundedRectangleBorder(radius=10),
                        padding=ft.padding.symmetric(vertical=12, horizontal=14),
                    ),
                )
            )

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("4. В какое время удобнее тренироваться?", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Container(height=8),
                    ft.Row(time_buttons, spacing=8, wrap=True),
                ], spacing=4),
                padding=16,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=16, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )

        # --- Вопрос 5: Увлечения ---
        hobbies_field = ft.TextField(
            value=state.get("q_hobbies", ""),
            hint_text="Например: танцы, велосипед, плавание...",
            multiline=True,
            min_lines=2,
            max_lines=4,
            bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
            hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
            text_size=14,
            on_change=lambda e: state.update({"q_hobbies": e.control.value}),
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("5. Есть ли подвижные увлечения?", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Text("Можно пропустить", size=12, color=TEXT_MUTED),
                    ft.Container(height=8),
                    hobbies_field,
                ], spacing=4),
                padding=16,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=16, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )

        # --- Кнопка «Далее» ---
        def submit(e):
            if not selected_goals:
                snack = ft.SnackBar(ft.Text("Выбери хотя бы одну цель"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return
            if not state.get("q_freq"):
                snack = ft.SnackBar(ft.Text("Выбери частоту тренировок"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return
            if not state.get("q_activity"):
                snack = ft.SnackBar(ft.Text("Выбери уровень активности"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return
            if not state.get("q_time"):
                snack = ft.SnackBar(ft.Text("Выбери удобное время"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return

            # Сохраняем в user
            user["goals"] = selected_goals
            user["frequency"] = state.get("q_freq", "")
            user["activity"] = state.get("q_activity", "")
            user["time_pref"] = state.get("q_time", "")
            user["hobbies"] = state.get("q_hobbies", "")
            server_save_users(users_data)

            state["screen"] = "inventory"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Button(
                        content=ft.Text("Что нам понадобится →", size=16, weight=ft.FontWeight.BOLD),
                        on_click=submit,
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY, color=PRIMARY_FG,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=18, horizontal=24),
                        ),
                        width=340,
                    ),
                ], alignment=ft.MainAxisAlignment.CENTER),
                padding=ft.padding.only(top=15, bottom=30),
            )
        )
    
    def render_inventory(user):
        content_area.controls.clear()

        content_area.controls.append(back_button("questions"))

        inventory_items = [
            ("Коврик", "inventory_mat"),
            ("Фитнес-резинки (двух видов)", "inventory_bands"),
            ("Скакалка (не обязательно, если негде прыгать)", "inventory_rope"),
            ("2 гантели по 2 кг", "inventory_dumbbells"),
            ("1 гиря 4 кг", "inventory_kettlebell"),
        ]

        inv_state = user.setdefault("inventory_checked", {})

        def on_toggle(key):
            inv_state[key] = not inv_state.get(key, False)
            all_checked = all(inv_state.get(k, False) for _, k in inventory_items)
            state["inventory_all_done"] = all_checked
            server_save_users(users_data)   # ← сохраняем!
            render()

        def on_start(e):
            state["screen"] = "intro_about"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.FITNESS_CENTER, color=PRIMARY, size=48),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Row([
                        ft.Text("Инвентарь", size=24, weight=ft.FontWeight.BOLD, color=TEXT),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Text("Отметь, что у тебя уже есть:", size=15, color=TEXT_MUTED),
                ], spacing=8),
                padding=ft.padding.only(left=20, right=20, top=30, bottom=20),
            )
        )

        # Карточки инвентаря
        for label, key in inventory_items:
            is_checked = inv_state.get(key, False)

            def make_handler(k):
                def handler(e):
                    on_toggle(k)
                return handler

            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Icon(
                                ft.Icons.CHECK,
                                color=PRIMARY_FG if is_checked else "transparent",
                                size=15,
                            ),
                            width=28, height=28, border_radius=14,
                            bgcolor=PRIMARY if is_checked else "transparent",
                            border=ft.border.all(2, PRIMARY if is_checked else BORDER),
                            alignment=ft.alignment.center,
                        ),
                        ft.Text(label, size=15, color=TEXT, expand=True,
                                weight=ft.FontWeight.BOLD if is_checked else ft.FontWeight.NORMAL),
                    ], spacing=14),
                    padding=16,
                    margin=ft.margin.symmetric(horizontal=20, vertical=5),
                    border_radius=16,
                    bgcolor=CARD,
                    border=ft.border.all(2, PRIMARY if is_checked else BORDER),
                    on_click=make_handler(key),
                )
            )

        # Инфо-блок — цвет и текст зависят от того, всё ли отмечено
        if state.get("inventory_all_done", False):
            info_border = MINT
            info_content = ft.Column([
                ft.Row([
                    ft.Icon(ft.Icons.CHECK_CIRCLE, color=MINT, size=22),
                    ft.Text(
                        "Отлично, всё есть!",
                        size=18, weight=ft.FontWeight.BOLD, color=TEXT, expand=True,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ], spacing=8, alignment=ft.MainAxisAlignment.CENTER),
            ], horizontal_alignment=ft.CrossAxisAlignment.CENTER)
        else:
            info_border = PRIMARY
            info_content = ft.Column([
                ft.Row([
                    ft.Icon(ft.Icons.INFO_OUTLINE, color=PRIMARY, size=20),
                    ft.Text(
                        "Первые тренировки будут без инвентаря, поэтому ты можешь уже приступать 💜",
                        size=14, color=TEXT_MUTED, expand=True,
                    ),
                ], spacing=8),
                ft.Container(height=8),
                ft.Row([
                    ft.Icon(ft.Icons.MENU_BOOK, color=PRIMARY, size=20),
                    ft.Text(
                        "Ты сможешь вернуться к этому списку позже — он в разделе Теория.",
                        size=14, color=TEXT_MUTED, expand=True,
                    ),
                ], spacing=8),
            ])

        content_area.controls.append(
            ft.Container(
                content=info_content,
                padding=18,
                margin=ft.margin.symmetric(horizontal=20, vertical=12),
                border_radius=14, bgcolor=CARD_SOFT,
                border=ft.border.all(2, info_border),
            )
        )

        # Кнопка "Далее"
        start_button = ft.Button(
            content=ft.Text("Далее →", size=16, weight=ft.FontWeight.BOLD),
            on_click=on_start,
            style=ft.ButtonStyle(
                bgcolor=PRIMARY, color=PRIMARY_FG,
                shape=ft.RoundedRectangleBorder(radius=12),
                padding=ft.padding.symmetric(vertical=18, horizontal=24),
            ),
            width=340,
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Row([start_button], alignment=ft.MainAxisAlignment.CENTER),
                padding=ft.padding.only(top=10, bottom=30),
            )
        )

    def render_intro_about(user):
        content_area.controls.clear()

        def on_start(e):
            state["screen"] = "warmup"
            render()

        # Картинка
        about_image_path = f"{ASSETS_PREFIX}images/intro_about.jpg"
        image_widget = ft.Row([
            ft.Image(
                src=about_image_path,
                fit=ft.ImageFit.COVER,
                width=400,
                height=260,
            ),
        ], alignment=ft.MainAxisAlignment.CENTER)

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    image_widget,
                    ft.Container(height=25),
                    ft.Row([
                        ft.Text(
                            "Оцени свой уровень",
                            size=24, weight=ft.FontWeight.BOLD, color=TEXT,
                        ),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Container(height=15),
                    ft.Text(
                        "Сейчас мы предлагаем пройти короткую вводную тренировку.",
                        size=16, color=TEXT_MUTED,
                    ),
                    ft.Container(height=10),
                    ft.Text(
                        "Она поможет понять, какой уровень тебе ближе:",
                        size=16, color=TEXT_MUTED,
                    ),
                    ft.Container(height=8),
                    ft.Text(
                        "• начинающий — проходит блоки 1–8. Это подготовка: "
                        "тело привыкнет к нагрузке, и дальше будет легче.",
                        size=15, color=TEXT_MUTED,
                    ),
                    ft.Container(height=6),
                    ft.Text(
                        "• продвинутый — сразу тренируется вместе со всеми в текущем блоке. "
                        "Тренер выставляет новый блок каждую неделю.",
                        size=15, color=TEXT_MUTED,
                    ),
                    ft.Container(height=6),
                    ft.Text(
                        "• если пропустишь неделю — приложение предложит "
                        "адаптационные тренировки, чтобы вернуться в ритм.",
                        size=15, color=TEXT_MUTED,
                    ),
                    ft.Container(height=12),
                    ft.Text(
                        "Ты попробуешь разные упражнения и решишь, "
                        "с какого уровня начать.",
                        size=15, color=TEXT_MUTED,
                    ),
                    ft.Container(height=20),
                    ft.Container(
                        content=ft.Column([
                            ft.Row([
                                ft.Icon(ft.Icons.INFO_OUTLINE, color=BLUSH, size=20),
                                ft.Text(
                                    "Вводную тренировку можно пройти только один раз.",
                                    size=14, color=TEXT_MUTED, expand=True,
                                ),
                            ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.START),
                            ft.Container(height=6),
                            ft.Text(
                                "После неё ты выберешь уровень и начнёшь тренировочный процесс.",
                                size=14, color=TEXT_MUTED,
                            ),
                        ], spacing=0),
                        padding=16,
                        border_radius=14, bgcolor=CARD_SOFT, border=ft.border.all(1, BLUSH),
                    ),
                    ft.Container(height=30),
                    ft.Row([
                        ft.Text(
                            "Готовы пройти вводную тренировку?",
                            size=18, weight=ft.FontWeight.BOLD, color=TEXT,
                            text_align=ft.TextAlign.CENTER,
                        ),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Container(height=15),
                    ft.Row([
                        ft.Button(
                            content=ft.Text("Погнали →", size=16, weight=ft.FontWeight.BOLD),
                            on_click=on_start,
                            style=ft.ButtonStyle(
                                bgcolor=PRIMARY, color=PRIMARY_FG,
                                shape=ft.RoundedRectangleBorder(radius=12),
                                padding=ft.padding.symmetric(vertical=18, horizontal=24),
                            ),
                            width=340,
                        ),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                ], spacing=0),
                padding=ft.padding.symmetric(horizontal=20, vertical=20),
            )
        )
        
    def render_warmup(user):
        content_area.controls.clear()

        content_area.controls.append(back_button("inventory"))

        warmup_done = state.get("warmup_done", False)

        def on_warmup_done(e):
            state["warmup_done"] = e.control.value
            render()

        def on_next(e):
            if not state.get("warmup_done", False):
                snack = ft.SnackBar(ft.Text("Сначала отметь «Разминка сделана»"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return
            state["warmup_done"] = False
            state["screen"] = "intro"
            render()

        video_url = "https://vkvideo.ru/video-148225750_456239018?list=ln-UyoBctTlIxijwLYDgz"  # ← замените

        # Заголовок
        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Icon(ft.Icons.WHATSHOT, color=PRIMARY, size=48),
                    ft.Row([
                        ft.Text("Разминка", size=26, weight=ft.FontWeight.BOLD, color=TEXT),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.padding.only(top=30, bottom=15),
            )
        )

        # Вводный текст
        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text(
                        "Вот это ты бодро нажала, а как же разминка? 😊",
                        size=16, color=PRIMARY, weight=ft.FontWeight.BOLD,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    ft.Container(height=10),
                    ft.Text(
                        "Разминка разогревает мышцы, готовит суставы к нагрузке "
                        "и защищает от травм. Выполняй в спокойном темпе.",
                        size=15, color=TEXT_MUTED,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    ft.Container(height=15),
                    ft.Button(
                        content=ft.Text("▶  Смотреть видео", size=16, weight=ft.FontWeight.BOLD),
                        url=video_url,
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY, color=PRIMARY_FG,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=16, horizontal=24),
                        ),
                        width=320,
                    ),
                ], spacing=0, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.padding.symmetric(horizontal=20, vertical=10),
            )
        )

        # Упражнения
        exercises_list = [
            ("20 Джеки", ""),
            ("10/10 Спайдермен", ""),
            ("3 Червячки", ""),
            ("10 Динамическая лодочка", ""),
            ("10 Развороты сидя", ""),
            ("5 Выпрыгивания из седа", ""),
            ("2 минуты суставная разминка с резинкой", ""),
        ]

        for title, _ in exercises_list:
            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.CHECK_CIRCLE_OUTLINE, color=PRIMARY, size=20),
                        ft.Text(title, size=15, color=TEXT, expand=True),
                    ], spacing=12),
                    padding=14,
                    margin=ft.margin.symmetric(horizontal=20, vertical=4),
                    border_radius=14, bgcolor=CARD, border=ft.border.all(1, BORDER),
                )
            )

        # Финальный текст
        content_area.controls.append(
            ft.Container(
                content=ft.Text(
                    "• Если тело всё ещё не готово к работе — сделай ещё один круг.",
                    size=14, color=PRIMARY, weight=ft.FontWeight.BOLD,
                    text_align=ft.TextAlign.CENTER,
                ),
                padding=ft.padding.symmetric(horizontal=20, vertical=15),
                alignment=ft.alignment.center,
            )
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Text(
                    "Разминку нужно делать перед каждой тренировкой. "
                    "Ты всегда сможешь найти её в разделе «Тренировки».",
                    size=14, color=TEXT_MUTED,
                    text_align=ft.TextAlign.CENTER,
                ),
                padding=ft.padding.symmetric(horizontal=20, vertical=5),
                alignment=ft.alignment.center,
            )
        )

        # Фраза после разминки
        content_area.controls.append(
            ft.Container(
                content=ft.Text(
                    "Ну теперь я точно вижу, что ты готова! 💜",
                    size=16, color=PRIMARY, weight=ft.FontWeight.BOLD,
                    text_align=ft.TextAlign.CENTER,
                ),
                padding=ft.padding.symmetric(horizontal=20, vertical=15),
                alignment=ft.alignment.center,
            )
        )

        # Галочка
        content_area.controls.append(
            ft.Container(
                content=ft.Checkbox(
                    value=warmup_done,
                    label="Разминка сделана",
                    on_change=on_warmup_done,
                     fill_color=PRIMARY, 
                    check_color=PRIMARY_FG,
                    label_style=ft.TextStyle(color=TEXT, size=16, weight=ft.FontWeight.BOLD),
                ),
                padding=ft.padding.symmetric(horizontal=20, vertical=12),
                margin=ft.margin.symmetric(horizontal=20, vertical=5),
                border_radius=14,
                bgcolor=CARD_SOFT,
                border=ft.border.all(2, PRIMARY if warmup_done else BORDER), 
            )
        )

        next_button = ft.Button(
            content=ft.Text("Погнали #2 →", size=16, weight=ft.FontWeight.BOLD),
            on_click=on_next,
            style=ft.ButtonStyle(
                bgcolor=PRIMARY, color=PRIMARY_FG,
                shape=ft.RoundedRectangleBorder(radius=12),
                padding=ft.padding.symmetric(vertical=18, horizontal=24),
            ),
            width=340,
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Row([next_button], alignment=ft.MainAxisAlignment.CENTER),
                padding=ft.padding.only(top=15, bottom=30),
            )
        )

    # ---------- Вводная тренировка ----------

    def render_intro(user):
        content_area.controls.clear()
        done_id = "intro"

        # Перезапрашиваем данные с сервера (чтобы вводная обновлялась)
        fresh = server_get_data()
        intro_data = fresh.get("intro_workout", {}) if fresh else intro

        content_area.controls.append(back_button("warmup"))

        def on_done(e):
            user.setdefault("done", {})[done_id] = e.control.value
            if e.control.value:
                user.setdefault("done_dates", {})[done_id] = today_str()
                user["last_done_date"] = today_str()   # ← добавить
            server_save_users(users_data)
            render()

        def on_continue(e):
            if not user.get("done", {}).get(done_id, False):
                snack = ft.SnackBar(ft.Text("Сначала отметь «Сделано»"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return
            state["screen"] = "level_question"
            render()

        # Картинка
        intro_image_path_raw = intro_data.get("image", "")
        intro_image_path = intro_image_path_raw.replace("assets/", "") if intro_image_path_raw else ""
        if intro_image_path:
            image_widget = ft.Row([
                ft.Image(
                    src=f"{ASSETS_PREFIX}{intro_image_path}",
                    fit=ft.ImageFit.COVER,
                    width=400,
                    height=220,
                ),
            ], alignment=ft.MainAxisAlignment.CENTER)
        else:
            image_widget = ft.Row([
                ft.Container(
                    content=ft.Icon(ft.Icons.PLAY_CIRCLE_OUTLINE, color=PRIMARY, size=60),
                    width=400,
                    height=180,
                    alignment=ft.alignment.center,
                    border_radius=18,
                    bgcolor=CARD_SOFT,
                ),
            ], alignment=ft.MainAxisAlignment.CENTER)

        # Заголовок
        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    image_widget,
                    ft.Container(height=20),
                    ft.Row([
                        ft.Text("Вводная тренировка", size=26, weight=ft.FontWeight.BOLD, color=TEXT),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                ], spacing=10),
                padding=ft.padding.only(top=20, bottom=15),
            )
        )

        # Вводный текст
        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text(
                        "Это знакомство с твоим телом. Выполняй упражнения "
                        "в удобном темпе, не торопись. Если что-то не получается — "
                        "просто пропусти и продолжай.",
                        size=15, color=TEXT_MUTED,
                    ),
                    ft.Container(height=15),
                    ft.Button(
                        content=ft.Text("▶  Смотреть видео", size=16, weight=ft.FontWeight.BOLD),
                        url=intro_data.get("video_url", ""),
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY, color=PRIMARY_FG,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=16, horizontal=24),
                        ),
                        width=320,
                    ) if intro_data.get("video_url", "") else ft.Container(),
                ], spacing=0, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.padding.symmetric(horizontal=20, vertical=10),
            )
        )
        
        # --- Упражнения с видео (плашки) ---
        # Сначала парсим заголовки/указания
        intro_blocks, _ = parse_workout_text(intro_data.get("text", ""))

        # Заголовки (например, "3 Круга") — выводим отдельно, БЕЗ звёзд
        for b in intro_blocks:
            if b["type"] == "header":
                content_area.controls.append(
                    ft.Container(
                        content=ft.Text(
                            b["text"], size=16, weight=ft.FontWeight.BOLD, color=TEXT,
                        ),
                        padding=ft.padding.only(left=20, right=20, top=8, bottom=4),
                        alignment=ft.alignment.center_left,
                    )
                )
            elif b["type"] == "note":
                content_area.controls.append(
                    ft.Container(
                        content=ft.Text(
                            b["text"], size=14, color=TEXT_MUTED, italic=True,
                        ),
                        padding=ft.padding.only(left=20, right=20, top=4, bottom=4),
                    )
                )

        # Потом упражнения с видео
        main_exercises, alt_exercises = find_exercises_in_text(intro_data.get("text", ""))

        # Основные упражнения
        for ex in main_exercises:
            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.FITNESS_CENTER, color=PRIMARY, size=20),
                        ft.Text(ex["name"], size=15, weight=ft.FontWeight.BOLD, color=TEXT, expand=True),
                        ft.Button(
                            content=ft.Text("▶", size=16, weight=ft.FontWeight.BOLD),
                            url=ex["video_url"],
                            style=ft.ButtonStyle(
                                bgcolor=PRIMARY, color=PRIMARY_FG,
                                shape=ft.RoundedRectangleBorder(radius=10),
                                padding=ft.padding.symmetric(vertical=8, horizontal=14),
                            ),
                        ) if ex["video_url"] else ft.Text("Скоро", size=12, color=TEXT_MUTED),
                    ], spacing=10),
                    padding=12,
                    margin=ft.margin.symmetric(horizontal=20, vertical=4),
                    border_radius=12,
                    bgcolor=CARD_SOFT,
                    border=ft.border.all(1, BORDER),
                )
            )

        # Замены (отдельная рамка)
        if alt_exercises:
            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Row([
                            ft.Icon(ft.Icons.SWAP_HORIZ, color=BLUSH, size=20),
                            ft.Text("Замена", size=15, weight=ft.FontWeight.BOLD, color=TEXT),
                        ], spacing=8),
                        ft.Container(height=8),
                    ] + [
                        ft.Container(
                            content=ft.Row([
                                ft.Icon(ft.Icons.FITNESS_CENTER, color=PRIMARY, size=18),
                                ft.Text(ex["name"], size=14, weight=ft.FontWeight.BOLD, color=TEXT, expand=True),
                                ft.Button(
                                    content=ft.Text("▶", size=14, weight=ft.FontWeight.BOLD),
                                    url=ex["video_url"],
                                    style=ft.ButtonStyle(
                                        bgcolor=PRIMARY, color=PRIMARY_FG,
                                        shape=ft.RoundedRectangleBorder(radius=10),
                                        padding=ft.padding.symmetric(vertical=6, horizontal=12),
                                    ),
                                ) if ex["video_url"] else ft.Text("Скоро", size=12, color=TEXT_MUTED),
                            ], spacing=10),
                            padding=10,
                            margin=ft.margin.only(bottom=4),
                            border_radius=10,
                            bgcolor=CARD_SOFT,
                            border=ft.border.all(1, BORDER),
                        )
                        for ex in alt_exercises
                    ]),
                    padding=14,
                    margin=ft.margin.symmetric(horizontal=20, vertical=10),
                    border_radius=14,
                    bgcolor=CARD,
                    border=ft.border.all(2, BLUSH),
                )
            )

        # Финальный текст
        content_area.controls.append(
            ft.Container(
                content=ft.Text(
                    "Отличная работа! 💜",
                    size=16, color=PRIMARY, weight=ft.FontWeight.BOLD,
                    text_align=ft.TextAlign.CENTER,
                ),
                padding=ft.padding.symmetric(horizontal=20, vertical=15),
                alignment=ft.alignment.center,
            )
        )

        # Галочка + кнопка
        content_area.controls.append(
            ft.Container(
                content=ft.Checkbox(
                    value=user.get("done", {}).get(done_id, False),
                    label="Сделано",
                    on_change=on_done,
                    fill_color=PRIMARY,
                    check_color=PRIMARY_FG,
                    label_style=ft.TextStyle(color=TEXT, size=16, weight=ft.FontWeight.BOLD),
                ),
                padding=ft.padding.symmetric(horizontal=20, vertical=12),
                margin=ft.margin.symmetric(horizontal=20, vertical=5),
                border_radius=14,
                bgcolor=CARD_SOFT,
                border=ft.border.all(2, PRIMARY if user.get("done", {}).get(done_id, False) else BORDER),
            )
        )

        continue_button = ft.Button(
            content=ft.Text("Продолжить →", size=16, weight=ft.FontWeight.BOLD),
            on_click=on_continue,
            style=ft.ButtonStyle(
                bgcolor=PRIMARY, color=PRIMARY_FG,
                shape=ft.RoundedRectangleBorder(radius=12),
                padding=ft.padding.symmetric(vertical=18, horizontal=24),
            ),
            width=340,
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Row([continue_button], alignment=ft.MainAxisAlignment.CENTER),
                padding=ft.padding.only(top=15, bottom=30),
            )
        )

        # --- ВРЕМЕННАЯ КНОПКА ДЛЯ ТЕСТА ---
        def reset_all(e):
            users_data["users"] = []
            users_data["current_user"] = None
            server_save_users(users_data)
            state["user"] = None
            state["is_admin"] = False
            state["logged_in"] = False
            state["tab"] = "home"
            state["screen"] = "auto"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.TextButton(
                    content=ft.Text("⚠ Сбросить всё (тест)", size=13, color=BLUSH),
                    on_click=reset_all,
                ),
                padding=ft.padding.only(left=20, right=20, top=10, bottom=30),
            )
        )
        
    # ---------- Вопрос об уровне ----------

    def render_level_question(user):
        content_area.controls.clear()
        
        content_area.controls.append(back_button("intro"))        

        def choose_beginner(e):
            user["level"] = "beginner"
            user["current_block"] = get_block_for_level("beginner")
            user["current_index"] = 0
            user["intro_done"] = True
            server_save_users(users_data)
            state["screen"] = "auto" 
            state["tab"] = "home"
            render()

        def choose_advanced(e):
            user["level"] = "advanced"
            user["current_block"] = get_block_for_level("advanced")
            user["current_index"] = 0
            user["intro_done"] = True
            server_save_users(users_data)
            state["screen"] = "auto"
            state["tab"] = "home"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("Как прошла твоя первая тренировка?", size=22, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Container(height=10),
                    ft.Button(
                        content=ft.Text("Всё хорошо, хочу остаться на этом уровне", size=15, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
                        on_click=choose_beginner,
                        style=ft.ButtonStyle(bgcolor=PRIMARY, color=PRIMARY_FG, shape=ft.RoundedRectangleBorder(radius=12), padding=ft.padding.symmetric(vertical=20, horizontal=20)),
                        width=320,
                    ),
                    ft.Button(
                        content=ft.Text("Было слишком легко, хочу перейти на продвинутый уровень", size=15, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
                        on_click=choose_advanced,
                        style=ft.ButtonStyle(bgcolor=CARD_SOFT, color=TEXT, shape=ft.RoundedRectangleBorder(radius=12), padding=ft.padding.symmetric(vertical=20, horizontal=20)),
                        width=320,
                    ),
                ], spacing=15, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=30,
            )
        )

    def render_rating(user):
        content_area.controls.clear()

        def go_back(e):
            state["screen"] = "auto"
            state["tab"] = "home"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text("Рейтинг", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        # Собираем список
        rating_list = []
        for u in users:
            total = sum(1 for v in u.get("done", {}).values() if v)
            rating_list.append({
                "name": f"{u['first_name']} {u['last_name']}",
                "total": total,
                "id": u["id"],
            })
        rating_list.sort(key=lambda x: x["total"], reverse=True)

        for i, r in enumerate(rating_list):
            place = i + 1

            # Медали для первых трёх
            if place == 1:
                medal = "🥇"
            elif place == 2:
                medal = "🥈"
            elif place == 3:
                medal = "🥉"
            else:
                medal = f"{place}."

            is_me = r["id"] == user["id"]

            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Text(medal, size=22, width=40),
                        ft.Text(
                            r["name"] + (" (ты)" if is_me else ""),
                            size=15, weight=ft.FontWeight.BOLD,
                            color=PRIMARY if is_me else TEXT,
                            expand=True,
                        ),
                        ft.Text(
                            f"{r['total']}",
                            size=17, weight=ft.FontWeight.BOLD,
                            color=PRIMARY if is_me else TEXT,
                        ),
                    ], spacing=10),
                    padding=14,
                    margin=ft.margin.symmetric(horizontal=20, vertical=4),
                    border_radius=14,
                    bgcolor=CARD_SOFT if is_me else CARD,
                    border=ft.border.all(2 if is_me else 1, PRIMARY if is_me else BORDER),
                )
            )

    def render_calculator(user):
        content_area.controls.clear()

        # Добавляем личные продукты пользователя в foods_list
        custom_foods = user.get("custom_foods", [])
        for cf in custom_foods:
            if cf not in foods_list:
                foods_list.append(cf)

        def go_back(e):
            back_to = state.get("back_to", "profile")
            state["back_to"] = ""
            if back_to.startswith("tab:"):
                state["screen"] = "auto"
                state["tab"] = back_to.replace("tab:", "")
            else:
                state["screen"] = back_to
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text("Питание", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        # Вес из state (если есть) или из user
        current_weight = state.get("kbju_weight_input", user.get("kbju_weight", ""))

        def on_weight_change(e):
            state["kbju_weight_input"] = e.control.value

        weight_field = ft.TextField(
            value=str(current_weight) if current_weight else "",
            hint_text="Твой вес (кг)",
            keyboard_type=ft.KeyboardType.NUMBER,
            on_change=on_weight_change,
            bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
            hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
            text_size=15,
        )

        # --- Выбор цели ---
        selected_goal = state.get("kbju_goal", user.get("kbju_goal", "Похудеть"))

        goals = ["Похудеть", "Подтянуть фигуру", "Рельеф и мышцы", "Набор массы"]

        def select_goal(g):
            state["kbju_goal"] = g
            render()

        goal_buttons = []
        for g in goals:
            is_active = selected_goal == g
            goal_buttons.append(
                ft.Button(
                    content=ft.Text(g, size=13, weight=ft.FontWeight.BOLD),
                    on_click=lambda e, goal=g: select_goal(goal),
                    style=ft.ButtonStyle(
                        bgcolor=PRIMARY if is_active else CARD_SOFT,
                        color=PRIMARY_FG if is_active else TEXT,
                        shape=ft.RoundedRectangleBorder(radius=10),
                        padding=ft.padding.symmetric(vertical=12, horizontal=14),
                    ),
                )
            )

        # --- Результат ---
        result_block = []
        try:
            weight = float(user.get("kbju_weight", 0)) if user.get("kbju_weight") else 0
        except Exception:
            weight = 0

        if weight > 0:
            goal = user.get("kbju_goal", "Похудеть")

            if goal == "Похудеть":
                proteins = weight * 1.75
                fats = weight * 1.0
                carbs = weight * 2.5
            elif goal == "Подтянуть фигуру":
                proteins = weight * 2.0
                fats = weight * 1.0
                carbs = weight * 2.5
            elif goal == "Рельеф и мышцы":
                proteins = weight * 3.0
                fats = weight * 1.5
                carbs = weight * 4.0
            else:  # Набор массы
                proteins = weight * 2.5
                fats = weight * 1.5
                carbs = weight * 4.5

            calories = proteins * 4 + fats * 9 + carbs * 4

            result_block = [
                ft.Container(height=15),
                ft.Container(
                    content=ft.Column([
                        ft.Text("Твоя норма на день:", size=15, color=TEXT_MUTED),
                        ft.Container(height=8),
                        ft.Text(f"🔥 Калории: {int(calories)} ккал", size=17, weight=ft.FontWeight.BOLD, color=PRIMARY),
                        ft.Text(f"🥩 Белки: {int(proteins)} г", size=15, color=TEXT),
                        ft.Text(f"🥑 Жиры: {int(fats)} г", size=15, color=TEXT),
                        ft.Text(f"🍚 Углеводы: {int(carbs)} г", size=15, color=TEXT),
                        ft.Container(height=10),
                        ft.Text(
                            "Это рекомендация. Со временем норму можно корректировать.",
                            size=12, color=TEXT_MUTED,
                        ),
                    ], spacing=4),
                    padding=18,
                    border_radius=16,
                    bgcolor=CARD_SOFT,
                    border=ft.border.all(1, PRIMARY),
                ),
            ]

        def save_params(e):
            try:
                w = float(weight_field.value.strip())
            except Exception:
                snack = ft.SnackBar(ft.Text("Введите вес числом"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return

            user["kbju_weight"] = w
            user["kbju_goal"] = selected_goal
            server_save_users(users_data)
            state["kbju_weight_input"] = ""

            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("Узнай свою норму КБЖУ", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Container(height=10),
                    ft.Text("Введи вес:", size=14, color=TEXT_MUTED),
                    weight_field,
                    ft.Container(height=10),
                    ft.Text("Выбери цель:", size=14, color=TEXT_MUTED),
                    ft.Row(goal_buttons, spacing=8, wrap=True),
                    ft.Container(height=15),
                    ft.Button(
                        content=ft.Text("Рассчитать", size=15, weight=ft.FontWeight.BOLD),
                        on_click=save_params,
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY, color=PRIMARY_FG,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=14, horizontal=24),
                        ),
                    ),
                ] + result_block, spacing=6),
                padding=20,
                margin=ft.margin.symmetric(horizontal=20, vertical=10),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )

        # --- Дневник питания ---
        content_area.controls.append(
            ft.Container(
                content=ft.Text("Дневник питания", size=18, weight=ft.FontWeight.BOLD, color=TEXT),
                padding=ft.padding.only(left=20, right=20, top=20, bottom=10),
            )
        )

        # Поле поиска продукта
        food_search = ft.TextField(
            hint_text="Введи название продукта...",
            bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
            hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
            text_size=14,
        )

        portion_field = ft.TextField(
            hint_text="Порция (г или шт)",
            keyboard_type=ft.KeyboardType.NUMBER,
            bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
            hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
            text_size=14, width=120,
        )

        selected_food = state.get("selected_food", None)
        selected_food_name = state.get("selected_food_name", "")

        # Список найденных продуктов
        search_results = state.get("food_search_results", [])

        def do_search(e):
            query = food_search.value.strip().lower()
            if not query:
                state["food_search_results"] = []
                render()
                return
            found = [f for f in foods_list if query in f["name"].lower()][:5]
            state["food_search_results"] = found
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Container(content=food_search, expand=True),
                    ft.Button(
                        content=ft.Text("Найти", size=14, weight=ft.FontWeight.BOLD),
                        on_click=do_search,
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY, color=PRIMARY_FG,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=14, horizontal=18),
                        ),
                    ),
                ], spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.padding.symmetric(horizontal=20, vertical=10),
            )
        )

        # --- Кнопка "Добавить свой продукт" ---
        show_custom_form = state.get("show_custom_food", False)

        def toggle_custom(e):
            state["show_custom_food"] = not show_custom_form
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Button(
                    content=ft.Text(
                        "✕ Закрыть" if show_custom_form else "+ Добавить свой продукт",
                        size=14, weight=ft.FontWeight.BOLD,
                    ),
                    on_click=toggle_custom,
                    style=ft.ButtonStyle(
                        bgcolor=CARD_SOFT if show_custom_form else PRIMARY,
                        color=TEXT if show_custom_form else PRIMARY_FG,
                        shape=ft.RoundedRectangleBorder(radius=12),
                        padding=ft.padding.symmetric(vertical=12, horizontal=18),
                    ),
                ),
                padding=ft.padding.symmetric(horizontal=20, vertical=6),
            )
        )

        # --- Форма своего продукта ---
        if show_custom_form:
            custom_name = ft.TextField(
                hint_text="Название продукта",
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=14,
            )
            custom_kcal = ft.TextField(
                hint_text="Калории на 100 г",
                keyboard_type=ft.KeyboardType.NUMBER,
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=14,
            )
            custom_p = ft.TextField(
                hint_text="Белки (г)",
                keyboard_type=ft.KeyboardType.NUMBER,
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=14, width=100,
            )
            custom_f = ft.TextField(
                hint_text="Жиры (г)",
                keyboard_type=ft.KeyboardType.NUMBER,
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=14, width=100,
            )
            custom_c = ft.TextField(
                hint_text="Углеводы (г)",
                keyboard_type=ft.KeyboardType.NUMBER,
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=14, width=100,
            )

            def save_custom_food(e):
                name = custom_name.value.strip()
                if not name:
                    snack = ft.SnackBar(ft.Text("Введите название"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    return
                try:
                    kcal = float(custom_kcal.value.strip().replace(",", "."))
                    p = float(custom_p.value.strip().replace(",", ".")) if custom_p.value.strip() else 0
                    f = float(custom_f.value.strip().replace(",", ".")) if custom_f.value.strip() else 0
                    c = float(custom_c.value.strip().replace(",", ".")) if custom_c.value.strip() else 0
                except Exception:
                    snack = ft.SnackBar(ft.Text("Введите числа"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    return

                # Добавляем в личные продукты пользователя
                new_food = {
                    "name": name,
                    "type": "grams",
                    "per": 100,
                    "kcal": kcal,
                    "p": p,
                    "f": f,
                    "c": c,
                }
                user.setdefault("custom_foods", []).append(new_food)
                server_save_users(users_data)
                foods_list.append(new_food)

                # Сбрасываем форму
                state["show_custom_food"] = False

                # Сразу выбираем продукт для добавления
                state["selected_food"] = new_food
                state["selected_food_name"] = name

                snack = ft.SnackBar(ft.Text(f"«{name}» добавлен"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                render()

            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text("Свой продукт", size=15, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Container(height=8),
                        custom_name,
                        ft.Container(height=6),
                        custom_kcal,
                        ft.Container(height=6),
                        ft.Row([custom_p, custom_f, custom_c], spacing=6),
                        ft.Container(height=10),
                        ft.Button(
                            content=ft.Text("Сохранить", size=14, weight=ft.FontWeight.BOLD),
                            on_click=save_custom_food,
                            style=ft.ButtonStyle(
                                bgcolor=PRIMARY, color=PRIMARY_FG,
                                shape=ft.RoundedRectangleBorder(radius=12),
                                padding=ft.padding.symmetric(vertical=12, horizontal=20),
                            ),
                        ),
                    ], spacing=4),
                    padding=16,
                    margin=ft.margin.symmetric(horizontal=20, vertical=10),
                    border_radius=16, bgcolor=CARD, border=ft.border.all(2, PRIMARY),
                )
            )

        # Результаты поиска
        if search_results:
            for f in search_results:
                def make_select(food):
                    def select(e):
                        state["selected_food"] = food
                        state["selected_food_name"] = food["name"]
                        state["food_search_results"] = []
                        render()
                    return select

                content_area.controls.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Text(f["name"], size=14, color=TEXT, expand=True),
                            ft.Text(f"{f['kcal']} ккал/100г", size=12, color=TEXT_MUTED),
                        ]),
                        padding=12,
                        margin=ft.margin.symmetric(horizontal=20, vertical=2),
                        border_radius=10, bgcolor=CARD_SOFT, border=ft.border.all(1, BORDER),
                        on_click=make_select(f),
                    )
                )

        # Выбранный продукт + порция
        if selected_food:
            # Определяем единицу измерения
            if selected_food["type"] == "pieces":
                unit = "шт"
                default_portion = "1"
            else:
                unit = "г"
                default_portion = "100"

            def add_food(e):
                try:
                    portion = float(portion_field.value.strip().replace(",", "."))
                except Exception:
                    snack = ft.SnackBar(ft.Text("Введи порцию числом"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    return

                # Считаем КБЖУ
                per = selected_food["per"]
                ratio = portion / per

                entry = {
                    "date": today_str(),
                    "name": selected_food["name"],
                    "portion": portion,
                    "unit": unit,
                    "kcal": round(selected_food["kcal"] * ratio, 1),
                    "p": round(selected_food["p"] * ratio, 1),
                    "f": round(selected_food["f"] * ratio, 1),
                    "c": round(selected_food["c"] * ratio, 1),
                }

                diary = user.setdefault("food_diary", [])
                diary.append(entry)
                server_save_users(users_data)

                state["selected_food"] = None
                state["selected_food_name"] = ""
                snack = ft.SnackBar(ft.Text(f"{selected_food['name']} добавлен"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                render()

            def clear_selection(e):
                state["selected_food"] = None
                state["selected_food_name"] = ""
                render()

            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Row([
                            ft.Text(f"Выбрано: {selected_food['name']}", size=14, weight=ft.FontWeight.BOLD, color=PRIMARY, expand=True),
                            ft.IconButton(ft.Icons.CLOSE, icon_color=DANGER, icon_size=18, on_click=clear_selection),
                        ]),
                        ft.Text(
                            f"На {selected_food['per']} {unit}: {selected_food['kcal']} ккал · Б {selected_food['p']} · Ж {selected_food['f']} · У {selected_food['c']}",
                            size=12, color=TEXT_MUTED,
                        ),
                        ft.Container(height=8),
                        ft.Row([
                            ft.Text(f"Порция ({unit}):", size=14, color=TEXT_MUTED),
                            portion_field,
                            ft.Button(
                                content=ft.Text("Добавить", size=14, weight=ft.FontWeight.BOLD),
                                on_click=add_food,
                                style=ft.ButtonStyle(
                                    bgcolor=PRIMARY, color=PRIMARY_FG,
                                    shape=ft.RoundedRectangleBorder(radius=12),
                                    padding=ft.padding.symmetric(vertical=14, horizontal=18),
                                ),
                            ),
                        ], spacing=8),
                    ], spacing=4),
                    padding=16,
                    margin=ft.margin.symmetric(horizontal=20, vertical=8),
                    border_radius=14, bgcolor=CARD, border=ft.border.all(2, PRIMARY),
                )
            )

        # --- Съедено за сегодня ---
        today = today_str()
        diary = user.get("food_diary", [])
        today_entries = [e for e in diary if e["date"] == today]

        if today_entries:
            total_kcal = sum(e["kcal"] for e in today_entries)
            total_p = sum(e["p"] for e in today_entries)
            total_f = sum(e["f"] for e in today_entries)
            total_c = sum(e["c"] for e in today_entries)

            # Норма из калькулятора
            try:
                weight_val = float(user.get("kbju_weight", 0)) if user.get("kbju_weight") else 0
            except Exception:
                weight_val = 0

            norm_kcal = 0
            if weight_val > 0:
                goal = user.get("kbju_goal", "Похудеть")
                if goal == "Похудеть":
                    p_n = weight_val * 1.75
                    f_n = weight_val * 1.0
                    c_n = weight_val * 2.5
                elif goal == "Подтянуть фигуру":
                    p_n = weight_val * 2.0
                    f_n = weight_val * 1.0
                    c_n = weight_val * 2.5
                elif goal == "Рельеф и мышцы":
                    p_n = weight_val * 3.0
                    f_n = weight_val * 1.5
                    c_n = weight_val * 4.0
                else:
                    p_n = weight_val * 2.5
                    f_n = weight_val * 1.5
                    c_n = weight_val * 4.5
                norm_kcal = p_n * 4 + f_n * 9 + c_n * 4

            remaining = int(norm_kcal - total_kcal) if norm_kcal > 0 else 0

            rows = []
            for entry in reversed(today_entries):
                def make_delete_diary(idx):
                    def delete(e):
                        diary.remove(idx)
                        server_save_users(users_data)
                        render()
                    return delete

                rows.append(
                    ft.Row([
                        ft.Text(f"{entry['name']} — {entry['portion']} {entry['unit']}", size=13, color=TEXT, expand=True),
                        ft.Text(f"{entry['kcal']} ккал", size=13, weight=ft.FontWeight.BOLD, color=PRIMARY),
                        ft.IconButton(
                            ft.Icons.DELETE_OUTLINE, icon_color=DANGER, icon_size=16,
                            on_click=make_delete_diary(entry),
                        ),
                    ], spacing=4)
                )

            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text(f"Сегодня съедено ({len(today_entries)})", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Container(height=8),
                    ] + rows + [
                        ft.Divider(color=BORDER),
                        ft.Row([
                            ft.Text("Итого:", size=14, weight=ft.FontWeight.BOLD, color=TEXT, expand=True),
                            ft.Text(f"{int(total_kcal)} ккал", size=15, weight=ft.FontWeight.BOLD, color=PRIMARY),
                        ]),
                        ft.Text(f"Б: {int(total_p)} г · Ж: {int(total_f)} г · У: {int(total_c)} г", size=12, color=TEXT_MUTED),
                        ft.Container(height=6),
                        ft.Text(
                            f"Осталось до нормы: {remaining} ккал" if norm_kcal > 0 else "Рассчитай КБЖУ выше, чтобы видеть остаток",
                            size=13,
                            color=PRIMARY if remaining >= 0 else DANGER,
                            weight=ft.FontWeight.BOLD,
                        ),
                    ], spacing=6),
                    padding=16,
                    margin=ft.margin.symmetric(horizontal=20, vertical=10),
                    border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                )
            )

        # --- История за 5 дней ---
        content_area.controls.append(
            ft.Container(
                content=ft.Text("История за 5 дней", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                padding=ft.padding.only(left=20, right=20, top=15, bottom=8),
            )
        )

        from datetime import timedelta
        history_rows = []
        for i in range(5):
            day = (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
            day_entries = [e for e in diary if e["date"] == day]
            day_kcal = sum(e["kcal"] for e in day_entries)

            label = "Сегодня" if i == 0 else "Вчера" if i == 1 else day
            history_rows.append(
                ft.Row([
                    ft.Text(label, size=13, color=TEXT_MUTED, expand=True),
                    ft.Text(f"{int(day_kcal)} ккал", size=14, weight=ft.FontWeight.BOLD, color=TEXT),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN)
            )

        content_area.controls.append(
            ft.Container(
                content=ft.Column(history_rows, spacing=8),
                padding=16,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )



    def render_weight(user):
        content_area.controls.clear()

        def go_back(e):
            back_to = state.get("back_to", "profile")
            state["back_to"] = ""
            if back_to.startswith("tab:"):
                state["screen"] = "auto"
                state["tab"] = back_to.replace("tab:", "")
            else:
                state["screen"] = back_to
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text("Вес", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        # --- Ввод веса ---
        weight_field = ft.TextField(
            hint_text="Твой вес (кг)",
            keyboard_type=ft.KeyboardType.NUMBER,
            bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
            hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
            text_size=15,
            expand=True,
        )

        def save_weight(e):
            try:
                w = float(weight_field.value.strip().replace(",", "."))
            except Exception:
                snack = ft.SnackBar(ft.Text("Введите вес числом"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return

            weights = user.setdefault("weights", [])
            weights.append({
                "date": today_str(),
                "weight": w,
            })
            server_save_users(users_data)
            weight_field.value = ""
            snack = ft.SnackBar(ft.Text(f"Вес {w} кг записан"))
            page.overlay.append(snack)
            snack.open = True
            page.update()
            render()

        # --- Инфо-блок ---
        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.INFO_OUTLINE, color=PRIMARY, size=20),
                        ft.Text(
                            "Взвешивайся 2 раза в неделю",
                            size=15, weight=ft.FontWeight.BOLD, color=TEXT,
                        ),
                    ], spacing=8),
                    ft.Container(height=6),
                    ft.Text(
                        "По понедельникам и в четверг/пятницу, в одно и то же время.",
                        size=14, color=TEXT_MUTED,
                    ),
                    ft.Container(height=6),
                    ft.Text(
                        "Для чего это нужно? Понедельник — отправная точка. "
                        "А по четвергам/пятницам — динамика за неделю. "
                        "Многие любят вкусно поесть на выходных — увидишь, "
                        "что потеряла или приобрела.",
                        size=13, color=TEXT_MUTED,
                    ),
                ], spacing=0),
                padding=16,
                margin=ft.margin.symmetric(horizontal=20, vertical=8),
                border_radius=14, bgcolor=CARD_SOFT, border=ft.border.all(1, PRIMARY),
            )
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    weight_field,
                    ft.Button(
                        content=ft.Text("Записать", size=14, weight=ft.FontWeight.BOLD),
                        on_click=save_weight,
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY, color=PRIMARY_FG,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=14, horizontal=18),
                        ),
                    ),
                ], spacing=8),
                padding=ft.padding.symmetric(horizontal=20, vertical=10),
            )
        )

        weights = user.get("weights", [])

        # --- График ---
        if len(weights) >= 2:
            # Сортируем по дате
            sorted_weights = sorted(weights, key=lambda x: x["date"])
            last = sorted_weights

            # Первая дата — точка отсчёта
            try:
                first_date = datetime.strptime(last[0]["date"], "%Y-%m-%d")
            except Exception:
                first_date = None

            chart_points = []
            for w in last:
                try:
                    w_date = datetime.strptime(w["date"], "%Y-%m-%d")
                    x = (w_date - first_date).days
                except Exception:
                    x = 0
                chart_points.append(
                    ft.LineChartDataPoint(x, w["weight"])
                )

            min_w = min(w["weight"] for w in last)
            max_w = max(w["weight"] for w in last)
            padding_y = max(1, (max_w - min_w) * 0.2)

            # Максимум по X (дни)
            max_x = max(p.x for p in chart_points) if chart_points else 1

            chart = ft.LineChart(
                data_series=[
                    ft.LineChartData(
                        data_points=chart_points,
                        stroke_width=3,
                        color=PRIMARY,
                        curved=False,
                        stroke_cap_round=True,
                    ),
                ],
                border=ft.border.all(1, BORDER),
                horizontal_grid_lines=ft.ChartGridLines(
                    interval=1, color=BORDER, width=1,
                ),
                left_axis=ft.ChartAxis(
                    labels_size=40,
                    title_size=20,
                ),
                bottom_axis=ft.ChartAxis(
                    labels_size=40,
                ),
                min_y=min_w - padding_y,
                max_y=max_w + padding_y,
                min_x=0,
                max_x=max_x if max_x > 0 else 1,
                expand=True,
            )
            
            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text("График веса", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Container(height=10),
                        ft.Container(
                            content=chart,
                            height=200,
                        ),
                    ]),
                    padding=16,
                    margin=ft.margin.symmetric(horizontal=20, vertical=10),
                    border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                )
            )   

        else:
            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.SHOW_CHART, color=TEXT_MUTED, size=48),
                        ft.Text(
                            "График веса",
                            size=16, weight=ft.FontWeight.BOLD, color=TEXT,
                            text_align=ft.TextAlign.CENTER,
                        ),
                        ft.Text(
                            "Внеси хотя бы 2 записи — и здесь появится график динамики.",
                            size=13, color=TEXT_MUTED,
                            text_align=ft.TextAlign.CENTER,
                        ),
                    ], spacing=6, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=30,
                    margin=ft.margin.symmetric(horizontal=20, vertical=10),
                    border_radius=18, bgcolor=CARD_SOFT, border=ft.border.all(1, BORDER),
                )
            )
            
        # --- Таблица ---
        editing_weight_index = state.get("editing_weight_index", None)

        # Сортируем по дате (сначала новые)
        show_all = state.get("show_all_weights", False)

        indexed_weights = list(enumerate(weights))
        indexed_weights.sort(key=lambda x: x[1]["date"], reverse=True)
        
        if show_all:
            sorted_last = indexed_weights
        else:
            sorted_last = indexed_weights[:10]

        rows = []
        for real_index, w in sorted_last:

            is_editing = editing_weight_index == real_index

            if is_editing:
                # Поля редактирования
                date_field = ft.TextField(
                    value=w["date"],
                    bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                    border_radius=10, text_size=13, expand=True,
                )
                weight_edit_field = ft.TextField(
                    value=str(w["weight"]),
                    bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                    border_radius=10, text_size=13, width=90,
                )

                def make_save_edit(idx, df, wf):
                    def save_edit(e):
                        try:
                            new_w = float(wf.value.strip().replace(",", "."))
                        except Exception:
                            return
                        # Приводим дату к формату YYYY-MM-DD
                        new_date = df.value.strip()
                        try:
                            parsed = datetime.strptime(new_date, "%Y-%m-%d")
                            new_date = parsed.strftime("%Y-%m-%d")
                        except Exception:
                            for fmt in ["%d.%m.%Y", "%d/%m/%Y", "%Y.%m.%d", "%d-%m-%Y"]:
                                try:
                                    parsed = datetime.strptime(new_date, fmt)
                                    new_date = parsed.strftime("%Y-%m-%d")
                                    break
                                except Exception:
                                    continue
                        
                        weights[idx]["date"] = new_date
                        weights[idx]["weight"] = new_w
                        server_save_users(users_data)
                        state["editing_weight_index"] = None
                        render()
                    return save_edit

                def cancel_edit(e):
                    state["editing_weight_index"] = None
                    render()

                row = ft.Row([
                    date_field,
                    weight_edit_field,
                    ft.IconButton(
                        ft.Icons.CHECK, icon_color=MINT, icon_size=18,
                        on_click=make_save_edit(real_index, date_field, weight_edit_field),
                    ),
                    ft.IconButton(
                        ft.Icons.CLOSE, icon_color=DANGER, icon_size=18,
                        on_click=cancel_edit,
                    ),
                ], spacing=4)
            else:
                def make_start_edit(idx):
                    def start(e):
                        state["editing_weight_index"] = idx
                        render()
                    return start

                def make_delete(idx):
                    def delete(e):
                        del weights[idx]
                        server_save_users(users_data)
                        render()
                    return delete

                row = ft.Row([
                    ft.Text(w["date"], size=13, color=TEXT_MUTED, expand=True),
                    ft.Text(f"{w['weight']} кг", size=14, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.IconButton(
                        ft.Icons.EDIT, icon_color=PRIMARY, icon_size=18,
                        on_click=make_start_edit(real_index),
                        tooltip="Изменить",
                    ),
                    ft.IconButton(
                        ft.Icons.DELETE_OUTLINE, icon_color=DANGER, icon_size=18,
                        on_click=make_delete(real_index),
                        tooltip="Удалить",
                    ),
                ], spacing=2)

            rows.append(row)
            
        # --- Отображаем таблицу ---
        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("История веса (последние 10)", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Container(height=10),
                ] + rows, spacing=6),
                padding=16,
                margin=ft.margin.symmetric(horizontal=20, vertical=10),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )            

    def render_measures(user):
        content_area.controls.clear()

        def go_back(e):
            back_to = state.get("back_to", "profile")
            state["back_to"] = ""
            if back_to.startswith("tab:"):
                state["screen"] = "auto"
                state["tab"] = back_to.replace("tab:", "")
            else:
                state["screen"] = back_to
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text("Замеры", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        # --- Ввод замеров ---
        chest_field = ft.TextField(hint_text="Грудь (см)", keyboard_type=ft.KeyboardType.NUMBER, bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT, hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12, text_size=14, expand=True)
        waist_field = ft.TextField(hint_text="Талия (см)", keyboard_type=ft.KeyboardType.NUMBER, bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT, hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12, text_size=14, expand=True)
        arms_field = ft.TextField(hint_text="Плечи/руки (см)", keyboard_type=ft.KeyboardType.NUMBER, bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT, hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12, text_size=14, expand=True)
        legs_field = ft.TextField(hint_text="Ноги/бёдра (см)", keyboard_type=ft.KeyboardType.NUMBER, bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT, hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12, text_size=14, expand=True)

        def save_measures(e):
            try:
                chest = float(chest_field.value.strip().replace(",", ".")) if chest_field.value.strip() else 0
                waist = float(waist_field.value.strip().replace(",", ".")) if waist_field.value.strip() else 0
                arms = float(arms_field.value.strip().replace(",", ".")) if arms_field.value.strip() else 0
                legs = float(legs_field.value.strip().replace(",", ".")) if legs_field.value.strip() else 0
            except Exception:
                snack = ft.SnackBar(ft.Text("Введите числа"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return

            if chest == 0 and waist == 0 and arms == 0 and legs == 0:
                snack = ft.SnackBar(ft.Text("Заполните хотя бы одно поле"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return

            measures = user.setdefault("measures", [])
            measures.append({
                "date": today_str(),
                "chest": chest,
                "waist": waist,
                "arms": arms,
                "legs": legs,
            })
            # Храним только последние 12 замеров
            if len(measures) > 12:
                measures.sort(key=lambda x: x["date"])
                measures[:] = measures[-12:]
            server_save_users(users_data)
            snack = ft.SnackBar(ft.Text("Замеры записаны"))
            page.overlay.append(snack)
            snack.open = True
            page.update()
            render()

        # --- Инфо-блок ---
        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.INFO_OUTLINE, color=PRIMARY, size=20),
                        ft.Text(
                            "Снимай замеры каждый месяц в одно и то же время суток.",
                            size=15, weight=ft.FontWeight.BOLD, color=TEXT,
                        ),
                    ], spacing=8),
                    ft.Container(height=6),
                    ft.Text(
                        "Для чего это нужно? Мышцы тяжелее жира при одном и том же объёме — "
                        "ты можешь становиться меньше или больше, но не видеть изменений на весах.",
                        size=13, color=TEXT_MUTED,
                    ),
                ], spacing=0),
                padding=16,
                margin=ft.margin.symmetric(horizontal=20, vertical=8),
                border_radius=14, bgcolor=CARD_SOFT, border=ft.border.all(1, PRIMARY),
            )
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("Новые замеры", size=15, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Container(height=8),
                    ft.Row([chest_field, waist_field], spacing=8),
                    ft.Row([arms_field, legs_field], spacing=8),
                    ft.Container(height=8),
                    ft.Button(
                        content=ft.Text("Записать", size=14, weight=ft.FontWeight.BOLD),
                        on_click=save_measures,
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY, color=PRIMARY_FG,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=14, horizontal=18),
                        ),
                    ),
                ], spacing=6),
                padding=ft.padding.symmetric(horizontal=20, vertical=10),
            )
        )

        measures = user.get("measures", [])

        # Убрали return — график рисуется всегда (с заглушкой)

        # --- Выбор замера для графика ---
        selected_measure = state.get("measures_chart_type", "waist")
        measure_labels = {
            "chest": "Грудь",
            "waist": "Талия",
            "arms": "Плечи/руки",
            "legs": "Ноги/бёдра",
        }

        def select_measure(m):
            state["measures_chart_type"] = m
            render()

        measure_buttons = []
        for key, label in measure_labels.items():
            is_active = selected_measure == key
            measure_buttons.append(
                ft.Button(
                    content=ft.Text(label, size=12, weight=ft.FontWeight.BOLD),
                    on_click=lambda e, k=key: select_measure(k),
                    style=ft.ButtonStyle(
                        bgcolor=PRIMARY if is_active else CARD_SOFT,
                        color=PRIMARY_FG if is_active else TEXT,
                        shape=ft.RoundedRectangleBorder(radius=10),
                        padding=ft.padding.symmetric(vertical=10, horizontal=12),
                    ),
                )
            )

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("Что показать на графике:", size=14, color=TEXT_MUTED),
                    ft.Container(height=6),
                    ft.Row(measure_buttons, spacing=6, wrap=True),
                ]),
                padding=ft.padding.symmetric(horizontal=20, vertical=8),
            )
        )

        # --- График ---
        if len(measures) >= 2:
            sorted_measures = sorted(measures, key=lambda x: x["date"])
            last = sorted_measures[-10:]

            try:
                first_date = datetime.strptime(last[0]["date"], "%Y-%m-%d")
            except Exception:
                first_date = None

            chart_points = []
            for m in last:
                try:
                    m_date = datetime.strptime(m["date"], "%Y-%m-%d")
                    x = (m_date - first_date).days
                except Exception:
                    x = 0
                val = m.get(selected_measure, 0)
                if val > 0:
                    chart_points.append(ft.LineChartDataPoint(x, val))

            if len(chart_points) >= 2:
                min_v = min(p.y for p in chart_points)
                max_v = max(p.y for p in chart_points)
                padding_y = max(1, (max_v - min_v) * 0.2)
                max_x = max(p.x for p in chart_points)

                chart = ft.LineChart(
                    data_series=[
                        ft.LineChartData(
                            data_points=chart_points,
                            stroke_width=3,
                            color=PRIMARY,
                            curved=False,
                            stroke_cap_round=True,
                        ),
                    ],
                    border=ft.border.all(1, BORDER),
                    horizontal_grid_lines=ft.ChartGridLines(interval=1, color=BORDER, width=1),
                    left_axis=ft.ChartAxis(labels_size=40),
                    bottom_axis=ft.ChartAxis(labels_size=40),
                    min_y=min_v - padding_y,
                    max_y=max_v + padding_y,
                    min_x=0,
                    max_x=max_x if max_x > 0 else 1,
                    expand=True,
                )

                content_area.controls.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Text(f"График: {measure_labels[selected_measure]}", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                            ft.Container(height=10),
                            ft.Container(content=chart, height=200),
                        ]),
                        padding=16,
                        margin=ft.margin.symmetric(horizontal=20, vertical=10),
                        border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                    )
                )
            else:
                # Меньше 2 точек — заглушка
                content_area.controls.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Icon(ft.Icons.SHOW_CHART, color=TEXT_MUTED, size=48),
                            ft.Text(
                                f"График: {measure_labels[selected_measure]}",
                                size=16, weight=ft.FontWeight.BOLD, color=TEXT,
                                text_align=ft.TextAlign.CENTER,
                            ),
                            ft.Text(
                                "Внеси хотя бы 2 замера — и здесь появится график динамики.",
                                size=13, color=TEXT_MUTED,
                                text_align=ft.TextAlign.CENTER,
                            ),
                        ], spacing=6, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                        padding=30,
                        margin=ft.margin.symmetric(horizontal=20, vertical=10),
                        border_radius=18, bgcolor=CARD_SOFT, border=ft.border.all(1, BORDER),
                    )
                )
        else:
            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.SHOW_CHART, color=TEXT_MUTED, size=48),
                        ft.Text(
                            f"График: {measure_labels[selected_measure]}",
                            size=16, weight=ft.FontWeight.BOLD, color=TEXT,
                            text_align=ft.TextAlign.CENTER,
                        ),
                        ft.Text(
                            "Внеси хотя бы 2 замера — и здесь появится график динамики.",
                            size=13, color=TEXT_MUTED,
                            text_align=ft.TextAlign.CENTER,
                        ),
                    ], spacing=6, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=30,
                    margin=ft.margin.symmetric(horizontal=20, vertical=10),
                    border_radius=18, bgcolor=CARD_SOFT, border=ft.border.all(1, BORDER),
                )
            )               

        # --- Таблица ---
        editing_measure_index = state.get("editing_measure_index", None)

        indexed_measures = list(enumerate(measures))
        indexed_measures.sort(key=lambda x: x[1]["date"], reverse=True)
        sorted_last = indexed_measures[:12]

        rows = []
        for real_index, m in sorted_last:
            is_editing = editing_measure_index == real_index

            if is_editing:
                date_field = ft.TextField(value=m["date"], bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT, border_radius=10, text_size=12, expand=True)
                chest_e = ft.TextField(value=str(m.get("chest", "")), bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT, border_radius=10, text_size=12, width=60)
                waist_e = ft.TextField(value=str(m.get("waist", "")), bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT, border_radius=10, text_size=12, width=60)
                arms_e = ft.TextField(value=str(m.get("arms", "")), bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT, border_radius=10, text_size=12, width=60)
                legs_e = ft.TextField(value=str(m.get("legs", "")), bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT, border_radius=10, text_size=12, width=60)

                def make_save_edit(idx, df, cf, wf, af, lf):
                    def save_edit(e):
                        try:
                            new_date = df.value.strip()
                            try:
                                parsed = datetime.strptime(new_date, "%Y-%m-%d")
                                new_date = parsed.strftime("%Y-%m-%d")
                            except Exception:
                                pass
                            measures[idx]["date"] = new_date
                            measures[idx]["chest"] = float(cf.value.strip().replace(",", ".")) if cf.value.strip() else 0
                            measures[idx]["waist"] = float(wf.value.strip().replace(",", ".")) if wf.value.strip() else 0
                            measures[idx]["arms"] = float(af.value.strip().replace(",", ".")) if af.value.strip() else 0
                            measures[idx]["legs"] = float(lf.value.strip().replace(",", ".")) if lf.value.strip() else 0
                            server_save_users(users_data)
                            state["editing_measure_index"] = None
                            render()
                        except Exception as ex:
                            print(f"[MEASURES SAVE ERROR] {ex}")
                    return save_edit

                def cancel_edit(e):
                    state["editing_measure_index"] = None
                    render()

                row = ft.Column([
                    ft.Row([date_field], spacing=4),
                    ft.Row([chest_e, waist_e, arms_e, legs_e], spacing=4),
                    ft.Row([
                        ft.IconButton(ft.Icons.CHECK, icon_color=MINT, icon_size=18, on_click=make_save_edit(real_index, date_field, chest_e, waist_e, arms_e, legs_e)),
                        ft.IconButton(ft.Icons.CLOSE, icon_color=DANGER, icon_size=18, on_click=cancel_edit),
                    ], spacing=4, alignment=ft.MainAxisAlignment.END),
                ], spacing=4)
            else:
                def make_start_edit(idx):
                    def start(e):
                        state["editing_measure_index"] = idx
                        render()
                    return start

                def make_delete(idx):
                    def delete(e):
                        del measures[idx]
                        server_save_users(users_data)
                        render()
                    return delete

                row = ft.Column([
                    ft.Row([
                        ft.Text(m["date"], size=13, color=TEXT_MUTED, expand=True),
                        ft.IconButton(ft.Icons.EDIT, icon_color=PRIMARY, icon_size=18, on_click=make_start_edit(real_index), tooltip="Изменить"),
                        ft.IconButton(ft.Icons.DELETE_OUTLINE, icon_color=DANGER, icon_size=18, on_click=make_delete(real_index), tooltip="Удалить"),
                    ]),
                    ft.Text(
                        f"Грудь: {m.get('chest', 0)} · Талия: {m.get('waist', 0)} · Плечи/руки: {m.get('arms', 0)} · Ноги/бёдра: {m.get('legs', 0)}",
                        size=12, color=TEXT,
                    ),
                ], spacing=4)

            rows.append(row)

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("История замеров", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Container(height=10),
                ] + rows, spacing=10),
                padding=16,
                margin=ft.margin.symmetric(horizontal=20, vertical=10),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )

    def render_photos(user):
        content_area.controls.clear()

        def go_back(e):
            back_to = state.get("back_to", "profile")
            state["back_to"] = ""
            if back_to.startswith("tab:"):
                state["screen"] = "auto"
                state["tab"] = back_to.replace("tab:", "")
            else:
                state["screen"] = back_to
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text("Фото до/после", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        # --- Надпись про приватность ---
        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.LOCK_OUTLINE, color=BLUSH, size=20),
                    ft.Text(
                        "Никто, кроме вас, их не увидит",
                        size=14, color=TEXT_MUTED, expand=True,
                    ),
                ], spacing=8),
                padding=ft.padding.symmetric(horizontal=20, vertical=10),
            )
        )

        # --- Папка для фото ---
        photos_dir = os.path.join(APP_DATA_DIR, "photos")
        os.makedirs(photos_dir, exist_ok=True)

        slots = [
            ("start", "Старт"),
            ("3m", "3 месяца"),
            ("6m", "6 месяцев"),
            ("1y", "Год"),
        ]

        photos_data = user.setdefault("photos", {})

        # --- FilePicker ---
        file_picker = ft.FilePicker(
            on_result=lambda e: on_photo_picked(e, user, photos_dir, photos_data)
        )
        page.overlay.append(file_picker)

        def on_photo_picked(e, u, pdir, pdata):
            if not e.files:
                return
            file = e.files[0]
            current_slot = state.get("photo_slot", "")
            if not current_slot:
                return
            try:
                # Копируем в папку приложения
                ext = os.path.splitext(file.name)[1] or ".jpg"
                dest_filename = f"user_{u['id']}_{current_slot}{ext}"
                dest_path = os.path.join(pdir, dest_filename)
                
                # На Android file.path может быть доступен
                import shutil
                shutil.copy(file.path, dest_path)
                
                pdata[current_slot] = dest_filename
                server_save_users(users_data)
                snack = ft.SnackBar(ft.Text("Фото загружено!"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                render()
            except Exception as ex:
                print(f"[PHOTO UPLOAD ERROR] {ex}")
                snack = ft.SnackBar(ft.Text("Не удалось загрузить фото"))
                page.overlay.append(snack)
                snack.open = True
                page.update()

        def pick_photo(slot_key):
            state["photo_slot"] = slot_key
            file_picker.pick_files(
                dialog_title="Выбери фото",
                file_type=ft.FilePickerFileType.IMAGE,
                allow_multiple=False,
            )

        # --- Карточки слотов ---
        for slot_key, slot_label in slots:
            photo_filename = photos_data.get(slot_key, "")
            photo_path = os.path.join(photos_dir, photo_filename) if photo_filename else ""

            if photo_filename and os.path.exists(photo_path):
                # Показываем фото
                def make_delete(sk):
                    def delete_photo(e):
                        pdata = user.get("photos", {})
                        old = pdata.get(sk, "")
                        if old:
                            old_path = os.path.join(photos_dir, old)
                            if os.path.exists(old_path):
                                try:
                                    os.remove(old_path)
                                except Exception:
                                    pass
                        pdata[sk] = ""
                        server_save_users(users_data)
                        render()
                    return delete_photo

                photo_widget = ft.Container(
                    content=ft.Image(
                        src=photo_path,
                        fit=ft.ImageFit.COVER,
                        width=300,
                        height=300,
                    ),
                    height=300,
                    border_radius=14,
                    clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                )

                buttons_row = ft.Row([
                    ft.Button(
                        content=ft.Text("Заменить", size=13),
                        on_click=lambda e, sk=slot_key: pick_photo(sk),
                        style=ft.ButtonStyle(
                            bgcolor=CARD_SOFT, color=TEXT,
                            shape=ft.RoundedRectangleBorder(radius=10),
                            padding=ft.padding.symmetric(vertical=8, horizontal=14),
                        ),
                    ),
                    ft.Button(
                        content=ft.Text("Удалить", size=13),
                        on_click=make_delete(slot_key),
                        style=ft.ButtonStyle(
                            bgcolor=CARD_SOFT, color=DANGER,
                            shape=ft.RoundedRectangleBorder(radius=10),
                            padding=ft.padding.symmetric(vertical=8, horizontal=14),
                        ),
                    ),
                ], spacing=8)
            else:
                # Пустой слот
                photo_widget = ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.ADD, color=PRIMARY, size=40),
                        ft.Text("Добавить фото", size=13, color=TEXT_MUTED),
                    ], spacing=6, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    height=200,
                    border_radius=14,
                    bgcolor=CARD_SOFT,
                    alignment=ft.alignment.center,
                    on_click=lambda e, sk=slot_key: pick_photo(sk),
                    border=ft.border.all(2, BORDER),
                )
                buttons_row = ft.Container()

            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text(slot_label, size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Container(height=8),
                        photo_widget,
                        ft.Container(height=8),
                        buttons_row,
                    ], spacing=0, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=16,
                    margin=ft.margin.symmetric(horizontal=20, vertical=8),
                    border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                )
            )

        # --- Рекомендация ---
        content_area.controls.append(
            ft.Container(
                content=ft.Text(
                    "Рекомендуем загрузить фото в начале, затем через 3 месяца, "
                    "полгода и год после начала тренировок. Так ты увидишь свой прогресс!",
                    size=13, color=TEXT_MUTED,
                    text_align=ft.TextAlign.CENTER,
                ),
                padding=ft.padding.symmetric(horizontal=20, vertical=15),
                alignment=ft.alignment.center,
            )
        )

    def render_level_change(user):
        content_area.controls.clear()

        def go_back(e):
            state["screen"] = "profile"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text("Смена уровня", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        current_level = user.get("level", "beginner")

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text(
                        "Если тебе кажется, что текущий уровень не подходит — "
                        "отправь заявку тренеру. Она рассмотрит и подтвердит.",
                        size=15, color=TEXT_MUTED,
                    ),
                    ft.Container(height=20),
                ]),
                padding=20,
                margin=ft.margin.symmetric(horizontal=20, vertical=10),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )

        def send_request(to_level, label):
            user["level_request"] = {
                "to": to_level,
                "requested_at": today_str(),
            }
            server_save_users(users_data)
            snack = ft.SnackBar(ft.Text(f"Заявка на «{label}» отправлена"))
            page.overlay.append(snack)
            snack.open = True
            page.update()
            state["screen"] = "profile"
            render()

        # Кнопка «Продвинутый»
        if current_level != "advanced":
            content_area.controls.append(
                ft.Container(
                    content=ft.Button(
                        content=ft.Text("Перейти на продвинутый", size=16, weight=ft.FontWeight.BOLD),
                        on_click=lambda e: send_request("advanced", "Продвинутый"),
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY, color=PRIMARY_FG,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=18),
                        ),
                        width=340,
                    ),
                    padding=ft.padding.symmetric(horizontal=20, vertical=6),
                    alignment=ft.alignment.center,
                )
            )

        # Кнопка «Начинающий»
        if current_level != "beginner":
            content_area.controls.append(
                ft.Container(
                    content=ft.Button(
                        content=ft.Text("Перейти на начинающий", size=16, weight=ft.FontWeight.BOLD),
                        on_click=lambda e: send_request("beginner", "Начинающий"),
                        style=ft.ButtonStyle(
                            bgcolor=CARD_SOFT, color=TEXT,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=18),
                        ),
                        width=340,
                    ),
                    padding=ft.padding.symmetric(horizontal=20, vertical=6),
                    alignment=ft.alignment.center,
                )
            )

    def render_profile(user):
        content_area.controls.clear()

        def go_back(e):
            state["screen"] = "auto"
            state["tab"] = "home"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text("Мой профиль", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        # --- Фото профиля ---
        photo_path = user.get("profile_photo", "")
        if photo_path:
            photo_url = f"{SERVER_URL}{photo_path}"
            avatar = ft.Container(
                content=ft.Image(
                    src=photo_url,
                    width=100, height=100,
                    fit=ft.ImageFit.COVER,
                    border_radius=50,
                ),
                width=100, height=100, border_radius=50,
                clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
            )
        else:
            avatar = ft.Container(
                content=ft.Icon(ft.Icons.PERSON, color=PRIMARY, size=50),
                width=100, height=100, border_radius=50,
                bgcolor=CARD_SOFT,
                alignment=ft.alignment.center,
            )

        # FilePicker для фото
        file_picker = ft.FilePicker(
            on_result=lambda e: upload_photo_result(e, user)
        )
        page.overlay.append(file_picker)

        def pick_photo(e):
            file_picker.pick_files(
                dialog_title="Выбери фото профиля",
                file_type=ft.FilePickerFileType.IMAGE,
                allow_multiple=False,
            )

        def upload_photo_result(e, u):
            if not e.files:
                return
            # Загружаем на сервер
            file = e.files[0]
            try:
                with open(file.path, "rb") as f:
                    files = {"file": (file.name, f, "image/jpeg")}
                    r = httpx.post(
                        f"{SERVER_URL}/upload/profile_photo?user_id={u['id']}",
                        files=files,
                        timeout=30,
                    )
                if r.status_code == 200:
                    u["profile_photo"] = r.json().get("path", "")
                    server_save_users(users_data)
                    snack = ft.SnackBar(ft.Text("Фото загружено!"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    render()
            except Exception as ex:
                print(f"[UPLOAD ERROR] {ex}")

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        avatar,
                        ft.Column([
                            ft.Text(
                                f"{user['first_name']} {user['last_name']}",
                                size=18, weight=ft.FontWeight.BOLD, color=TEXT,
                            ),
                            ft.Text(
                                "Начинающий" if user.get("level") == "beginner" else "Продвинутый" if user.get("level") == "advanced" else "Уровень не выбран",
                                size=13, color=TEXT_MUTED,
                            ),
                            ft.Container(height=8),
                            ft.Button(
                                content=ft.Text("Загрузить фото", size=13, weight=ft.FontWeight.BOLD),
                                on_click=pick_photo,
                                style=ft.ButtonStyle(
                                    bgcolor=CARD_SOFT, color=TEXT,
                                    shape=ft.RoundedRectangleBorder(radius=10),
                                    padding=ft.padding.symmetric(vertical=8, horizontal=14),
                                ),
                            ),
                        ], spacing=2, expand=True),
                    ], spacing=14),
                ]),
                padding=20,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )

        # --- Вес ---
        def open_weight(e):
            state["back_to"] = "profile"
            state["screen"] = "weight"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.MONITOR_WEIGHT, color=PRIMARY, size=28),
                    ft.Column([
                        ft.Text("Вес", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Text("Записывай и следи за динамикой", size=13, color=TEXT_MUTED),
                    ], spacing=2, expand=True),
                    ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=24),
                ], spacing=14),
                padding=18,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                on_click=open_weight,
            )
        )
        
        # --- Замеры ---
        def open_measures(e):
            state["back_to"] = "profile"
            state["screen"] = "measures"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.STRAIGHTEN, color=PRIMARY, size=28),
                    ft.Column([
                        ft.Text("Замеры", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Text("Грудь, талия, руки, ноги", size=13, color=TEXT_MUTED),
                    ], spacing=2, expand=True),
                    ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=24),
                ], spacing=14),
                padding=18,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                on_click=open_measures,
            )
        )
        
        # --- Питание ---
        def open_calculator(e):
            state["back_to"] = "tab:home"
            state["back_to"] = "profile"
            state["screen"] = "calculator"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.CALCULATE, color=PRIMARY, size=28),
                    ft.Column([
                        ft.Text("Питание", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Text("Норма КБЖУ и дневник питания", size=13, color=TEXT_MUTED),
                    ], spacing=2, expand=True),
                    ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=24),
                ], spacing=14),
                padding=18,
                margin=ft.margin.symmetric(horizontal=20, vertical=10),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                on_click=open_calculator,
            )
        )        
        
        # --- Фото до/после ---
        def open_photos(e):
            state["back_to"] = "profile"
            state["screen"] = "photos"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.PHOTO_CAMERA, color=PRIMARY, size=28),
                    ft.Column([
                        ft.Text("Фото до/после", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Text("Только для тебя", size=13, color=TEXT_MUTED),
                    ], spacing=2, expand=True),
                    ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=24),
                ], spacing=14),
                padding=18,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                on_click=open_photos,
            )
        )        

        # --- Смена уровня ---
        current_level = user.get("level", "beginner")
        level_text = "Начинающий" if current_level == "beginner" else "Продвинутый"
        request = user.get("level_request")

        if request:
            # Заявка уже отправлена
            req_text = "На продвинутый" if request.get("to") == "advanced" else "На начинающий"
            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.HOURGLASS_EMPTY, color=BLUSH, size=24),
                        ft.Column([
                            ft.Text("Заявка отправлена", size=15, weight=ft.FontWeight.BOLD, color=TEXT),
                            ft.Text(f"{req_text}. Ожидает подтверждения тренера.", size=13, color=TEXT_MUTED),
                        ], spacing=2, expand=True),
                    ], spacing=14),
                    padding=18,
                    margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=18, bgcolor=CARD_SOFT, border=ft.border.all(2, BLUSH),
                )
            )
        else:
            def open_level_change(e):
                state["screen"] = "level_change"
                render()

            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.SWAP_VERT, color=PRIMARY, size=28),
                        ft.Column([
                            ft.Text("Сменить уровень", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                            ft.Text(f"Сейчас: {level_text}", size=13, color=TEXT_MUTED),
                        ], spacing=2, expand=True),
                        ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=24),
                    ], spacing=14),
                    padding=18,
                    margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                    on_click=open_level_change,
                )
            )

    def render_missed_workouts(user):
        content_area.controls.clear()

        content_area.controls.append(back_button("auto", "home"))

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.AUTO_AWESOME, color=PRIMARY, size=48),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Text(
                        "Что вы упустили",
                        size=24, weight=ft.FontWeight.BOLD, color=TEXT,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    ft.Text(
                        "Нажми на тренировку, чтобы пройти её в свободный день.",
                        size=14, color=TEXT_MUTED,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ], spacing=8, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=ft.padding.only(left=20, right=20, top=20, bottom=10),
            )
        )

        missed = get_missed_workouts(user)

        if not missed:
            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.CHECK_CIRCLE, color=MINT, size=56),
                        ft.Text(
                            "Всё сделано! Отличная работа! 💜",
                            size=16, weight=ft.FontWeight.BOLD, color=TEXT,
                            text_align=ft.TextAlign.CENTER,
                        ),
                    ], spacing=8, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40,
                    margin=ft.margin.symmetric(horizontal=20, vertical=20),
                    border_radius=18, bgcolor=CARD_SOFT, border=ft.border.all(2, MINT),
                )
            )
            return

        for m in missed:
            w = m["workout"]
            block_title = m["block_title"]
            number = m["workout_number"]
            day = m["day"]

            def make_open(workout=w, block_id=m["block_id"]):
                def open_workout(e):
                    user["current_block"] = block_id
                    block_obj = get_block(block_id)
                    if block_obj:
                        block_workouts = block_obj.get("workouts", [])
                        try:
                            new_index = next(i for i, x in enumerate(block_workouts) if x["id"] == workout["id"])
                        except StopIteration:
                            new_index = 0
                        user["current_index"] = new_index
                    state["from_block"] = True
                    state["from_bonus"] = False
                    server_save_users(users_data)
                    state["screen"] = "auto"
                    state["tab"] = "workouts"
                    render()
                return open_workout

            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Text(str(number), size=18, weight=ft.FontWeight.BOLD, color=PRIMARY_FG),
                            width=44, height=44, border_radius=22,
                            bgcolor=PRIMARY, alignment=ft.alignment.center,
                        ),
                        ft.Column([
                            ft.Text(block_title, size=13, color=TEXT_MUTED),
                            ft.Text(f"Тренировка {number} · {day}", size=15, weight=ft.FontWeight.BOLD, color=TEXT),
                        ], spacing=2, expand=True),
                        ft.Icon(ft.Icons.CHEVRON_RIGHT, color=TEXT_MUTED, size=22),
                    ], spacing=12, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=14,
                    margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=16, bgcolor=CARD, border=ft.border.all(1, BORDER),
                    on_click=make_open(),
                )
            )

    def render_home(user):
        content_area.controls.clear()

        if not user.get("intro_done"):
            render_intro(user)
            return

        if not is_access_active(user):
            payment_banner(user)
            return

        block = get_block(user.get("current_block"))
        if not block:
            content_area.controls.append(ft.Text("Блок не найден", color=TEXT))
            return

        workouts = block["workouts"]
        done_map = user.get("done", {})
        done_dates = user.get("done_dates", {})

        # --- Считаем "всего тренировок" ---
        total_done = sum(1 for v in done_map.values() if v)

        # --- Считаем "на этой неделе" ---
        today = datetime.now()
        monday = today - timedelta(days=today.weekday())
        monday_str = monday.strftime("%Y-%m-%d")

        week_count = 0
        for wid, date_str in done_dates.items():
            if date_str >= monday_str:
                week_count += 1

        # --- Считаем "в этом месяце" ---
        month_start = today.replace(day=1).strftime("%Y-%m-%d")
        month_count = 0
        for wid, date_str in done_dates.items():
            if date_str >= month_start:
                month_count += 1

        # --- Приветствие ---
        def open_profile(e):
            state["back_to"] = "tab:home"
            state["screen"] = "profile"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Column([
                        ft.Text(f"Привет, {user['first_name']} 💜", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Text(
                            "Продвинутый" if user.get("level") == "advanced" else "Начинающий",
                            size=14, color=TEXT_MUTED,
                        ),
                    ], spacing=4, expand=True),
                    ft.IconButton(
                        ft.Icons.ACCOUNT_CIRCLE,
                        icon_color=PRIMARY,
                        icon_size=36,
                        on_click=open_profile,
                        tooltip="Мой профиль",
                    ),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                padding=ft.padding.only(left=20, right=20, top=20, bottom=10),
            )
        )

        # --- Цитата дня ---
        import hashlib
        today_seed = datetime.now().strftime("%Y-%m-%d")
        quote_index = int(hashlib.md5(today_seed.encode()).hexdigest(), 16) % len(QUOTES)
        quote_of_day = QUOTES[quote_index]

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.FORMAT_QUOTE, color=PRIMARY, size=22),
                        ft.Text("Цитата дня", size=13, color=TEXT_MUTED, weight=ft.FontWeight.BOLD),
                    ], spacing=8),
                    ft.Container(height=8),
                    ft.Text(
                        quote_of_day,
                        size=15, color=TEXT,
                        italic=True,
                    ),
                ], spacing=0),
                padding=18,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=18,
                bgcolor=CARD,
                border=ft.border.all(1, BORDER),
            )
        )

        # --- Карточка цикла ---
        days_left = 0
        if user.get("payment_due_date"):
            try:
                due = datetime.strptime(user["payment_due_date"], "%Y-%m-%d")
                days_left = max(0, (due - datetime.now()).days)
            except ValueError:
                days_left = 0

        week_text = f"{week_count} раз" if week_count > 0 else "пока 0. Начни сегодня!"

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Text("Цикл заботы", size=13, color=TEXT_MUTED, weight=ft.FontWeight.BOLD),
                        ft.Container(
                            content=ft.Text("✨ Первая неделя — бесплатно", size=11, color=PRIMARY, weight=ft.FontWeight.BOLD),
                            padding=ft.padding.symmetric(vertical=4, horizontal=10),
                            border_radius=20,
                            bgcolor=CARD_SOFT,
                        ),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    ft.Container(height=12),
                    ft.Row([
                        ft.Column([
                            ft.Text(f"{total_done}", size=28, weight=ft.FontWeight.BOLD, color=TEXT),
                            ft.Text("всего тренировок", size=13, color=TEXT_MUTED),
                        ], spacing=2, expand=True),
                        ft.Column([
                            ft.Text(f"{days_left} дн.", size=22, weight=ft.FontWeight.BOLD, color=PRIMARY),
                            ft.Text("до оплаты", size=13, color=TEXT_MUTED),
                        ], spacing=2, horizontal_alignment=ft.CrossAxisAlignment.END),
                    ]),
                    ft.Container(height=12),
                    ft.Text(f"В этом месяце: {month_count} раз", size=14, color=PRIMARY, weight=ft.FontWeight.BOLD),
                    ft.Container(height=12),
                    ft.Container(
                        content=ft.Container(
                            bgcolor=PRIMARY, height=8, border_radius=4,
                            width=int((month_count / 20) * 100) if month_count < 20 else 100,
                        ),
                        bgcolor=CARD_SOFT, border_radius=4, height=8,
                    ),
                    ft.Container(height=8),
                    ft.Text("💙 Гордимся тобой!", size=13, color=PRIMARY),
                ]),
                padding=20,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )

        # --- Полоска недели ---
        days = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]
        today_idx = datetime.now().weekday()

        # Собираем даты тренировок за текущую неделю
        trained_dates = set()
        for wid_key, date_str in done_dates.items():
            if date_str >= monday_str:
                trained_dates.add(date_str)

        # Даты текущей недели (Пн–Вс)
        week_dates = []
        for i in range(7):
            d = monday + timedelta(days=i)
            week_dates.append(d.strftime("%Y-%m-%d"))

        week_row = []
        for i, day in enumerate(days):
            is_today = i == today_idx
            was_trained = week_dates[i] in trained_dates

            if was_trained:
                circle_bg = PRIMARY
                circle_content = ft.Icon(ft.Icons.CHECK, color=PRIMARY_FG, size=16)
                day_color = PRIMARY
            elif is_today:
                circle_bg = PRIMARY
                circle_content = ft.Container(width=8, height=8, border_radius=4, bgcolor=PRIMARY_FG)
                day_color = PRIMARY
            else:
                circle_bg = CARD_SOFT
                circle_content = ft.Container(width=8, height=8, border_radius=4, bgcolor=TEXT_MUTED)
                day_color = TEXT_MUTED

            week_row.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text(day, size=12, weight=ft.FontWeight.BOLD, color=day_color),
                        ft.Container(
                            content=ft.Container(content=circle_content, alignment=ft.alignment.center),
                            width=32, height=32, border_radius=16, bgcolor=circle_bg,
                            alignment=ft.alignment.center,
                        ),
                    ], spacing=4, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    expand=True,
                )
            )
            
        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("Твоя неделя", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Container(height=10),
                    ft.Row(week_row, spacing=4),
                ]),
                padding=20,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )
   
        # --- Что вы упустили ---
        missed = get_missed_workouts(user)

        if missed:
            def open_missed(e):
                state["back_to"] = "tab:home"
                state["screen"] = "missed"
                render()

            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Icon(ft.Icons.AUTO_AWESOME, color=PRIMARY_FG, size=24),
                            width=44, height=44, border_radius=22,
                            bgcolor=PRIMARY, alignment=ft.alignment.center,
                        ),
                        ft.Column([
                            ft.Text("Ты можешь наверстать!", size=15, weight=ft.FontWeight.BOLD, color=TEXT),
                            ft.Text(f"{len(missed)} тренировок ждут тебя", size=13, color=TEXT_MUTED),
                        ], spacing=2, expand=True),
                        ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=22),
                    ], spacing=12, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=16,
                    margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=18, bgcolor=CARD_SOFT, border=ft.border.all(1, PRIMARY),
                    on_click=open_missed,
                )
            )
   
        # --- Рейтинг ---
        rating_list = []
        for u in users:
            total = sum(1 for v in u.get("done", {}).values() if v)
            rating_list.append({
                "name": f"{u['first_name']} {u['last_name']}",
                "total": total,
                "id": u["id"],
            })
        rating_list.sort(key=lambda x: x["total"], reverse=True)

        my_place = 0
        for i, r in enumerate(rating_list):
            if r["id"] == user["id"]:
                my_place = i + 1
                break

        def open_rating(e):
            state["back_to"] = "tab:home"
            state["screen"] = "rating"
            render()

        # Топ-3
        top3_widgets = []
        for i, r in enumerate(rating_list[:3]):
            medal = ["🥇", "🥈", "🥉"][i]
            is_me = r["id"] == user["id"]
            top3_widgets.append(
                ft.Row([
                    ft.Text(medal, size=20),
                    ft.Text(
                        r["name"] + (" (ты)" if is_me else ""),
                        size=14, weight=ft.FontWeight.BOLD,
                        color=PRIMARY if is_me else TEXT,
                        expand=True,
                    ),
                    ft.Text(
                        str(r["total"]),
                        size=15, weight=ft.FontWeight.BOLD,
                        color=PRIMARY if is_me else TEXT,
                    ),
                ], spacing=8)
            )

        # Если я не в топ-3 — показываю своё место отдельно
        if my_place > 3 and my_place <= len(rating_list):
            me = rating_list[my_place - 1]
            top3_widgets.append(
                ft.Container(
                    content=ft.Row([
                        ft.Text(f"{my_place}.", size=16, width=40, color=PRIMARY),
                        ft.Text(
                            me["name"] + " (ты)",
                            size=14, weight=ft.FontWeight.BOLD,
                            color=PRIMARY,
                            expand=True,
                        ),
                        ft.Text(
                            str(me["total"]),
                            size=15, weight=ft.FontWeight.BOLD,
                            color=PRIMARY,
                        ),
                    ], spacing=8),
                    padding=ft.padding.symmetric(vertical=4),
                    margin=ft.margin.only(top=4),
                    border=ft.border.only(top=ft.BorderSide(1, BORDER)),
                )
            )

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.EMOJI_EVENTS, color=PRIMARY, size=24),
                        ft.Text("Рейтинг", size=17, weight=ft.FontWeight.BOLD, color=TEXT, expand=True),
                        ft.Text(
                            f"Ты на {my_place} месте" if my_place > 0 else "",
                            size=13, color=TEXT_MUTED,
                        ),
                    ], spacing=10),
                    ft.Container(height=10),
                ] + top3_widgets + [
                    ft.Container(height=8),
                    ft.Text(
                        "Посмотреть всех →",
                        size=13, color=PRIMARY, weight=ft.FontWeight.BOLD,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ], spacing=4),
                padding=18,
                margin=ft.margin.symmetric(horizontal=20, vertical=10),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                on_click=open_rating,
            )
        )

        # --- Рекомендации ---
        if user.get("goals"):
            def open_recs(e):
                state["back_to"] = "tab:home"
                state["screen"] = "recommendations"
                state["recs_from"] = "home"
                render()

            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.RECOMMEND, color=PRIMARY, size=28),
                        ft.Column([
                            ft.Text("Твои рекомендации", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                            ft.Text("Советы по питанию и тренировкам", size=13, color=TEXT_MUTED),
                        ], spacing=2, expand=True),
                        ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=24),
                    ], spacing=14),
                    padding=18,
                    margin=ft.margin.symmetric(horizontal=20, vertical=10),
                    border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                    on_click=open_recs,
                )
            )
        
        # --- ВРЕМЕННАЯ КНОПКА ДЛЯ ТЕСТА ---
        def reset_all(e):
            users_data["users"] = []
            users_data["current_user"] = None
            server_save_users(users_data)
            state["user"] = None
            state["is_admin"] = False
            state["logged_in"] = False
            state["tab"] = "home"
            state["screen"] = "auto"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.TextButton(
                    content=ft.Text("⚠ Сбросить всё (тест)", size=13, color=BLUSH),
                    on_click=reset_all,
                ),
                padding=ft.padding.only(left=20, right=20, top=10, bottom=30),
            )
        )

        # --- Шутка внизу ---
        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Text("🌱", size=28),
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    ft.Container(height=6),
                    ft.Text(
                        "Если ты соблюдаешь рекомендации КБЖУ, правильно питаешься "
                        "и много тренируешься более 3 месяцев, а изменений нет —",
                        size=13, color=TEXT_MUTED,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    ft.Container(height=4),
                    ft.Text(
                        "ПЕРЕСТАНЬ СЕБЕ ВРАТЬ",
                        size=16, weight=ft.FontWeight.BOLD, color=PRIMARY,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ], spacing=0, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=20,
                margin=ft.margin.symmetric(horizontal=20, vertical=15),
                border_radius=18,
                bgcolor=CARD_SOFT,
                border=ft.border.all(1, BORDER),
            )
        )

    def render_video_view(user):
        content_area.controls.clear()

        video_url = state.get("view_video_url", "")
        if not video_url:
            return

        def go_back(e):
            state["screen"] = "auto"
            state["tab"] = "workouts"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text("Видео", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Video(
                    playlist=[ft.VideoMedia(video_url)],
                    autoplay=True,
                    show_controls=True,
                    expand=True,
                ),
                padding=20,
                height=400,
            )
        )

    # ---------- Тренировки ----------

    def render_workouts_tab(user):
        content_area.controls.clear()

        # Перезапрашиваем данные и пользователей (чтобы текущий блок обновлялся)
        fresh = server_get_data()
        print(f"[DEBUG] fresh blocks: {len(fresh.get('blocks', [])) if fresh else 'None'}")
        if fresh:
            data.clear()
            data.update(fresh)
            blocks.clear()
            blocks.extend(fresh.get("blocks", []))
            print(f"[DEBUG] blocks after update: {len(blocks)}")

        if not user.get("intro_done"):
            content_area.controls.append(ft.Container(content=ft.Text("Сначала пройди вводную тренировку", size=15, color=TEXT_MUTED), padding=20))
            return

        if not is_access_active(user):
            payment_banner(user)
            return

        # Текущий блок — по флагу is_current (если есть)
        # НО не трогаем, если пришли из блока/бонуса (from_block)
        if not state.get("from_block") and user.get("level") == "advanced":
            current_block_id = get_current_block_id()
            if user.get("current_block", 1) < current_block_id:
                user["current_block"] = current_block_id
                user["current_index"] = 0
                server_save_users(users_data)

        # Определяем уровень
        level = user.get("level", "beginner")

        # Проверка: продвинутый пропустил неделю → показываем блок 8
        catchup_mode = False
        if level == "advanced" and is_week_missed(user):
            block_8 = get_block(8)
            if block_8:
                done_map_check = user.get("done", {})
                skipped_map = user.get("skipped", {})
                workouts_8 = block_8.get("workouts", [])
                if not workouts_8:
                    # Блок 8 пуст — не входим в catchup
                    all_done_or_skipped = True
                else:
                    catchup_done = user.get("catchup_done", {})
                    all_done_or_skipped = all(
                        catchup_done.get(str(w["id"]), False) or skipped_map.get(str(w["id"]), False)
                        for w in workouts_8
                    )

                if all_done_or_skipped:
                    # Все 5 выполнены/пропущены → возвращаем в текущий блок
                    user["last_done_date"] = today_str()
                    user["catchup_done"] = {}
                    server_save_users(users_data)
                else:
                    catchup_mode = True

        state["_in_catchup"] = catchup_mode
        if catchup_mode:
            block = get_block(8)
        else:
            block = get_block(user.get("current_block"))

        print(f"[DEBUG catchup] catchup_mode={catchup_mode}, block_id={block['id'] if block else None}")

        workouts = block["workouts"]
        index = user.get("current_index", 0)
        done_map = user.get("done", {})

        # При catchup — игнорируем done для блока 8
        if catchup_mode:
            done_map = {k: v for k, v in done_map.items() if not str(k).startswith("8")}
        level = user.get("level", "beginner")

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Text("Тренировки", size=24, weight=ft.FontWeight.BOLD, color=TEXT, expand=True),
                    ft.Text(
                        f"Блок {block['id']}" if block else "",
                        size=13, weight=ft.FontWeight.BOLD, color=MINT,
                    ),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                padding=ft.padding.only(left=20, right=20, top=20, bottom=10),
            )
        )

        # --- Определяем тренировку для показа ---
        today_names = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        today_name = today_names[datetime.now().weekday()]

        if level == "beginner" or catchup_mode:
            from_block = state.get("from_block", False)
            just_done = state.get("just_done")

            if from_block:
                # Пришли из блока — показываем current_index (выбранную)
                index = user.get("current_index", 0)
                if index >= len(workouts):
                    index = 0
                state["from_block"] = False   # сбрасываем
            elif just_done:
                # Только что нажали «Сделано» — показываем ту же тренировку
                for i, w in enumerate(workouts):
                    if str(w["id"]) == just_done:
                        index = i
                        break
            else:
                # Первая невыполненная и не пропущенная
                index = len(workouts)
                catchup_done_map = user.get("catchup_done", {}) if catchup_mode else {}
                for i, w in enumerate(workouts):
                    wid_w = str(w["id"])
                    is_done = catchup_done_map.get(wid_w, False) if catchup_mode else done_map.get(wid_w, False)
                    is_skipped = user.get("skipped", {}).get(wid_w, False)
                    if not is_done and not is_skipped:
                        index = i
                        break

            if index >= len(workouts):
                # Начинающий прошёл блок 8 → автоматически продвинутый
                if user.get("level") == "beginner" and user.get("current_block") == 8:
                    user["level"] = "advanced"
                    user["current_block"] = get_current_block_id()
                    user["current_index"] = 0
                    server_save_users(users_data)
                    render()
                    return

                # Блок пройден — показываем «Следующий блок»
                level_next = user.get("level", "beginner")
                next_bid = get_next_block_id(user.get("current_block", 1), level_next)
                next_block_obj = get_block(next_bid)
                is_same = (next_bid == user.get("current_block"))

                def go_next_block(e):
                    if next_block_obj and not is_same:
                        user["current_block"] = next_bid
                        user["current_index"] = 0
                        server_save_users(users_data)
                        render()
                    else:
                        snack = ft.SnackBar(ft.Text("Скоро новый блок от Ламии 💜"))
                        page.overlay.append(snack)
                        snack.open = True
                        page.update()

                # Проверяем, есть ли невыполненные (не done и не skipped)
                missed_in_block = []
                for i, w in enumerate(workouts):
                    wid_w = str(w["id"])
                    if not done_map.get(wid_w, False) and not user.get("skipped", {}).get(wid_w, False):
                        missed_in_block.append((i, w))

                if missed_in_block:
                    first_missed_idx, first_missed_w = missed_in_block[0]
                    first_missed_num = first_missed_w.get("number", first_missed_idx + 1)
                    first_missed_wid = str(first_missed_w["id"])

                    def go_to_missed(e):
                        user["current_index"] = first_missed_idx
                        # Убираем из skipped — теперь её можно выполнить
                        if "skipped" in user:
                            user["skipped"].pop(first_missed_wid, None)
                        state["just_done"] = None
                        state["force_scroll"] = True
                        server_save_users(users_data)
                        render()

                    content_area.controls.append(
                        ft.Container(
                            content=ft.Column([
                                ft.Text(
                                    f"В этом блоке вы ещё не выполнили тренировку {first_missed_num}.",
                                    size=16, weight=ft.FontWeight.BOLD, color=TEXT,
                                    text_align=ft.TextAlign.CENTER,
                                ),
                                ft.Text(
                                    "Хотите выполнить её сейчас?",
                                    size=14, color=TEXT_MUTED,
                                    text_align=ft.TextAlign.CENTER,
                                ),
                                ft.Container(height=15),
                                ft.Button(
                                    content=ft.Text(f"Выполнить тренировку {first_missed_num} →", size=16, weight=ft.FontWeight.BOLD),
                                    on_click=go_to_missed,
                                    style=ft.ButtonStyle(bgcolor=PRIMARY, color=PRIMARY_FG, shape=ft.RoundedRectangleBorder(radius=12), padding=ft.padding.symmetric(vertical=16)),
                                ),
                            ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                            padding=30,
                            margin=ft.margin.symmetric(horizontal=20, vertical=10),
                            border_radius=18, bgcolor=CARD, border=ft.border.all(2, PRIMARY),
                        )
                    )
                    return

                # --- Все тренировки выполнены — блок пройден ---
                content_area.controls.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Text("🏆 Блок пройден!", size=22, weight=ft.FontWeight.BOLD, color=TEXT),
                            ft.Text("Отличная работа!", size=16, color=TEXT_MUTED),
                            ft.Container(height=15),
                            ft.Button(
                                content=ft.Text("Следующий блок →", size=16, weight=ft.FontWeight.BOLD),
                                on_click=go_next_block,
                                style=ft.ButtonStyle(bgcolor=PRIMARY, color=PRIMARY_FG, shape=ft.RoundedRectangleBorder(radius=12), padding=ft.padding.symmetric(vertical=16)),
                            ) if (next_block_obj and not is_same) else ft.Text("Скоро новый блок 💜", size=14, color=PRIMARY),
                        ], spacing=15, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                        padding=30,
                        margin=ft.margin.symmetric(horizontal=20, vertical=10),
                        border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                    )
                )
                return   # ← выходим, блоки не показываем

            workout = workouts[index]
        else:
            # Продвинутые
            from_block = state.get("from_block", False)
            just_done = state.get("just_done")

            if from_block:
                # Пришли из блока/бонуса — показываем выбранную тренировку
                index = user.get("current_index", 0)
                if index >= len(workouts):
                    index = 0
                workout = workouts[index] if workouts else None
            elif just_done:
                # Только что нажали «Сделано» — показываем ту же тренировку
                workout = None
                for i, w in enumerate(workouts):
                    if str(w["id"]) == just_done:
                        index = i
                        workout = w
                        break
                if workout is None:
                    workout = workouts[index] if index < len(workouts) else None
            else:
                # Тренировка по дню недели
                workout = None
                for w in workouts:
                    if w.get("day") == today_name:
                        workout = w
                        break

                # Если сегодняшняя уже сделана — показываем «Уже сделана»
                if workout and done_map.get(str(workout["id"]), False):
                    workout = None
        if workout is None:
            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Icon(ft.Icons.CHECK_CIRCLE, color=MINT, size=56),
                        ft.Text(
                            "Тренировка на сегодня уже сделана!",
                            size=16, weight=ft.FontWeight.BOLD, color=TEXT,
                            text_align=ft.TextAlign.CENTER,
                        ),
                        ft.Text(
                            "Можешь пройти пропущенную или заглянуть в Бонус 💜",
                            size=14, color=TEXT_MUTED,
                            text_align=ft.TextAlign.CENTER,
                        ),
                    ], spacing=8, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=40,
                    margin=ft.margin.symmetric(horizontal=20, vertical=20),
                    border_radius=18, bgcolor=CARD_SOFT, border=ft.border.all(2, MINT),
                )
            )
        else:
            # --- Текущая тренировка ---
            wid = str(workout["id"])

            def on_done_change(e):
                # Лимит: 2 тренировки в день (только при отметке done=True)
                if e.control.value and not state.get("_in_catchup"):
                    done_dates_check = user.get("done_dates", {})
                    today = today_str()

                    # Считаем done за сегодня
                    done_today_count = 0
                    for w_id, d in done_dates_check.items():
                        if d == today:
                            done_today_count += 1

                    if done_today_count >= 2:
                        snack = ft.SnackBar(ft.Text("Вы сегодня хорошо поработали. Залог успеха не только в нагрузках, но и в правильном восстановлении 💜"))
                        page.overlay.append(snack)
                        snack.open = True
                        page.update()
                        return

                if state.get("_in_catchup"):
                    # Catchup: сохраняем в отдельный список
                    catchup_done = user.setdefault("catchup_done", {})
                    catchup_done[wid] = e.control.value
                    if e.control.value:
                        user.setdefault("catchup_dates", {})[wid] = today_str()
                else:
                    done_map[wid] = e.control.value
                    if e.control.value:
                        user.setdefault("done_dates", {})[wid] = today_str()
                        user["last_done_date"] = today_str()
                state["just_done"] = wid
                server_save_users(users_data)
                render()

            # При catchup — проверяем catchup_done, иначе done_map
            if state.get("_in_catchup"):
                catchup_done_map = user.get("catchup_done", {})
                is_checked = catchup_done_map.get(wid, False)
            else:
                is_checked = done_map.get(wid, False)

            def toggle_done(e):
                class FakeEvent:
                    def __init__(self, val):
                        self.control = type('obj', (), {'value': val})()
                on_done_change(FakeEvent(not is_checked))

            done_check = ft.Container(
                content=ft.Row([
                    ft.Container(
                        content=ft.Icon(
                            ft.Icons.CHECK,
                            color=PRIMARY_FG if is_checked else "transparent",
                            size=18,
                        ),
                        width=26, height=26, border_radius=8,
                        bgcolor=PRIMARY if is_checked else "transparent",
                        border=ft.border.all(2, PRIMARY),
                        alignment=ft.alignment.center,
                    ),
                    ft.Text(
                        "Сделано",
                        size=16, weight=ft.FontWeight.BOLD,
                        color=TEXT,
                    ),
                ], spacing=12),
                padding=ft.padding.symmetric(vertical=16, horizontal=16),
                border_radius=16,
                bgcolor=ft.Colors.with_opacity(0.14, PRIMARY),
                border=ft.border.all(2, PRIMARY if is_checked else BORDER),
                on_click=toggle_done,
            )

            comment_field = ft.TextField(
                hint_text="Твой комментарий...",
                multiline=True, min_lines=1, max_lines=3,
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
            )

            # Хранилище прикреплённых файлов
            attached_media = state.setdefault("comment_attached", {})
            if wid not in attached_media or "items" not in attached_media[wid]:
                attached_media[wid] = {"items": []}

            def pick_comment_media(e):
                comment_picker.on_result = lambda ev: handle_comment_media(ev, wid, user)
                comment_picker.pick_files(
                    dialog_title="Выбери фото или видео",
                    allow_multiple=False,
                )

            def handle_comment_media(e, wid_local, u):
                if not e.files:
                    return
                file = e.files[0]

                # Ограничение: 50 МБ
                MAX_SIZE_MB = 50
                try:
                    file_size = os.path.getsize(file.path)
                    if file_size > MAX_SIZE_MB * 1024 * 1024:
                        snack = ft.SnackBar(ft.Text(f"Файл больше {MAX_SIZE_MB} МБ. Выберите меньше."))
                        page.overlay.append(snack)
                        snack.open = True
                        page.update()
                        return
                except Exception as ex:
                    print(f"[SIZE CHECK ERROR] {ex}")

                try:
                    with open(file.path, "rb") as f:
                        files = {"file": (file.name, f)}
                        r = httpx.post(
                            f"{SERVER_URL}/upload/comment_media?user_id={u['id']}",
                            files=files,
                            timeout=60,
                        )
                    if r.status_code == 200:
                        data = r.json()
                        current = state["comment_attached"].get(wid_local, {"items": []})
                        if "items" not in current:
                            current = {"items": []}
                        current["items"].append({
                            "path": data.get("path", ""),
                            "media_type": data.get("media_type", ""),
                        })
                        state["comment_attached"][wid_local] = current
                        snack = ft.SnackBar(ft.Text("Файл прикреплён!"))
                        page.overlay.append(snack)
                        snack.open = True
                        page.update()
                        render()

                        async def _scroll_bottom():
                            try:
                                col = state.get("comments_column")
                                if col:
                                    await col.scroll_to(offset=-1, duration=300)
                            except Exception:
                                pass
                        page.run_task(_scroll_bottom)
                    else:
                        snack = ft.SnackBar(ft.Text("Не удалось загрузить"))
                        page.overlay.append(snack)
                        snack.open = True
                        page.update()
                except Exception as ex:
                    print(f"[COMMENT UPLOAD ERROR] {ex}")

            attach_button = ft.IconButton(
                ft.Icons.ATTACH_FILE,
                icon_color=PRIMARY,
                icon_size=24,
                on_click=pick_comment_media,
                tooltip="Прикрепить фото или видео",
            )          

            def scroll_comments_down():
                async def _scroll():
                    try:
                        import asyncio
                        await asyncio.sleep(0.1)
                        col = state.get("comments_column")
                        if col:
                            await col.scroll_to(offset=-1, duration=300)
                    except Exception as e:
                        print(f"[SCROLL ERROR] {e}")
                page.run_task(_scroll)

            def send_comment(e):
                text_value = comment_field.value.strip()
                media_items = attached_media.get(wid, {}).get("items", [])

                if not text_value and not media_items:
                    snack = ft.SnackBar(ft.Text("Напишите текст или прикрепите файл"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    return

                # Список комментариев (новый формат)
                user.setdefault("comments_list", {}).setdefault(wid, []).append({
                    "text": text_value,
                    "media_list": media_items,
                    "date": today_str(),
                })
                attached_media[wid] = {"items": []}
                server_save_users(users_data)
                snack = ft.SnackBar(ft.Text("Комментарий сохранён!"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                render()

                # Прокрутка комментариев вниз
                async def _scroll_bottom():
                    try:
                        import asyncio
                        await asyncio.sleep(0.2)
                        col = state.get("comments_column")
                        if col:
                            await col.scroll_to(offset=-1, duration=300)
                    except Exception as e:
                        print(f"[SCROLL ERROR] {e}")
                page.run_task(_scroll_bottom)

            # Превью прикреплённого файла
            attached_info = attached_media.get(wid, {})
            attached_path = attached_info.get("path", "")
            attached_type = attached_info.get("media_type", "")

            preview_widget = ft.Container()
            attached_items = attached_media.get(wid, {}).get("items", [])

            if attached_items:
                def clear_attached(e):
                    attached_media[wid] = {"items": []}
                    render()

                preview_children = []
                for item in attached_items:
                    full_url = f"{SERVER_URL}{item.get('path', '')}"
                    if item.get("media_type") == "image":
                        preview_children.append(
                            ft.Container(
                                content=ft.Image(
                                    src=full_url,
                                    fit=ft.ImageFit.COVER,
                                    width=60,
                                    height=60,
                                    border_radius=6,
                                ),
                                width=60,
                                height=60,
                                border_radius=6,
                                clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                            )
                        )
                    elif item.get("media_type") == "video":
                        preview_children.append(
                            ft.Container(
                                content=ft.Video(
                                    playlist=[ft.VideoMedia(full_url)],
                                    width=60,
                                    height=60,
                                    autoplay=False,
                                    show_controls=False,
                                ),
                                width=60,
                                height=60,
                                border_radius=6,
                                clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                            )
                        )

                preview_widget = ft.Container(
                    content=ft.Column([
                        ft.Row([
                            ft.Text(f"Прикреплено: {len(attached_items)}", size=13, color=TEXT_MUTED, expand=True),
                            ft.IconButton(
                                ft.Icons.CLOSE,
                                icon_color=DANGER,
                                icon_size=18,
                                on_click=clear_attached,
                            ),
                        ], spacing=6),
                        ft.Row(
                            preview_children,
                            spacing=6,
                            scroll=ft.ScrollMode.AUTO,
                        ),
                    ], spacing=6),
                    padding=8,
                    margin=ft.margin.only(top=6),
                    border_radius=10,
                    bgcolor=CARD_SOFT,
                    border=ft.border.all(1, BORDER),
                )

            send_button = ft.Button(
                content=ft.Text("Отправить комментарий", size=15, weight=ft.FontWeight.BOLD),
                on_click=send_comment,
                style=ft.ButtonStyle(
                    bgcolor=PRIMARY, color=PRIMARY_FG,
                    shape=ft.RoundedRectangleBorder(radius=12),
                    padding=ft.padding.symmetric(vertical=14, horizontal=18),
                ),
            )

            # Кнопки видео/голосового
            media_buttons = []
            
            video_url = workout.get("video_url", "").strip()
            audio_url = workout.get("audio_url", "").strip()
            
            if video_url:
                media_buttons.append(
                    ft.Button(
                        content=ft.Text("▶  Смотреть видео", size=16, weight=ft.FontWeight.BOLD),
                        url=video_url,
                        style=ft.ButtonStyle(bgcolor=PRIMARY, color=PRIMARY_FG, shape=ft.RoundedRectangleBorder(radius=12), padding=ft.padding.symmetric(vertical=16)),
                    )
                )
            
            if audio_url:
                media_buttons.append(
                    ft.Button(
                        content=ft.Text("▶  Слушать голосовое", size=16, weight=ft.FontWeight.BOLD),
                        url=audio_url,
                        style=ft.ButtonStyle(bgcolor=PRIMARY, color=PRIMARY_FG, shape=ft.RoundedRectangleBorder(radius=12), padding=ft.padding.symmetric(vertical=16)),
                    )
                )
            def next_workout(e):
                # Лимит: 2 тренировки в день — проверяем при переходе на 3-ю
                if not state.get("_in_catchup"):
                    done_dates_check = user.get("done_dates", {})
                    today = today_str()

                    done_today_count = 0
                    for w_id, d in done_dates_check.items():
                        if d == today:
                            done_today_count += 1

                    if done_today_count >= 2:
                        snack = ft.SnackBar(ft.Text("Вы сегодня хорошо поработали. Залог успеха не только в нагрузках, но и в правильном восстановлении 💜"))
                        page.overlay.append(snack)
                        snack.open = True
                        page.update()
                        return
                print(f"[DEBUG next_workout CALLED]")                
                if state.get("_in_catchup"):
                    catchup_done = user.get("catchup_done", {})
                    skipped_map = user.get("skipped", {})
                    new_index = None
                    for i, w in enumerate(workouts):
                        wid_w = str(w["id"])
                        if not catchup_done.get(wid_w, False) and not skipped_map.get(wid_w, False):
                            new_index = i
                            break
                    print(f"[DEBUG next_workout catchup] new_index={new_index}, catchup_done={catchup_done}, skipped={skipped_map}")
                    if new_index is not None:
                        user["current_index"] = new_index
                else:
                    user["current_index"] = index + 1
                state["just_done"] = None
                state["from_block"] = False
                state["force_scroll"] = True
                server_save_users(users_data)
                render()

            next_button = ft.Button(
                content=ft.Text("Следующая тренировка →", size=16, weight=ft.FontWeight.BOLD),
                on_click=next_workout,
                style=ft.ButtonStyle(bgcolor=PRIMARY, color=PRIMARY_FG, shape=ft.RoundedRectangleBorder(radius=12), padding=ft.padding.symmetric(vertical=16)),
            )

            header = workout.get("day", "")
            subheader = f"{workout['number']} ТРЕНИРОВКА"

            image_path_raw = block.get("image", "")
            image_path = image_path_raw.replace("assets/", "") if image_path_raw else ""
            if image_path:
                image_widget = ft.Row([
                    ft.Image(
                        src=f"{ASSETS_PREFIX}{image_path}",
                        fit=ft.ImageFit.COVER,
                        width=400,
                        height=180,
                    ),
                ], alignment=ft.MainAxisAlignment.CENTER)
            else:
                image_widget = ft.Container()

            # --- Разминка ---
            warmup_card = ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.WHATSHOT, color=PRIMARY, size=24),
                    ft.Column([
                        ft.Text("Разминка", size=15, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Text("Перед каждой тренировкой", size=12, color=TEXT_MUTED),
                    ], spacing=2, expand=True),
                    ft.IconButton(
                        ft.Icons.PLAY_ARROW,
                        icon_color=PRIMARY_FG,
                        icon_size=22,
                        url="https://vkvideo.ru/video-148225750_456239017",
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY,
                            shape=ft.CircleBorder(),
                            padding=ft.padding.all(10),
                        ),
                    ),
                ], spacing=12),
                padding=16,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=14, bgcolor=CARD_SOFT, border=ft.border.all(1, BORDER),
            )

            content_area.controls.append(warmup_card)
            
            # --- Реакции ---
            reactions_map = user.setdefault("reactions", {})
            my_reaction = reactions_map.get(wid, "")
            counts = get_reactions_for_workout(wid)

            def skip_workout(e):
                # Лимит: 1 пропуск на блок
                skipped_map_check = user.get("skipped", {})
                current_block_id = user.get("current_block", 1)

                # Считаем пропуски в текущем блоке
                skipped_in_block = 0
                for w_check in workouts:
                    if skipped_map_check.get(str(w_check["id"]), False):
                        skipped_in_block += 1

                if skipped_in_block >= 1:
                    snack = ft.SnackBar(ft.Text("Хватит халявить! Один пропуск на блок — это максимум 💜"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    return

                user.setdefault("skipped", {})[wid] = True
                user["current_index"] = index + 1
                state["just_done"] = None
                state["force_scroll"] = True
                server_save_users(users_data)
                render()
                
            def skip_from_bonus(e):
                state["screen"] = "auto"
                state["tab"] = "bonus"
                state["from_block"] = False
                state["from_bonus"] = False
                state["force_scroll"] = True
                render()             

            def on_react(e, emoji):
                if reactions_map.get(wid) == emoji:
                    reactions_map[wid] = ""
                else:
                    reactions_map[wid] = emoji
                server_save_users(users_data)
                render()

            reaction_buttons = []
            main_emojis = ["👍", "❤️", "💪", "🔥", "😊"]
            extra_emojis = ["😂", "😮", "😢", "👎", "💩"]

            def toggle_extra(e):
                state["show_extra_reactions"] = not state.get("show_extra_reactions", False)
                render()

            for emoji in main_emojis:
                is_active = my_reaction == emoji
                count = counts.get(emoji, 0)
                reaction_buttons.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Text(emoji, size=18),
                            ft.Text(str(count) if count > 0 else "", size=13,
                                    color=PRIMARY_FG if is_active else TEXT_MUTED,
                                    weight=ft.FontWeight.BOLD),
                        ], spacing=4),
                        padding=ft.padding.symmetric(vertical=6, horizontal=12),
                        border_radius=20,
                        bgcolor=PRIMARY if is_active else CARD_SOFT,
                        border=ft.border.all(1, PRIMARY if is_active else BORDER),
                        on_click=lambda e, em=emoji: on_react(e, em),
                    )
                )

            # Кнопка "+" для дополнительных
            reaction_buttons.append(
                ft.IconButton(
                    ft.Icons.ADD,
                    icon_color=TEXT_MUTED,
                    icon_size=20,
                    on_click=toggle_extra,
                    tooltip="Ещё реакции",
                    style=ft.ButtonStyle(
                        bgcolor=CARD_SOFT,
                        shape=ft.CircleBorder(),
                        padding=ft.padding.all(10),
                    ),
                )
            )

            # Дополнительные (если раскрыто)
            if state.get("show_extra_reactions", False):
                for emoji in extra_emojis:
                    is_active = my_reaction == emoji
                    count = counts.get(emoji, 0)
                    reaction_buttons.append(
                        ft.Container(
                            content=ft.Row([
                                ft.Text(emoji, size=18),
                                ft.Text(str(count) if count > 0 else "", size=13,
                                        color=PRIMARY_FG if is_active else TEXT_MUTED,
                                        weight=ft.FontWeight.BOLD),
                            ], spacing=4),
                            padding=ft.padding.symmetric(vertical=6, horizontal=12),
                            border_radius=20,
                            bgcolor=PRIMARY if is_active else CARD_SOFT,
                            border=ft.border.all(1, PRIMARY if is_active else BORDER),
                            on_click=lambda e, em=emoji: on_react(e, em),
                        )
                    )

            reactions_row = ft.Row(
                reaction_buttons,
                spacing=6,
                alignment=ft.MainAxisAlignment.CENTER,
                wrap=False,
            )
            
            # --- Парсим текст ---
            parsed_blocks, alt_exercises_list = parse_workout_text(workout.get("text", ""))

            def open_video(video_file):
                state["view_video_url"] = f"{SERVER_URL}{video_file}"
                state["screen"] = "video_view"
                render()
            
            exercise_widgets = []
            for block in parsed_blocks:
                if block["type"] == "space":
                    exercise_widgets.append(ft.Container(height=6))
                
                elif block["type"] == "header":
                    exercise_widgets.append(
                        ft.Container(
                            content=ft.Row([
                                ft.Text(
                                    block["text"],
                                    size=20, weight=ft.FontWeight.BOLD, color=TEXT,
                                    expand=True,
                                    text_align=ft.TextAlign.LEFT,
                                ),
                            ], alignment=ft.MainAxisAlignment.START),
                            padding=ft.padding.symmetric(vertical=8),
                        )
                    )
                
                elif block["type"] == "exercise":
                    ex = block["data"]
                    row_items = [
                        ft.Icon(ft.Icons.FITNESS_CENTER, color=PRIMARY, size=20),
                        ft.Text(ex["name"], size=15, weight=ft.FontWeight.BOLD, color=TEXT, expand=True),
                    ]
                    
                    # Проверяем, есть ли замена для этого упражнения
                    has_alt = False
                    for alt in alt_exercises_list:
                        alt_base = alt["name"].lower().split()[0]
                        ex_base = ex["name"].lower().split()[0]
                        if alt_base in ex["name"].lower() or ex_base in alt["name"].lower():
                            has_alt = True
                            break
                    
                    if has_alt:
                        row_items.append(
                            ft.Icon(ft.Icons.SWAP_HORIZ, color=BLUSH, size=18, tooltip="Есть замена")
                        )
                    video_file = ex.get("video_file", "").strip()
                    video_url = ex.get("video_url", "").strip()

                    if video_file:
                        row_items.append(
                            ft.IconButton(
                                ft.Icons.PLAY_ARROW,
                                icon_color=PRIMARY_FG,
                                icon_size=20,
                                on_click=lambda e, vf=video_file: open_video(vf),
                                style=ft.ButtonStyle(
                                    bgcolor=PRIMARY,
                                    shape=ft.CircleBorder(),
                                    padding=ft.padding.all(8),
                                ),
                            )
                        )
                    elif video_url:
                        row_items.append(
                            ft.Button(
                                content=ft.Text("▶", size=16, weight=ft.FontWeight.BOLD),
                                url=video_url,
                                style=ft.ButtonStyle(
                                    bgcolor=PRIMARY, color=PRIMARY_FG,
                                    shape=ft.RoundedRectangleBorder(radius=10),
                                    padding=ft.padding.symmetric(vertical=8, horizontal=14),
                                ),
                            )
                        )
                    else:
                        row_items.append(ft.Text("Скоро", size=12, color=TEXT_MUTED))

                    exercise_widgets.append(
                        ft.Container(
                            content=ft.Row(row_items, spacing=10),
                            padding=12,
                            margin=ft.margin.only(bottom=4),
                            border_radius=12,
                            bgcolor=CARD_SOFT,
                            border=ft.border.all(1, BORDER),
                        )
                    )
                
                elif block["type"] == "alt_block":
                    alt_items = []
                    for alt in block["items"]:
                        alt_row = [
                            ft.Icon(ft.Icons.FITNESS_CENTER, color=PRIMARY, size=18),
                            ft.Text(alt["name"], size=14, weight=ft.FontWeight.BOLD, color=TEXT, expand=True),
                        ]
                        if alt["video_url"]:
                            alt_row.append(
                                ft.Button(
                                    content=ft.Text("▶", size=14, weight=ft.FontWeight.BOLD),
                                    url=alt["video_url"],
                                    style=ft.ButtonStyle(
                                        bgcolor=PRIMARY, color=PRIMARY_FG,
                                        shape=ft.RoundedRectangleBorder(radius=10),
                                        padding=ft.padding.symmetric(vertical=6, horizontal=12),
                                    ),
                                )
                            )
                        else:
                            alt_row.append(ft.Text("Скоро", size=12, color=TEXT_MUTED))
                        alt_items.append(
                            ft.Container(
                                content=ft.Row(alt_row, spacing=10),
                                padding=10,
                                margin=ft.margin.only(bottom=4),
                                border_radius=10,
                                bgcolor=CARD_SOFT,
                                border=ft.border.all(1, BORDER),
                            )
                        )
                    
                    exercise_widgets.append(
                        ft.Container(
                            content=ft.Column([
                                ft.Row([
                                    ft.Icon(ft.Icons.SWAP_HORIZ, color=BLUSH, size=20),
                                    ft.Text("Замена", size=15, weight=ft.FontWeight.BOLD, color=TEXT),
                                ], spacing=8),
                                ft.Container(height=8),
                            ] + alt_items),
                            padding=14,
                            margin=ft.margin.only(top=8, bottom=8),
                            border_radius=14,
                            bgcolor=CARD,
                            border=ft.border.all(2, BLUSH),
                        )
                    )
                
                elif block["type"] == "note":
                    exercise_widgets.append(
                        ft.Container(
                            content=ft.Text(
                                block["text"],
                                size=15, color=TEXT_MUTED,
                                italic=True,
                            ),
                            padding=ft.padding.only(left=8, top=4, bottom=4),
                        )
                    )
            
            # Замены уже встроены в exercise_widgets
            alt_widgets = []

            # --- Комментарии ---
            all_comments = get_comments_for_workout(wid)

            comments_content = [
                ft.Row([
                    ft.Icon(ft.Icons.FORUM_OUTLINED, color=PRIMARY, size=20),
                    ft.Text(
                        f"Комментарии ({len(all_comments)})" if all_comments else "Комментарии",
                        size=16, weight=ft.FontWeight.BOLD, color=TEXT,
                    ),
                ], spacing=8),
                ft.Container(height=10),
            ]

            if all_comments:
                def make_comment_card(c):
                    photo = (c.get("photo") or "").strip()

                    if photo:
                        avatar = ft.Container(
                            content=ft.Image(
                                src=photo,
                                width=36, height=36,
                                fit=ft.ImageFit.COVER,
                                border_radius=18,
                            ),
                            width=36, height=36, border_radius=18,
                            clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                        )
                    else:
                        first_letter = (c.get("name", "?") or "?")[0].upper()
                        avatar = ft.Container(
                            content=ft.Text(
                                first_letter,
                                size=16, weight=ft.FontWeight.BOLD,
                                color=PRIMARY_FG,
                            ),
                            width=36, height=36, border_radius=18,
                            bgcolor=PRIMARY,
                            alignment=ft.alignment.center,
                        )

                    column_items = [
                        ft.Text(c["name"], size=13, weight=ft.FontWeight.BOLD, color=PRIMARY),
                    ]

                    if c.get("text"):
                        column_items.append(
                            ft.Text(c["text"], size=14, color=TEXT)
                        )

                    media_items = c.get("media_items", [])
                    if media_items:
                        media_widgets = []
                        for item in media_items:
                            media_url = item.get("media", "")
                            media_type = item.get("media_type", "")
                            if not media_url:
                                continue
                            if media_type == "image":
                                media_widgets.append(
                                    ft.Container(
                                        content=ft.Image(
                                            src=media_url,
                                            fit=ft.ImageFit.COVER,
                                            width=80,
                                            height=80,
                                            border_radius=8,
                                        ),
                                        width=80,
                                        height=80,
                                        border_radius=8,
                                        clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                                    )
                                )
                            elif media_type == "video":
                                def make_open_video(url=media_url):
                                    def handler(e):
                                        state["view_video_url"] = url
                                        state["screen"] = "video_view"
                                        render()
                                    return handler

                                media_widgets.append(
                                    ft.Container(
                                        content=ft.Stack([
                                            ft.Container(
                                                content=ft.Icon(ft.Icons.PLAY_CIRCLE, color=PRIMARY_FG, size=32),
                                                width=80, height=80,
                                                bgcolor=PRIMARY,
                                                alignment=ft.alignment.center,
                                            ),
                                        ]),
                                        width=80,
                                        height=80,
                                        border_radius=8,
                                        clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                                        on_click=make_open_video(),
                                    )
                                )

                        if media_widgets:
                            column_items.append(
                                ft.Row(
                                    media_widgets,
                                    spacing=6,
                                    scroll=ft.ScrollMode.AUTO,
                                )
                            )

                    return ft.Container(
                        content=ft.Row([
                            avatar,
                            ft.Column(column_items, spacing=4, expand=True),
                        ], spacing=10, vertical_alignment=ft.CrossAxisAlignment.START),
                        padding=12,
                        margin=ft.margin.only(bottom=6),
                        border_radius=12,
                        bgcolor=CARD_SOFT,
                        border=ft.border.all(1, BORDER),
                    )

                comments_content += [make_comment_card(c) for c in all_comments]
            else:
                import random
                if "empty_comment_phrase" not in state:
                    state["empty_comment_phrase"] = random.choice([
                        "Поделитесь первым впечатлением! 💜",
                        "Оставьте первый комментарий! 💜",
                        "Ваш комментарий будет первым! 💜",
                    ])
                comments_content.append(
                    ft.Text(
                        state["empty_comment_phrase"],
                        size=14, color=TEXT_MUTED,
                        text_align=ft.TextAlign.CENTER,
                    )
                )

            comments_column = ft.Column(
                comments_content,
                spacing=4,
                scroll=ft.ScrollMode.AUTO,
            )
            state["comments_column"] = comments_column

            # --- Карточка тренировки ---
            card_content = [
                image_widget,
                ft.Container(
                    content=ft.Column([
                        ft.Row([
                            ft.Text(header, size=14, color=TEXT_MUTED, weight=ft.FontWeight.BOLD),
                        ], alignment=ft.MainAxisAlignment.CENTER),
                        ft.Row([
                            ft.Text(subheader, size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                        ], alignment=ft.MainAxisAlignment.CENTER),
                        ft.Container(height=5),
                    ] + exercise_widgets + alt_widgets + media_buttons + [
                        ft.Container(height=10),
                        ft.Divider(color=BORDER),
                        reactions_row,
                        ft.Container(height=10),
                        done_check,
                        ft.Container(height=10),
                        ft.Divider(color=BORDER),
                        ft.Container(
                            content=ft.Stack([
                                ft.Container(
                                    content=comments_column,
                                    height=300,
                                    padding=ft.padding.all(12),
                                ),
                                ft.Container(
                                    content=ft.IconButton(
                                        ft.Icons.ARROW_DOWNWARD,
                                        icon_color=PRIMARY_FG,
                                        icon_size=20,
                                        on_click=lambda e: scroll_comments_down(),
                                        tooltip="Вниз",
                                    ),
                                    width=40,
                                    height=40,
                                    border_radius=20,
                                    bgcolor=PRIMARY,
                                    alignment=ft.alignment.center,
                                    right=10,
                                    bottom=10,
                                ) if len(all_comments) > 5 else ft.Container(),
                            ], height=300),
                            border_radius=16,
                            bgcolor=CARD_SOFT,
                            border=ft.border.all(1, BORDER),
                            clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
                        ),
                        ft.Divider(color=BORDER),
                        ft.Row([
                            ft.Container(content=comment_field, expand=True),
                            attach_button,
                        ], spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                        preview_widget,
                        ft.Row([
                            ft.Button(
                                content=ft.Text("Отправить комментарий", size=15, weight=ft.FontWeight.BOLD),
                                on_click=send_comment,
                                style=ft.ButtonStyle(
                                    bgcolor=PRIMARY, color=PRIMARY_FG,
                                    shape=ft.RoundedRectangleBorder(radius=12),
                                    padding=ft.padding.symmetric(vertical=14, horizontal=18),
                                ),
                            ),
                        ], alignment=ft.MainAxisAlignment.START),
                        ft.Container(height=10),
                        # Кнопка действия — крупная, по всей ширине
                        (
                            # «← Назад в Бонус» — из бонуса
                            ft.Button(
                                content=ft.Text("← Назад в Бонус", size=16, weight=ft.FontWeight.BOLD),
                                on_click=skip_from_bonus,
                                style=ft.ButtonStyle(
                                    bgcolor=CARD_SOFT, color=TEXT,
                                    shape=ft.RoundedRectangleBorder(radius=16),
                                    padding=ft.padding.symmetric(vertical=18),
                                ),
                                width=340,
                            ) if (state.get("from_bonus") and level == "advanced")
                            else (
                                # «Следующая тренировка» — если сделано
                                ft.Button(
                                    content=ft.Text("Следующая тренировка →", size=16, weight=ft.FontWeight.BOLD),
                                    on_click=next_workout,
                                    style=ft.ButtonStyle(
                                        bgcolor=PRIMARY, color=PRIMARY_FG,
                                        shape=ft.RoundedRectangleBorder(radius=16),
                                        padding=ft.padding.symmetric(vertical=18),
                                    ),
                                    width=340,
                                ) if (state.get("_in_catchup") and user.get("catchup_done", {}).get(wid, False))
                                or (not state.get("_in_catchup") and done_map.get(wid, False))
                                else (
                                    # «Пропустить» — начинающий / catchup
                                    ft.Button(
                                        content=ft.Text("Пропустить →", size=16, weight=ft.FontWeight.BOLD),
                                        on_click=skip_workout,
                                        style=ft.ButtonStyle(
                                            bgcolor=CARD_SOFT, color=TEXT,
                                            shape=ft.RoundedRectangleBorder(radius=16),
                                            padding=ft.padding.symmetric(vertical=18),
                                        ),
                                        width=340,
                                    ) if (level == "beginner" or catchup_mode)
                                    else ft.Container()
                                )
                            )
                        ),
                    ], spacing=12),
                    padding=20,
                ),
            ]
            
            card = ft.Container(
                content=ft.Column(card_content, spacing=0),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                clip_behavior=ft.ClipBehavior.ANTI_ALIAS,
            )

            content_area.controls.append(ft.Container(content=card, padding=ft.padding.symmetric(horizontal=20)))

        def render_block_card(block_item, locked):
            workouts_b = block_item["workouts"]
            done_map_b = user.get("done", {})
            done_count = sum(1 for w in workouts_b if done_map_b.get(str(w["id"]), False))

            def on_open(e):
                if locked:
                    snack = ft.SnackBar(ft.Text("Этот блок откроется после оплаты"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    return
                state["screen"] = "block_detail"
                state["view_block"] = block_item["id"]
                render()

            lock_icon = ft.Icon(ft.Icons.LOCK_OUTLINE, color=TEXT_MUTED, size=20) if locked else None

            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Column([
                            ft.Text(block_item["title"], size=17, weight=ft.FontWeight.BOLD, color=TEXT if not locked else TEXT_MUTED),
                            ft.Text(f"{done_count} из {len(workouts_b)} тренировок", size=14, color=TEXT_MUTED),
                        ], spacing=4, expand=True),
                        lock_icon if locked else ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=24),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    padding=20, margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                    on_click=on_open,
                )
            )

        # --- Список блоков (только если не из «Бонуса») ---
        from_bonus = state.get("from_bonus", False)
        if not from_bonus:
            content_area.controls.append(ft.Container(height=20))
            content_area.controls.append(
                ft.Container(
                    content=ft.Text("Блоки", size=18, weight=ft.FontWeight.BOLD, color=TEXT),
                    padding=ft.padding.only(left=20, right=20, top=10, bottom=10),
                )
            )

            current_bid = user.get("current_block", 1)
            current_block = get_block(current_bid)

            if catchup_mode:
                # При catchup — блок 8 (открыт), текущий блок 11 (замок)
                block_8_obj = get_block(8)
                if block_8_obj:
                    render_block_card(block_8_obj, locked=False)
                if current_block:
                    render_block_card(current_block, locked=True)
            else:
                next_block = get_block(current_bid + 1)
                if current_block:
                    render_block_card(current_block, locked=False)
                if next_block:
                    render_block_card(next_block, locked=True)

    def get_comments_for_workout(workout_id):
        wid = str(workout_id)
        result = []
        for u in users:
            # Новый формат: список
            raw_list = u.get("comments_list", {}).get(wid, [])
            if raw_list:
                for comment in raw_list:
                    comment_text = comment.get("text", "")
                    media_list = comment.get("media_list", [])
                    if not comment_text.strip() and not media_list:
                        continue
                    media_items = []
                    for m in media_list:
                        path = m.get("path", "")
                        if path:
                            media_items.append({
                                "media": f"{SERVER_URL}{path}",
                                "media_type": m.get("media_type", ""),
                            })
                    photo_path = u.get("profile_photo", "")
                    photo_url = f"{SERVER_URL}{photo_path}" if photo_path else ""
                    result.append({
                        "user_id": u.get("id"),
                        "name": f"{u['first_name']} {u['last_name']}",
                        "text": comment_text,
                        "photo": photo_url,
                        "media_items": media_items,
                        "date": comment.get("date", ""),
                    })
                continue

            # Старый формат (один комментарий)
            raw = u.get("comments", {}).get(wid, "")
            if isinstance(raw, str):
                comment_text = raw
                media_list = []
            elif isinstance(raw, dict):
                comment_text = raw.get("text", "")
                media_list = raw.get("media_list", [])
                if not media_list and raw.get("media"):
                    media_list = [{
                        "path": raw.get("media", ""),
                        "media_type": raw.get("media_type", ""),
                    }]
            else:
                continue

            if not comment_text.strip() and not media_list:
                continue

            photo_path = u.get("profile_photo", "")
            photo_url = f"{SERVER_URL}{photo_path}" if photo_path else ""

            media_items = []
            for m in media_list:
                path = m.get("path", "")
                if path:
                    media_items.append({
                        "media": f"{SERVER_URL}{path}",
                        "media_type": m.get("media_type", ""),
                    })

            result.append({
                "user_id": u.get("id"),
                "name": f"{u['first_name']} {u['last_name']}",
                "text": comment_text,
                "photo": photo_url,
                "media_items": media_items,
            })
        return result
        
    def get_reactions_for_workout(workout_id):
        """Собирает реакции всех пользователей к тренировке."""
        wid = str(workout_id)
        counts = {"👍": 0, "❤️": 0, "💪": 0, "🔥": 0, "😊": 0, "😂": 0, "😮": 0, "😢": 0, "👎": 0, "💩": 0}
        for u in users:
            user_reaction = u.get("reactions", {}).get(wid, "")
            if user_reaction in counts:
                counts[user_reaction] += 1
        return counts

    def parse_workout_text(text):
        """Разбирает текст тренировки по формату Ламии."""
        import re
        blocks = []
        all_alt_exercises = []
        lines = text.split("\n")
        
        for line in lines:
            line = line.strip()
            if not line:
                blocks.append({"type": "space"})
                continue
            
            # --- Заголовок или указание в *звёздочках* ---
            match_star = re.match(r'^\*(.+)\*$', line)
            if match_star:
                content = match_star.group(1).strip()
                if any(w in content.lower() for w in ["круг", "сет", "подход", "раунд"]):
                    blocks.append({"type": "header", "text": content})
                else:
                    blocks.append({"type": "note", "text": content})
                continue
            
            # --- Замена ---
            if line.lower().startswith("замена"):
                clean = re.sub(r'^замена\s*:?\s*', '', line, flags=re.IGNORECASE).strip()
                parts = re.split(r'[,;]|\bлибо\b', clean)
                alt_items = []
                for part in parts:
                    part = part.strip().strip('«»"\'')
                    if not part:
                        continue
                    found = None
                    # Сортируем по длине — сначала длинные
                    sorted_ex = sorted(
                        exercises.items(),
                        key=lambda x: len(x[1].get("name", x[0])),
                        reverse=True
                    )
                    for key, ex in sorted_ex:
                        exact = ex.get("name", key)
                        name_norm = exact.lower().replace("ё", "е")
                        part_norm = part.lower().replace("ё", "е")
                        if name_norm in part_norm:
                            # Проверяем, не часть ли длинного
                            is_part = False
                            for other_key, other_ex in sorted_ex:
                                if other_key == key:
                                    continue
                                other_name = other_ex.get("name", other_key).lower().replace("ё", "е")
                                if other_name in part_norm and name_norm in other_name and len(other_name) > len(name_norm):
                                    is_part = True
                                    break
                            if is_part:
                                continue
                            found = {
                                "key": key,
                                "name": exact,
                                "video_url": ex.get("video_url", ""),
                            }
                            break
                    if found:
                        alt_items.append(found)
                if alt_items:
                    blocks.append({"type": "alt_block", "items": alt_items})
                    all_alt_exercises.extend(alt_items)   # ← добавляем
                continue
            
            # --- Упражнение или указание ---
            found_exercise = None
            sorted_exercises = sorted(
                exercises.items(),
                key=lambda x: len(x[1].get("name", x[0])),
                reverse=True
            )
            line_lower = line.lower().replace("ё", "е")
            
            for key, ex in sorted_exercises:
                exact_name = ex.get("name", key)
                name_normalized = exact_name.lower().replace("ё", "е")
                
                if name_normalized in line_lower:
                    is_part = False
                    for other_key, other_ex in sorted_exercises:
                        if other_key == key:
                            continue
                        other_name = other_ex.get("name", other_key).lower().replace("ё", "е")
                        if other_name in line_lower and name_normalized in other_name and len(other_name) > len(name_normalized):
                            is_part = True
                            break
                    if is_part:
                        continue
                    
                    match = re.search(r'(\d+(?:[/+]\d+)?)\s*(раз|сек|секунд|мин|минут)?', line_lower)
                    count_text = ""
                    if match:
                        number = match.group(1)
                        unit = match.group(2) or ""
                        if unit in ["сек", "секунд"]:
                            count_text = f"{number} сек"
                        elif unit in ["мин", "минут"]:
                            count_text = f"{number} мин"
                        elif unit == "раз":
                            count_text = f"{number} раз"
                        else:
                            count_text = number
                    
                    display_name = exact_name
                    if count_text:
                        display_name = f"{display_name} — {count_text}"
                    
                    found_exercise = {
                        "key": key,
                        "name": display_name,
                        "video_url": ex.get("video_url", ""),
                    }
                    break
            
            if found_exercise:
                blocks.append({"type": "exercise", "data": found_exercise})
            else:
                blocks.append({"type": "note", "text": line})
        
        return blocks, all_alt_exercises

    def find_exercises_in_text(text):
        """Ищет упражнения в тексте. Возвращает (основные, замены)."""
        import re
        main_found = []
        alt_found = []
        
        lines = text.split("\n")
        in_alternatives = False
        
        # Сортируем упражнения по длине названия — сначала длинные
        sorted_exercises = sorted(
            exercises.items(),
            key=lambda x: len(x[1].get("name", x[0])),
            reverse=True
        )
        
        for line in lines:
            line_lower = line.lower().replace("ё", "е")
            
            # Проверяем, начинается ли блок замен
            if "замена" in line_lower or "замены" in line_lower:
                in_alternatives = True
                line_lower = line_lower.replace("замена", "").replace("замены", "").strip()
                line = line.replace("Замена", "").replace("замена", "").replace("Замены", "").replace("замены", "").strip()
                line_lower = line.lower().replace("ё", "е")
            
            # Ищем упражнения в этой строке
            for key, ex in sorted_exercises:
                exact_name = ex.get("name", key)
                name_normalized = exact_name.lower().replace("ё", "е")
                
                if name_normalized in line_lower:
                    # Проверяем, не является ли это частью более длинного названия
                    is_part_of_longer = False
                    for other_key, other_ex in sorted_exercises:
                        if other_key == key:
                            continue
                        other_name = other_ex.get("name", other_key).lower().replace("ё", "е")
                        if other_name in line_lower and name_normalized in other_name and len(other_name) > len(name_normalized):
                            is_part_of_longer = True
                            break
                    
                    if is_part_of_longer:
                        continue
                    
                    # Извлекаем количество
                    match = re.search(r'(\d+(?:[/+]\d+)?)\s*(раз|сек|секунд|мин|минут)?', line_lower)
                    
                    count_text = ""
                    if match:
                        number = match.group(1)
                        unit = match.group(2) or ""
                        
                        if unit in ["сек", "секунд"]:
                            count_text = f"{number} сек"
                        elif unit in ["мин", "минут"]:
                            count_text = f"{number} мин"
                        elif unit == "раз":
                            count_text = f"{number} раз"
                        else:
                            count_text = number
                    
                    display_name = exact_name
                    if count_text:
                        display_name = f"{display_name} — {count_text}"
                    
                    item = {
                        "key": key,
                        "name": display_name,
                        "video_url": ex.get("video_url", ""),
                        "description": ex.get("description", ""),
                        "count": count_text,
                    }
                    
                    if in_alternatives:
                        alt_found.append(item)
                    else:
                        main_found.append(item)
                    
                    break
        
        return main_found, alt_found

    def render_block_detail(user):
        content_area.controls.clear()
        block = get_block(state.get("view_block"))
        if not block:
            return

        def go_back(e):
            state["screen"] = "auto"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text(block["title"], size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        done_map = user.get("done", {})

        level = user.get("level", "beginner")
        today_names = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"]
        today_idx = datetime.now().weekday()
        today_name = today_names[today_idx]

        for w in block["workouts"]:
            wid = str(w["id"])
            is_done = done_map.get(wid, False)

            # Для продвинутых: нельзя открыть тренировку позже сегодняшнего дня
            w_day = w.get("day", "")
            is_future = False
            if level == "advanced" and w_day in today_names:
                w_idx = today_names.index(w_day)
                if w_idx > today_idx:
                    is_future = True

            def open_workout(e, workout=w, future=is_future):
                if future:
                    snack = ft.SnackBar(ft.Text("Эта тренировка ещё не наступила"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    return
                block_workouts = block.get("workouts", [])
                try:
                    new_index = next(i for i, x in enumerate(block_workouts) if x["id"] == workout["id"])
                except StopIteration:
                    new_index = 0
                user["current_index"] = new_index
                state["from_block"] = True
                state["from_bonus"] = False
                server_save_users(users_data)
                state["screen"] = "auto"
                state["tab"] = "workouts"
                render()

            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Column([
                            ft.Text(f"{w['day']}", size=13, color=TEXT_MUTED),
                            ft.Text(f"{w['number']} ТРЕНИРОВКА", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                        ], spacing=2, expand=True),
                        ft.Icon(ft.Icons.LOCK_OUTLINE, color=TEXT_MUTED, size=22) if is_future else (ft.Icon(ft.Icons.CHECK_CIRCLE, color=PRIMARY, size=22) if is_done else ft.Icon(ft.Icons.CIRCLE_OUTLINED, color=TEXT_MUTED, size=22)),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    padding=16, margin=ft.margin.symmetric(horizontal=20, vertical=5),
                    border_radius=14, bgcolor=CARD, border=ft.border.all(1, BORDER),
                    on_click=open_workout,
                )
            )

    def render_general_chat(user):
        content_area.controls.clear()

        def go_back(e):
            state["screen"] = "auto"
            state["tab"] = "chat"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text("Общий чат", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        # Поле ввода
        message_field = ft.TextField(
            hint_text="Напиши сообщение...",
            bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
            hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
            expand=True, multiline=False,
        )

        def send_message(e):
            text = message_field.value.strip()
            if not text:
                return
            snack = ft.SnackBar(ft.Text("Сообщение отправлено!"))
            page.overlay.append(snack)
            snack.open = True
            page.update()
            message_field.value = ""
            page.update()

        send_button = ft.Button(
            content=ft.Icon(ft.Icons.SEND, color=PRIMARY_FG, size=20),
            on_click=send_message,
            style=ft.ButtonStyle(
                bgcolor=PRIMARY, color=PRIMARY_FG,
                shape=ft.RoundedRectangleBorder(radius=12),
                padding=ft.padding.symmetric(vertical=14, horizontal=16),
            ),
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Row([message_field, send_button], spacing=8),
                padding=ft.padding.symmetric(horizontal=20, vertical=10),
            )
        )

        # Заглушка — сообщения появятся после Amvera
        content_area.controls.append(
            ft.Container(
                content=ft.Text(
                    "Здесь будут сообщения всех участниц 💜",
                    size=14, color=TEXT_MUTED,
                    text_align=ft.TextAlign.CENTER,
                ),
                padding=30,
                alignment=ft.alignment.center,
            )
        )

    def render_trainer_chat(user):
        content_area.controls.clear()

        def go_back(e):
            state["screen"] = "auto"
            state["tab"] = "chat"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text("Чат с тренером", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        message_field = ft.TextField(
            hint_text="Напиши сообщение Ламие...",
            bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
            hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
            expand=True, multiline=False,
        )

        def send_message(e):
            text = message_field.value.strip()
            if not text:
                return
            snack = ft.SnackBar(ft.Text("Сообщение отправлено!"))
            page.overlay.append(snack)
            snack.open = True
            page.update()
            message_field.value = ""
            page.update()

        send_button = ft.Button(
            content=ft.Icon(ft.Icons.SEND, color=PRIMARY_FG, size=20),
            on_click=send_message,
            style=ft.ButtonStyle(
                bgcolor=PRIMARY, color=PRIMARY_FG,
                shape=ft.RoundedRectangleBorder(radius=12),
                padding=ft.padding.symmetric(vertical=14, horizontal=16),
            ),
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Row([message_field, send_button], spacing=8),
                padding=ft.padding.symmetric(horizontal=20, vertical=10),
            )
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Text(
                    "Задай вопрос Ламие — она ответит, когда сможет 💜",
                    size=14, color=TEXT_MUTED,
                    text_align=ft.TextAlign.CENTER,
                ),
                padding=30,
                alignment=ft.alignment.center,
            )
        )

    def render_bonus_stretch(user):
        content_area.controls.clear()

        def go_back(e):
            state["screen"] = "auto"
            state["tab"] = "bonus"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text("Растяжка", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        # Заглушка — Ламия добавит контент через админку позже
        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Icon(ft.Icons.SELF_IMPROVEMENT, color=PRIMARY, size=64),
                    ft.Text(
                        "Здесь будет тренировка на растяжку",
                        size=16, color=TEXT_MUTED,
                        text_align=ft.TextAlign.CENTER,
                    ),
                ], spacing=15, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                padding=40,
                alignment=ft.alignment.center,
            )
        )

    def render_bonus_view(user):
        content_area.controls.clear()
        bw = state.get("view_bonus")
        if not bw:
            return

        def go_back(e):
            state["screen"] = "auto"
            state["tab"] = "bonus"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text(bw.get("title", "Бонус"), size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text(bw.get("text", ""), size=15, color=TEXT),
                    ft.Container(height=15),
                    ft.Button(
                        content=ft.Text("▶  Смотреть видео", size=16, weight=ft.FontWeight.BOLD),
                        url=bw.get("video_url", ""),
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY, color=PRIMARY_FG,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=16),
                        ),
                    ) if bw.get("video_url") else ft.Text("Видео скоро", size=13, color=TEXT_MUTED),
                ], spacing=10),
                padding=20,
                margin=ft.margin.symmetric(horizontal=20, vertical=10),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )

    def render_bonus_tab(user):
        content_area.controls.clear()

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("Бонус", size=24, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Text("Дополнительные тренировки для тебя", size=14, color=TEXT_MUTED),
                ], spacing=4),
                padding=ft.padding.only(left=20, right=20, top=20, bottom=10),
            )
        )

        # --- Растяжка (всегда) ---
        def open_stretch(e):
            state["screen"] = "bonus_stretch"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Container(
                        content=ft.Icon(ft.Icons.SELF_IMPROVEMENT, color=PRIMARY, size=28),
                        width=50, height=50, border_radius=25, bgcolor=CARD_SOFT,
                        alignment=ft.alignment.center,
                    ),
                    ft.Column([
                        ft.Text("Растяжка", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                        ft.Text("Всегда доступна", size=13, color=TEXT_MUTED),
                    ], spacing=2, expand=True),
                    ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=24),
                ], spacing=14),
                padding=18,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                on_click=open_stretch,
            )
        )

        # --- Для продвинутых: 5 невыполненных из блоков 9 … (текущий - 1) ---
        level = user.get("level", "beginner")

        if level == "advanced":
            done_map = user.get("done", {})
            skipped_map = user.get("skipped", {})
            current_block_id = get_current_block_id()

            all_blocks = sorted(data.get("blocks", []), key=lambda b: b["id"])

            bonus_blocks = [
                b for b in all_blocks
                if b.get("level") == "advanced" and b["id"] < current_block_id
            ]

            # Собираем пул всех невыполненных
            pool = []
            for b in bonus_blocks:
                workouts_b = sorted(b.get("workouts", []), key=lambda x: x["number"])
                for w in workouts_b:
                    wid_w = str(w["id"])
                    if done_map.get(wid_w, False) or skipped_map.get(wid_w, False):
                        continue
                    pool.append((b, w))

            # Показываем первые 5
            for b, w in pool[:5]:
                wid_w = str(w["id"])

                def make_open_bonus(workout=w, block_id=b["id"]):
                    def handler(e):
                        user["current_block"] = block_id
                        block_obj = get_block(block_id)
                        if block_obj:
                            block_workouts = block_obj.get("workouts", [])
                            try:
                                new_index = next(i for i, x in enumerate(block_workouts) if x["id"] == workout["id"])
                            except StopIteration:
                                new_index = 0
                            user["current_index"] = new_index
                        state["from_block"] = True
                        state["from_bonus"] = True
                        state["force_scroll"] = True
                        server_save_users(users_data)
                        state["screen"] = "auto"
                        state["tab"] = "workouts"
                        render()
                    return handler

                status_icon = ft.Icon(ft.Icons.CIRCLE_OUTLINED, color=TEXT_MUTED, size=22)

                content_area.controls.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Container(
                                content=ft.Text(str(w.get("number", "?")), size=18, weight=ft.FontWeight.BOLD, color=PRIMARY_FG),
                                width=44, height=44, border_radius=22,
                                bgcolor=PRIMARY, alignment=ft.alignment.center,
                            ),
                            ft.Column([
                                ft.Text(f"Блок {b['id']} · Тренировка {w.get('number', '?')}", size=15, weight=ft.FontWeight.BOLD, color=TEXT),
                                ft.Text(w.get("day", ""), size=13, color=TEXT_MUTED),
                            ], spacing=2, expand=True),
                            status_icon,
                        ], spacing=12, vertical_alignment=ft.CrossAxisAlignment.CENTER),
                        padding=14,
                        margin=ft.margin.symmetric(horizontal=20, vertical=4),
                        border_radius=16, bgcolor=CARD, border=ft.border.all(1, BORDER),
                        on_click=make_open_bonus(),
                    )
                )

            # Если пул пуст
            if not pool:
                content_area.controls.append(
                    ft.Container(
                        content=ft.Text(
                            "Все бонусные тренировки выполнены! 💜",
                            size=14, color=TEXT_MUTED,
                            text_align=ft.TextAlign.CENTER,
                        ),
                        padding=ft.padding.symmetric(horizontal=20, vertical=15),
                        alignment=ft.alignment.center,
                    )
                )

        # --- Табата (если есть) ---
        bonus_workouts = data.get("bonus_workouts", [])
        
        for bw in bonus_workouts:
            def make_open(bonus_item):
                def handler(e):
                    state["screen"] = "bonus_view"
                    state["view_bonus"] = bonus_item
                    render()
                return handler

            icon = ft.Icons.LOCAL_FIRE_DEPARTMENT if "табата" in bw.get("title", "").lower() else ft.Icons.FITNESS_CENTER

            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Container(
                            content=ft.Icon(icon, color=PRIMARY, size=28),
                            width=50, height=50, border_radius=25, bgcolor=CARD_SOFT,
                            alignment=ft.alignment.center,
                        ),
                        ft.Column([
                            ft.Text(bw.get("title", "Бонусная тренировка"), size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                            ft.Text(bw.get("subtitle", ""), size=13, color=TEXT_MUTED),
                        ], spacing=2, expand=True),
                        ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=24),
                    ], spacing=14),
                    padding=18,
                    margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                    on_click=make_open(bw),
                )
            )

        # Если бонусных тренировок нет
        if not bonus_workouts:
            content_area.controls.append(
                ft.Container(
                    content=ft.Text(
                        "Скоро здесь появятся новые бонусные тренировки 💜",
                        size=14, color=TEXT_MUTED,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    padding=ft.padding.symmetric(horizontal=20, vertical=15),
                    alignment=ft.alignment.center,
                )
            )

       # ---------- ЧАТ ----------

    def render_chat_tab(user):
        content_area.controls.clear()

        content_area.controls.append(
            ft.Container(
                content=ft.Text("Чат", size=24, weight=ft.FontWeight.BOLD, color=TEXT),
                padding=ft.padding.only(left=20, right=20, top=20, bottom=10),
            )
        )

        # --- Общий чат ---
        def open_general_chat(e):
            state["screen"] = "general_chat"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.FORUM_OUTLINED, color=PRIMARY, size=28),
                        ft.Column([
                            ft.Text("Общий чат", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                            ft.Text("Общайся со всеми участницами", size=13, color=TEXT_MUTED),
                        ], spacing=2, expand=True),
                        ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=24),
                    ], spacing=14),
                ]),
                padding=20,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                on_click=open_general_chat,
            )
        )

        # --- Чат с тренером ---
        def open_trainer_chat(e):
            state["screen"] = "trainer_chat"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.SUPPORT_AGENT, color=PRIMARY, size=28),
                        ft.Column([
                            ft.Text("Чат с тренером", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                            ft.Text("Задай вопрос лично тренеру", size=13, color=TEXT_MUTED),
                        ], spacing=2, expand=True),
                        ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=24),
                    ], spacing=14),
                ]),
                padding=20,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                on_click=open_trainer_chat,
            )
        )
        
        # --- Позвонить тренеру ---
        def call_trainer(e):
            page.launch_url(f"tel:{PAYMENT_PHONE}")

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.PHONE, color=PRIMARY, size=28),
                        ft.Column([
                            ft.Text("Позвонить тренеру", size=17, weight=ft.FontWeight.BOLD, color=TEXT),
                            ft.Text(PAYMENT_PHONE, size=13, color=TEXT_MUTED),
                        ], spacing=2, expand=True),
                        ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=24),
                    ], spacing=14),
                ]),
                padding=20,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                on_click=call_trainer,
            )
        )        

    def render_theory_item(user):
        content_area.controls.clear()

        idx = state.get("theory_index", 0)
        if idx < 0 or idx >= len(THEORY_ITEMS):
            return

        item = THEORY_ITEMS[idx]

        def go_back(e):
            state["screen"] = "auto"
            state["tab"] = "theory"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.IconButton(ft.Icons.ARROW_BACK, icon_color=TEXT, on_click=go_back),
                    ft.Text(item["title"], size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                ]),
                padding=ft.padding.only(left=10, right=20, top=15, bottom=10),
            )
        )

        # --- Если это чек-лист ---
        if item.get("checklist"):
            inventory_checked = user.setdefault("inventory_checked", {})
            # Берём инвентарь из inventory.json
            items = inventory_items if inventory_items else []

            def on_check(e, key):
                inventory_checked[key] = e.control.value
                server_save_users(users_data)
                render()

            for inv_item in items:
                inv_key = inv_item["key"]
                inv_label = inv_item["label"]
                is_checked = inventory_checked.get(inv_key, False)
                content_area.controls.append(
                    ft.Container(
                        content=ft.Checkbox(
                            value=is_checked,
                            label=inv_label,
                            on_change=lambda e, k=inv_key: on_check(e, k),
                            fill_color=PRIMARY,
                            check_color=PRIMARY_FG,
                            label_style=ft.TextStyle(color=TEXT, size=15),
                        ),
                        padding=ft.padding.symmetric(horizontal=16, vertical=8),
                        margin=ft.margin.symmetric(horizontal=20, vertical=4),
                        border_radius=14,
                        bgcolor=CARD,
                        border=ft.border.all(2, PRIMARY if is_checked else BORDER),
                    )
                )

            # --- Если всё отмечено ---
            all_checked = all(inventory_checked.get(x["key"], False) for x in items)
            if all_checked:
                content_area.controls.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Icon(ft.Icons.CHECK_CIRCLE, color=MINT, size=36),
                            ft.Text(
                                "Отлично, всё есть! 💜",
                                size=16, weight=ft.FontWeight.BOLD, color=TEXT,
                                text_align=ft.TextAlign.CENTER,
                            ),
                        ], spacing=6, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                        padding=20,
                        margin=ft.margin.symmetric(horizontal=20, vertical=10),
                        border_radius=14, bgcolor=CARD_SOFT, border=ft.border.all(2, MINT),
                    )
                )

            # --- Инфо-блок 1: список может пополняться ---
            if item.get("note_after_checklist"):
                content_area.controls.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Icon(ft.Icons.INFO_OUTLINE, color=PRIMARY, size=18),
                            ft.Text(
                                item["note_after_checklist"],
                                size=13, color=TEXT_MUTED, expand=True,
                            ),
                        ], spacing=8),
                        padding=ft.padding.symmetric(horizontal=20, vertical=12),
                        margin=ft.margin.symmetric(horizontal=20, vertical=6),
                        border_radius=12, bgcolor=CARD_SOFT, border=ft.border.all(1, BORDER),
                    )
                )

            # --- Ссылки на покупку ---
            links_items = []
            for inv in items:
                # Поддерживаем и новый (links), и старый (url) формат
                inv_links = inv.get("links", [])
                if not inv_links and inv.get("url"):
                    inv_links = [{"url": inv.get("url", ""), "promo": inv.get("promo", "")}]

                for link in inv_links:
                    url = link.get("url", "").strip()
                    promo = link.get("promo", "").strip()
                    if url:
                        title = f"{inv['label']} · промокод {promo}" if promo else inv["label"]
                        links_items.append(
                            ft.Button(
                                content=ft.Text(title, size=13, weight=ft.FontWeight.BOLD),
                                url=url,
                                style=ft.ButtonStyle(
                                    bgcolor=CARD_SOFT, color=TEXT,
                                    shape=ft.RoundedRectangleBorder(radius=10),
                                    padding=ft.padding.symmetric(vertical=10, horizontal=14),
                                ),
                            )
                        )

            if links_items:
                content_area.controls.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Row([
                                ft.Icon(ft.Icons.SHOPPING_CART, color=PRIMARY, size=20),
                                ft.Text("Где купить", size=15, weight=ft.FontWeight.BOLD, color=TEXT),
                            ], spacing=8),
                            ft.Container(height=10),
                        ] + links_items, spacing=6),
                        padding=16,
                        margin=ft.margin.symmetric(horizontal=20, vertical=10),
                        border_radius=14, bgcolor=CARD, border=ft.border.all(1, BORDER),
                    )
                )

            # --- Инфо-блок 2: это пример + промокоды ---
            if item.get("note_after_links"):
                content_area.controls.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Icon(ft.Icons.INFO_OUTLINE, color=PRIMARY, size=18),
                            ft.Text(
                                item["note_after_links"],
                                size=13, color=TEXT_MUTED, expand=True,
                            ),
                        ], spacing=8),
                        padding=ft.padding.symmetric(horizontal=20, vertical=12),
                        margin=ft.margin.symmetric(horizontal=20, vertical=6),
                        border_radius=12, bgcolor=CARD_SOFT, border=ft.border.all(1, BORDER),
                    )
                )

            return

        # --- Обычный текст (для других пунктов) ---
        text_lines = item.get("text", "").split("\n")
        text_widgets = []
        for line in text_lines:
            line = line.strip()
            if not line:
                text_widgets.append(ft.Container(height=6))
            else:
                text_widgets.append(
                    ft.Text(line, size=14, color=TEXT_MUTED)
                )

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text(item.get("subtitle", ""), size=14, color=PRIMARY, weight=ft.FontWeight.BOLD),
                    ft.Container(height=10),
                ] + text_widgets, spacing=4),
                padding=20,
                margin=ft.margin.symmetric(horizontal=20, vertical=10),
                border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
            )
        )

        # --- Видео ---
        if item.get("video_url", "").strip():
            content_area.controls.append(
                ft.Container(
                    content=ft.Button(
                        content=ft.Text("▶  Смотреть видео", size=16, weight=ft.FontWeight.BOLD),
                        url=item["video_url"],
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY, color=PRIMARY_FG,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=16),
                        ),
                        width=340,
                    ),
                    padding=ft.padding.symmetric(horizontal=20, vertical=10),
                    alignment=ft.alignment.center,
                )
            )
        
    def render_theory_tab(user):
        content_area.controls.clear()

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("Теория", size=24, weight=ft.FontWeight.BOLD, color=TEXT),
                    ft.Text("Виды тренировок и их описание", size=14, color=TEXT_MUTED),
                ], spacing=4),
                padding=ft.padding.only(left=20, right=20, top=20, bottom=10),
            )
        )

        for i, item in enumerate(THEORY_ITEMS):
            def make_open(idx):
                def open_item(e):
                    state["theory_index"] = idx
                    state["screen"] = "theory_item"
                    render()
                return open_item

            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.ARTICLE_OUTLINED, color=PRIMARY, size=24),
                        ft.Text(
                            item["title"],
                            size=17, weight=ft.FontWeight.BOLD, color=TEXT,
                            expand=True,
                        ),
                        ft.Icon(ft.Icons.CHEVRON_RIGHT, color=PRIMARY, size=24),
                    ], spacing=14),
                    padding=18,
                    margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=18, bgcolor=CARD, border=ft.border.all(1, BORDER),
                    on_click=make_open(i),
                )
            )

    def render_admin_exercises():
        
        # Какое упражнение сейчас редактируется
        editing_key = state.get("editing_exercise_key", None)        
        
        """Раздел админки: упражнения и видео."""
        search_query = state.get("exercise_search", "").strip().lower()

        search_value = state.get("exercise_search", "")

        search_field = ft.TextField(
            value=search_value,
            hint_text="Поиск упражнения...",
            bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
            hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
            text_size=14,
            expand=True,
        )

        def on_search(e):
            state["exercise_search"] = search_field.value.strip()
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    search_field,
                    ft.Button(
                        content=ft.Text("Найти", size=14, weight=ft.FontWeight.BOLD),
                        on_click=on_search,
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY, color=PRIMARY_FG,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=14, horizontal=20),
                        ),
                    ),
                ], spacing=10),
                padding=ft.padding.symmetric(horizontal=20, vertical=10),
            )
        )

        show_add_form = state.get("show_add_exercise_form", False)

        def toggle_add_form(e):
            state["show_add_exercise_form"] = not show_add_form
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Container(height=10),
                    ft.Button(
                        content=ft.Text(
                            "✕ Закрыть" if show_add_form else "+ Добавить упражнение",
                            size=15, weight=ft.FontWeight.BOLD,
                        ),
                        on_click=toggle_add_form,
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY if not show_add_form else CARD_SOFT,
                            color=PRIMARY_FG if not show_add_form else TEXT,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=14, horizontal=20),
                        ),
                    ),
                ], spacing=0),
                padding=ft.padding.symmetric(horizontal=20, vertical=10),
            )
        )

        # --- Форма добавления ---
        if show_add_form:
            name_field = ft.TextField(
                hint_text="Название (например: Приседания)",
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=13,
            )
            url_field_add = ft.TextField(
                hint_text="Ссылка на видео (https://...)",
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=13,
            )

            def submit_add(e):
                name = name_field.value.strip()
                url = url_field_add.value.strip()
                if not name:
                    snack = ft.SnackBar(ft.Text("Введите название"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    return

                ok = server_add_exercise(name, url)
                if ok:
                    snack = ft.SnackBar(ft.Text(f"Упражнение «{name}» добавлено"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    state["show_add_exercise_form"] = False

                    # Перезагружаем
                    new_ex = server_get_exercises()
                    if new_ex:
                        exercises_data.clear()
                        exercises_data.update(new_ex)
                        exercises.clear()
                        exercises.update(new_ex.get("exercises", {}))
                    render()
                else:
                    snack = ft.SnackBar(ft.Text("Ошибка: возможно, такое упражнение уже есть"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()

            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text("Название:", size=14, color=TEXT_MUTED),
                        name_field,
                        ft.Container(height=8),
                        ft.Text("Ссылка на видео:", size=14, color=TEXT_MUTED),
                        url_field_add,
                        ft.Container(height=15),
                        ft.Button(
                            content=ft.Text("Сохранить", size=15, weight=ft.FontWeight.BOLD),
                            on_click=submit_add,
                            style=ft.ButtonStyle(
                                bgcolor=PRIMARY, color=PRIMARY_FG,
                                shape=ft.RoundedRectangleBorder(radius=12),
                                padding=ft.padding.symmetric(vertical=14, horizontal=24),
                            ),
                        ),
                    ], spacing=4),
                    padding=20,
                    margin=ft.margin.symmetric(horizontal=20, vertical=10),
                    border_radius=16, bgcolor=CARD, border=ft.border.all(2, PRIMARY),
                )
            )

        # --- Список упражнений (с учётом поиска) ---
        editing_key = state.get("editing_exercise_key", None)

        for key, ex in exercises.items():
            name = ex.get("name", key)
            if search_query and search_query not in name.lower() and search_query not in key.lower():
                continue

            is_editing = editing_key == key

            def make_save_handler(k, ex_item):
                def save(e):
                    new_url = url_field.value.strip()
                    exercises[k]["video_url"] = new_url
                    exercises_data["exercises"] = exercises
                    server_save_exercises(exercises_data)
                    snack = ft.SnackBar(ft.Text(f"Сохранено: {ex_item['name']}"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                return save

            def make_delete_handler(k, ex_item):
                def delete(e):
                    ok = server_delete_exercise(k)
                    if ok:
                        snack = ft.SnackBar(ft.Text(f"Удалено: {ex_item['name']}"))
                        page.overlay.append(snack)
                        snack.open = True
                        page.update()

                        new_ex = server_get_exercises()
                        if new_ex:
                            exercises_data.clear()
                            exercises_data.update(new_ex)
                            exercises.clear()
                            exercises.update(new_ex.get("exercises", {}))
                        render()
                    else:
                        snack = ft.SnackBar(ft.Text("Ошибка: не удалось удалить"))
                        page.overlay.append(snack)
                        snack.open = True
                        page.update()
                return delete

            # Загрузка своего видео
            ex_key = key
            def make_upload_handler(k):
                def handler(e):
                    if not e.files:
                        return
                    file = e.files[0]
                    result = server_upload_exercise_video(k, file.path, file.name)
                    if result:
                        exercises[k]["video_file"] = result
                        exercises_data["exercises"] = exercises
                        server_save_exercises(exercises_data)
                        snack = ft.SnackBar(ft.Text("Видео загружено!"))
                        page.overlay.append(snack)
                        snack.open = True
                        page.update()
                        render()
                return handler

            video_picker = ft.FilePicker(on_result=make_upload_handler(ex_key))
            page.overlay.append(video_picker)

            upload_btn = ft.IconButton(
                ft.Icons.UPLOAD_FILE,
                icon_color=PRIMARY,
                icon_size=20,
                on_click=lambda e: video_picker.pick_files(
                    dialog_title="Выбери видео",
                    allow_multiple=False,
                    file_type=ft.FilePickerFileType.VIDEO,
                ),
                tooltip="Загрузить видео",
            )

            url_field = ft.TextField(
                value=ex.get("video_url", ""),
                hint_text="https://...",
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=13,
            )

            # --- Название (с ручкой или полем редактирования) ---
            if is_editing:
                name_field = ft.TextField(
                    value=name,
                    bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                    border_radius=12,
                    text_size=14,
                    expand=True,
                )

                def make_save_name(k, nf):
                    def save_name(e):
                        new_name = nf.value.strip()
                        if not new_name:
                            return
                        ok = server_rename_exercise(k, new_name)
                        if ok:
                            snack = ft.SnackBar(ft.Text(f"Переименовано: {new_name}"))
                            page.overlay.append(snack)
                            snack.open = True
                            page.update()
                            state["editing_exercise_key"] = None
                            new_ex = server_get_exercises()
                            if new_ex:
                                exercises_data.clear()
                                exercises_data.update(new_ex)
                                exercises.clear()
                                exercises.update(new_ex.get("exercises", {}))
                            render()
                    return save_name

                def cancel_edit(e):
                    state["editing_exercise_key"] = None
                    render()

                name_row = ft.Row([
                    name_field,
                    ft.IconButton(
                        ft.Icons.CHECK, icon_color=MINT, icon_size=20,
                        on_click=make_save_name(key, name_field),
                    ),
                    ft.IconButton(
                        ft.Icons.CLOSE, icon_color=DANGER, icon_size=20,
                        on_click=cancel_edit,
                    ),
                ], spacing=4)
            else:
                def start_edit(e, k=key):
                    state["editing_exercise_key"] = k
                    render()

                name_row = ft.Row([
                    ft.Text(name, size=16, weight=ft.FontWeight.BOLD, color=TEXT, expand=True),
                    ft.IconButton(
                        ft.Icons.EDIT, icon_color=PRIMARY, icon_size=20,
                        on_click=start_edit,
                        tooltip="Редактировать название",
                    ),
                ], spacing=4)

            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        name_row,
                        ft.Text(f"Код: {key}", size=12, color=TEXT_MUTED),
                        ft.Container(height=6),
                        ft.Row([
                            ft.Container(content=url_field, expand=True),
                            upload_btn,
                        ], spacing=6),
                        ft.Container(height=6),
                        ft.Row([
                            ft.Button(
                                content=ft.Text("Сохранить", size=13, weight=ft.FontWeight.BOLD),
                                on_click=make_save_handler(key, ex),
                                style=ft.ButtonStyle(
                                    bgcolor=PRIMARY, color=PRIMARY_FG,
                                    shape=ft.RoundedRectangleBorder(radius=10),
                                    padding=ft.padding.symmetric(vertical=10, horizontal=16),
                                ),
                            ),
                            ft.Button(
                                content=ft.Text("▶ Проверить", size=13),
                                url=ex.get("video_url", ""),
                                style=ft.ButtonStyle(
                                    bgcolor=CARD_SOFT, color=TEXT,
                                    shape=ft.RoundedRectangleBorder(radius=10),
                                    padding=ft.padding.symmetric(vertical=10, horizontal=16),
                                ),
                            ),
                            ft.Button(
                                content=ft.Text("Удалить", size=13),
                                on_click=make_delete_handler(key, ex),
                                style=ft.ButtonStyle(
                                    bgcolor=CARD_SOFT, color=DANGER,
                                    shape=ft.RoundedRectangleBorder(radius=10),
                                    padding=ft.padding.symmetric(vertical=10, horizontal=16),
                                ),
                            ),
                        ], spacing=8),
                    ], spacing=4),
                    padding=16,
                    margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=14, bgcolor=CARD, border=ft.border.all(1, BORDER),
                )
            )

    def render_admin_workouts():
        """Раздел админки: тренировки."""

        # --- Форма добавления ---
        show_form = state.get("show_workout_form", False)

        def toggle_form(e):
            state["show_workout_form"] = not show_form
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Button(
                    content=ft.Text(
                        "✕ Закрыть" if show_form else "+ Добавить тренировку",
                        size=15, weight=ft.FontWeight.BOLD,
                    ),
                    on_click=toggle_form,
                    style=ft.ButtonStyle(
                        bgcolor=PRIMARY if not show_form else CARD_SOFT,
                        color=PRIMARY_FG if not show_form else TEXT,
                        shape=ft.RoundedRectangleBorder(radius=12),
                        padding=ft.padding.symmetric(vertical=14, horizontal=20),
                    ),
                ),
                padding=ft.padding.symmetric(horizontal=20, vertical=10),
            )
        )

        if show_form:
            text_field = ft.TextField(
                hint_text="Берпи 20 раз, Приседания 20 раз...",
                multiline=True,
                min_lines=3,
                max_lines=6,
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
            )         

            # Выбор блока
            block_ids = [b["id"] for b in blocks]
            selected_block = state.get("new_workout_block", block_ids[0] if block_ids else 1)

            def select_block(bid):
                state["new_workout_block"] = bid
                render()

            def add_block_and_select(e):
                result = server_add_block()
                if result:
                    new_data = server_get_data()
                    if new_data:
                        data.clear()
                        data.update(new_data)
                        blocks.clear()
                        blocks.extend(new_data.get("blocks", []))

                    state["new_workout_block"] = result["id"]
                    state["new_workout_number"] = 1
                    state["show_workout_form"] = True
                    render()

            block_buttons = []
            for bid in block_ids:
                is_active = selected_block == bid
                block_buttons.append(
                    ft.Button(
                        content=ft.Text(f"Блок {bid}", size=13, weight=ft.FontWeight.BOLD),
                        on_click=lambda e, b=bid: select_block(b),
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY if is_active else CARD_SOFT,
                            color=PRIMARY_FG if is_active else TEXT,
                            shape=ft.RoundedRectangleBorder(radius=10),
                            padding=ft.padding.symmetric(vertical=10, horizontal=14),
                        ),
                    )
                )

            # Кнопка "+" для нового блока
            block_buttons.append(
                ft.Button(
                    content=ft.Text("+", size=18, weight=ft.FontWeight.BOLD),
                    on_click=add_block_and_select,
                    style=ft.ButtonStyle(
                        bgcolor=MINT, color=PRIMARY_FG,
                        shape=ft.RoundedRectangleBorder(radius=10),
                        padding=ft.padding.symmetric(vertical=8, horizontal=16),
                    ),
                )
            )

            # Выбор номера (1–5)
            selected_number = state.get("new_workout_number", 1)

            def select_number(n):
                state["new_workout_number"] = n
                render()

            number_buttons = []
            for n in [1, 2, 3, 4, 5]:
                is_active = selected_number == n
                number_buttons.append(
                    ft.Button(
                        content=ft.Text(str(n), size=13, weight=ft.FontWeight.BOLD),
                        on_click=lambda e, num=n: select_number(num),
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY if is_active else CARD_SOFT,
                            color=PRIMARY_FG if is_active else TEXT,
                            shape=ft.RoundedRectangleBorder(radius=10),
                            padding=ft.padding.symmetric(vertical=10, horizontal=14),
                        ),
                    )
                )

            # Проверяем, есть ли уже тренировка с таким номером
            existing_workout = None
            for b in blocks:
                if b["id"] == selected_block:
                    for w in b.get("workouts", []):
                        if w["number"] == selected_number:
                            existing_workout = w
                            break
                    break

            if existing_workout:
                text_field.value = existing_workout.get("text", "")
                
            video_url_field = ft.TextField(
                value=existing_workout.get("video_url", "") if existing_workout else "",
                hint_text="Ссылка на видео (https://...)",
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=13,
            )
            audio_url_field = ft.TextField(
                value=existing_workout.get("audio_url", "") if existing_workout else "",
                hint_text="Ссылка на голосовое (https://...)",
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=13,
            )                   

            def submit(e):
                txt = text_field.value.strip()
                if not txt:
                    snack = ft.SnackBar(ft.Text("Введите текст тренировки"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    return

                result = server_save_workout(selected_block, selected_number, txt, video_url_field.value.strip(), audio_url_field.value.strip())
                if result:
                    snack = ft.SnackBar(ft.Text(f"Тренировка сохранена (Блок {selected_block}, №{selected_number})"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    state["show_workout_form"] = False

                    new_data = server_get_data()
                    if new_data:
                        data.clear()
                        data.update(new_data)
                        blocks.clear()
                        blocks.extend(new_data.get("blocks", []))
                    render()
                else:
                    snack = ft.SnackBar(ft.Text("Ошибка: не удалось сохранить"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()

            def delete(e):
                ok = server_delete_workout(selected_block, selected_number)
                if ok:
                    snack = ft.SnackBar(ft.Text(f"Тренировка удалена (Блок {selected_block}, №{selected_number})"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    state["show_workout_form"] = False

                    new_data = server_get_data()
                    if new_data:
                        data.clear()
                        data.update(new_data)
                        blocks.clear()
                        blocks.extend(new_data.get("blocks", []))
                    render()
                else:
                    snack = ft.SnackBar(ft.Text("Ошибка: не удалось удалить"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()

            # Проверяем, пустой ли блок
            selected_block_data = None
            for b in blocks:
                if b["id"] == selected_block:
                    selected_block_data = b
                    break

            is_block_empty = (
                selected_block_data is not None
                and len(selected_block_data.get("workouts", [])) == 0
            )
            
            def delete_block(e):
                ok = server_delete_block(selected_block)
                if ok:
                    snack = ft.SnackBar(ft.Text(f"Блок {selected_block} удалён"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()

                    new_data = server_get_data()
                    if new_data:
                        data.clear()
                        data.update(new_data)
                        blocks.clear()
                        blocks.extend(new_data.get("blocks", []))

                    # Выбираем первый оставшийся блок
                    if blocks:
                        state["new_workout_block"] = blocks[0]["id"]
                    state["new_workout_number"] = 1
                    render()
                else:
                    snack = ft.SnackBar(ft.Text("Ошибка: не удалось удалить блок"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()

            buttons_row = [
                ft.Button(
                    content=ft.Text("Сохранить", size=15, weight=ft.FontWeight.BOLD),
                    on_click=submit,
                    style=ft.ButtonStyle(
                        bgcolor=PRIMARY, color=PRIMARY_FG,
                        shape=ft.RoundedRectangleBorder(radius=12),
                        padding=ft.padding.symmetric(vertical=14, horizontal=24),
                    ),
                ),
            ]

            # Кнопка "Удалить блок" (всегда)
            buttons_row.append(
                ft.Button(
                    content=ft.Text("Удалить блок", size=15, weight=ft.FontWeight.BOLD),
                    on_click=delete_block,
                    style=ft.ButtonStyle(
                        bgcolor=CARD_SOFT, color=DANGER,
                        shape=ft.RoundedRectangleBorder(radius=12),
                        padding=ft.padding.symmetric(vertical=14, horizontal=24),
                    ),
                )
            )

            # Если тренировка уже есть — "Удалить тренировку"
            if existing_workout:
                buttons_row.append(
                    ft.Button(
                        content=ft.Text("Удалить тренировку", size=15, weight=ft.FontWeight.BOLD),
                        on_click=delete,
                        style=ft.ButtonStyle(
                            bgcolor=CARD_SOFT, color=DANGER,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=14, horizontal=24),
                        ),
                    )
                )

            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text("Блок:", size=14, color=TEXT_MUTED),
                        ft.Row(block_buttons, spacing=8, wrap=True),
                        ft.Container(height=8),
                        ft.Text("Номер тренировки:", size=14, color=TEXT_MUTED),
                        ft.Row(number_buttons, spacing=8),
                        ft.Container(height=12),
                        ft.Text(
                            "⚠ Тренировка уже есть — можно заменить или удалить" if existing_workout else "Тренировка пустая — можно добавить",
                            size=13,
                            color=BLUSH if existing_workout else MINT,
                            weight=ft.FontWeight.BOLD,
                        ),
                        ft.Container(height=8),
                        ft.Text("Текст тренировки:", size=14, color=TEXT_MUTED),
                        text_field,
                        ft.Container(height=8),
                        ft.Text("Ссылка на видео:", size=14, color=TEXT_MUTED),
                        video_url_field,
                        ft.Container(height=8),
                        ft.Text("Ссылка на голосовое:", size=14, color=TEXT_MUTED),
                        audio_url_field,
                        ft.Container(height=15),
                        ft.Row(buttons_row, spacing=10),
                    ], spacing=6),
                    padding=20,
                    margin=ft.margin.symmetric(horizontal=20, vertical=10),
                    border_radius=16, bgcolor=CARD, border=ft.border.all(2, PRIMARY),
                )
            )

        # --- Список блоков (раскрывающиеся) ---
        expanded_blocks = state.setdefault("expanded_blocks", set())

        # --- Вводная тренировка ---
        intro_expanded = "intro" in expanded_blocks

        def toggle_intro(e):
            if "intro" in expanded_blocks:
                expanded_blocks.remove("intro")
            else:
                expanded_blocks.add("intro")
            render()

        intro_data = data.get("intro_workout", {})

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Text(
                        "Вводная",
                        size=17, weight=ft.FontWeight.BOLD,
                        color=PRIMARY if intro_expanded else TEXT,
                        expand=True,
                    ),
                    ft.Icon(
                        ft.Icons.EXPAND_LESS if intro_expanded else ft.Icons.EXPAND_MORE,
                        color=PRIMARY, size=24,
                    ),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                padding=18,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=16,
                bgcolor=CARD_SOFT if intro_expanded else CARD,
                border=ft.border.all(2, PRIMARY if intro_expanded else BORDER),
                on_click=toggle_intro,
            )
        )

        # Если раскрыта — показываем редактор
        if intro_expanded:
            title_field = ft.TextField(
                value=intro_data.get("title", "Первая тренировка · Знакомство"),
                hint_text="Название тренировки",
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=13,
            )

            text_field = ft.TextField(
                value=intro_data.get("text", ""),
                hint_text="Текст тренировки",
                multiline=True,
                min_lines=5,
                max_lines=10,
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=13,
            )

            video_field = ft.TextField(
                value=intro_data.get("video_url", ""),
                hint_text="Ссылка на видео (https://...)",
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=13,
            )

            audio_field = ft.TextField(
                value=intro_data.get("audio_url", ""),
                hint_text="Ссылка на голосовое (https://...)",
                bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                text_size=13,
            )

            def submit_intro(e):
                t = title_field.value.strip()
                txt = text_field.value.strip()
                v = video_field.value.strip()
                a = audio_field.value.strip()

                if not txt:
                    snack = ft.SnackBar(ft.Text("Введите текст тренировки"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()
                    return

                ok = server_update_intro(txt, v, a, t)
                if ok:
                    snack = ft.SnackBar(ft.Text("Вводная тренировка сохранена"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()

                    new_data = server_get_data()
                    if new_data:
                        data.clear()
                        data.update(new_data)
                    render()
                else:
                    snack = ft.SnackBar(ft.Text("Ошибка: не удалось сохранить"))
                    page.overlay.append(snack)
                    snack.open = True
                    page.update()

            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text("Название:", size=13, color=TEXT_MUTED),
                        title_field,
                        ft.Container(height=8),
                        ft.Text("Текст тренировки:", size=13, color=TEXT_MUTED),
                        text_field,
                        ft.Container(height=8),
                        ft.Text("Ссылка на видео:", size=13, color=TEXT_MUTED),
                        video_field,
                        ft.Container(height=8),
                        ft.Text("Ссылка на голосовое:", size=13, color=TEXT_MUTED),
                        audio_field,
                        ft.Container(height=12),
                        ft.Button(
                            content=ft.Text("Сохранить", size=14, weight=ft.FontWeight.BOLD),
                            on_click=submit_intro,
                            style=ft.ButtonStyle(
                                bgcolor=PRIMARY, color=PRIMARY_FG,
                                shape=ft.RoundedRectangleBorder(radius=12),
                                padding=ft.padding.symmetric(vertical=12, horizontal=24),
                            ),
                        ),
                    ], spacing=6),
                    padding=16,
                    margin=ft.margin.only(left=40, right=20, top=2, bottom=8),
                    border_radius=12, bgcolor=CARD, border=ft.border.all(1, BORDER),
                )
            )

        # --- Бонус ---
        bonus_expanded = "bonus_group" in expanded_blocks

        def toggle_bonus(e):
            if "bonus_group" in expanded_blocks:
                expanded_blocks.remove("bonus_group")
            else:
                expanded_blocks.add("bonus_group")
            render()

        bonus_workouts = data.get("bonus_workouts", [])

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Text(
                        f"Бонус ({len(bonus_workouts)})",
                        size=17, weight=ft.FontWeight.BOLD,
                        color=PRIMARY if bonus_expanded else TEXT,
                        expand=True,
                    ),
                    ft.Icon(
                        ft.Icons.EXPAND_LESS if bonus_expanded else ft.Icons.EXPAND_MORE,
                        color=PRIMARY, size=24,
                    ),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                padding=18,
                margin=ft.margin.symmetric(horizontal=20, vertical=6),
                border_radius=16,
                bgcolor=CARD_SOFT if bonus_expanded else CARD,
                border=ft.border.all(2, PRIMARY if bonus_expanded else BORDER),
                on_click=toggle_bonus,
            )
        )

        if bonus_expanded:
            # Кнопка добавления
            def add_bonus(e):
                state["editing_bonus_id"] = 0
                state["show_bonus_form"] = True
                render()

            content_area.controls.append(
                ft.Container(
                    content=ft.Button(
                        content=ft.Text("+ Добавить бонусную тренировку", size=14, weight=ft.FontWeight.BOLD),
                        on_click=add_bonus,
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY, color=PRIMARY_FG,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=12, horizontal=18),
                        ),
                    ),
                    padding=ft.padding.only(left=40, right=20, top=8, bottom=8),
                )
            )

            # Форма
            show_form = state.get("show_bonus_form", False)
            editing_id = state.get("editing_bonus_id", 0)

            if show_form:
                current = None
                for bw in bonus_workouts:
                    if bw.get("id") == editing_id:
                        current = bw
                        break

                title_f = ft.TextField(
                    value=current.get("title", "") if current else "",
                    hint_text="Название (например: Табата на пресс)",
                    bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                    hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                    text_size=13,
                )
                text_f = ft.TextField(
                    value=current.get("text", "") if current else "",
                    hint_text="Текст тренировки",
                    multiline=True, min_lines=3, max_lines=8,
                    bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                    hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                    text_size=13,
                )
                video_f = ft.TextField(
                    value=current.get("video_url", "") if current else "",
                    hint_text="Ссылка на видео",
                    bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                    hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
                    text_size=13,
                )

                def save_bonus(e):
                    ok = server_save_bonus_workout(
                        editing_id,
                        title_f.value.strip(),
                        text_f.value.strip(),
                        video_f.value.strip(),
                        "",
                    )
                    if ok:
                        state["show_bonus_form"] = False
                        state["editing_bonus_id"] = 0
                        new_data = server_get_data()
                        if new_data:
                            data.clear()
                            data.update(new_data)
                        render()

                def cancel_bonus(e):
                    state["show_bonus_form"] = False
                    state["editing_bonus_id"] = 0
                    render()

                content_area.controls.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Text("Название:", size=13, color=TEXT_MUTED),
                            title_f,
                            ft.Container(height=6),
                            ft.Text("Текст:", size=13, color=TEXT_MUTED),
                            text_f,
                            ft.Container(height=6),
                            ft.Text("Видео:", size=13, color=TEXT_MUTED),
                            video_f,
                            ft.Container(height=10),
                            ft.Row([
                                ft.Button(
                                    content=ft.Text("Сохранить", size=13, weight=ft.FontWeight.BOLD),
                                    on_click=save_bonus,
                                    style=ft.ButtonStyle(bgcolor=PRIMARY, color=PRIMARY_FG, shape=ft.RoundedRectangleBorder(radius=10), padding=ft.padding.symmetric(vertical=10, horizontal=16)),
                                ),
                                ft.Button(
                                    content=ft.Text("Отмена", size=13),
                                    on_click=cancel_bonus,
                                    style=ft.ButtonStyle(bgcolor=CARD_SOFT, color=TEXT, shape=ft.RoundedRectangleBorder(radius=10), padding=ft.padding.symmetric(vertical=10, horizontal=16)),
                                ),
                            ], spacing=8),
                        ], spacing=4),
                        padding=16,
                        margin=ft.margin.only(left=40, right=20, top=4, bottom=8),
                        border_radius=12, bgcolor=CARD, border=ft.border.all(2, PRIMARY),
                    )
                )

            # Список бонусных тренировок
            for bw in bonus_workouts:
                bw_id = bw.get("id", 0)

                def make_edit(bid):
                    def handler(e):
                        state["editing_bonus_id"] = bid
                        state["show_bonus_form"] = True
                        render()
                    return handler

                def make_delete(bid):
                    def handler(e):
                        ok = server_delete_bonus_workout(bid)
                        if ok:
                            new_data = server_get_data()
                            if new_data:
                                data.clear()
                                data.update(new_data)
                            render()
                    return handler

                content_area.controls.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Column([
                                ft.Text(bw.get("title", "Без названия"), size=15, weight=ft.FontWeight.BOLD, color=TEXT),
                                ft.Text((bw.get("text", "")[:50] + "...") if len(bw.get("text", "")) > 50 else bw.get("text", ""), size=12, color=TEXT_MUTED),
                            ], spacing=2, expand=True),
                            ft.IconButton(ft.Icons.EDIT, icon_color=PRIMARY, icon_size=20, on_click=make_edit(bw_id), tooltip="Редактировать"),
                            ft.IconButton(ft.Icons.DELETE_OUTLINE, icon_color=DANGER, icon_size=20, on_click=make_delete(bw_id), tooltip="Удалить"),
                        ], spacing=6),
                        padding=14,
                        margin=ft.margin.only(left=40, right=20, top=2, bottom=2),
                        border_radius=12, bgcolor=CARD, border=ft.border.all(1, BORDER),
                    )
                )

        # Разделяем блоки на начинающих и продвинутых
        beginner_blocks = [b for b in blocks if b.get("level") == "beginner"]
        advanced_blocks = [b for b in blocks if b.get("level") == "advanced"]

        # «Начинающие» — один раскрывающийся блок
        beginner_expanded = "beginner_group" in expanded_blocks

        def toggle_beginner_group(e):
            if "beginner_group" in expanded_blocks:
                expanded_blocks.remove("beginner_group")
            else:
                expanded_blocks.add("beginner_group")
            render()

        if beginner_blocks:
            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Text(
                            "Начинающие (блоки 1–8)",
                            size=16, weight=ft.FontWeight.BOLD,
                            color=PRIMARY if beginner_expanded else TEXT,
                            expand=True,
                        ),
                        ft.Icon(
                            ft.Icons.EXPAND_LESS if beginner_expanded else ft.Icons.EXPAND_MORE,
                            color=PRIMARY, size=24,
                        ),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    padding=18,
                    margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=16,
                    bgcolor=CARD_SOFT if beginner_expanded else CARD,
                    border=ft.border.all(2, PRIMARY if beginner_expanded else BORDER),
                    on_click=toggle_beginner_group,
                )
            )

        if beginner_expanded:
            for block in beginner_blocks:
                block_id = block["id"]
                is_expanded = block_id in expanded_blocks

                def make_toggle(bid):
                    def toggle(e):
                        if bid in expanded_blocks:
                            expanded_blocks.remove(bid)
                        else:
                            expanded_blocks.add(bid)
                        render()
                    return toggle

                # Кнопка блока (без точки и без "Сделать текущим")
                content_area.controls.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Text(
                                block.get("title", f"Блок {block_id}"),
                                size=17, weight=ft.FontWeight.BOLD, color=TEXT,
                                expand=True,
                            ),
                            ft.Icon(
                                ft.Icons.EXPAND_LESS if is_expanded else ft.Icons.EXPAND_MORE,
                                color=PRIMARY, size=24,
                            ),
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                        padding=18,
                        margin=ft.margin.only(left=40, right=20, top=4, bottom=4),
                        border_radius=14,
                        bgcolor=CARD_SOFT if is_expanded else CARD,
                        border=ft.border.all(2, PRIMARY if is_expanded else BORDER),
                        on_click=make_toggle(block_id),
                    )
                )

                # Если блок раскрыт — показываем тренировки
                if is_expanded:
                    workouts_in_block = block.get("workouts", [])

                    if not workouts_in_block:
                        content_area.controls.append(
                            ft.Container(
                                content=ft.Text(
                                    "В этом блоке пока нет тренировок",
                                    size=13, color=TEXT_MUTED,
                                ),
                                padding=ft.padding.only(left=40, right=20, top=4, bottom=8),
                            )
                        )
                    else:
                        sorted_workouts = sorted(workouts_in_block, key=lambda x: x["number"])

                        for w in sorted_workouts:
                            text_short = w.get("text", "")[:60]
                            if len(w.get("text", "")) > 60:
                                text_short += "..."

                            def make_open_handler(block_id, workout_number):
                                def handler(e):
                                    state["new_workout_block"] = block_id
                                    state["new_workout_number"] = workout_number
                                    state["show_workout_form"] = True
                                    render()
                                return handler

                            content_area.controls.append(
                                ft.Container(
                                    content=ft.Column([
                                        ft.Text(
                                            f"Тренировка {w['number']}",
                                            size=15, weight=ft.FontWeight.BOLD, color=PRIMARY,
                                        ),
                                        ft.Text(
                                            text_short,
                                            size=13, color=TEXT_MUTED,
                                            max_lines=2,
                                            overflow=ft.TextOverflow.ELLIPSIS,
                                        ),
                                    ], spacing=4),
                                    padding=14,
                                    margin=ft.margin.only(left=40, right=20, top=2, bottom=2),
                                    border_radius=12, bgcolor=CARD, border=ft.border.all(1, BORDER),
                                    width=400,
                                    height=80,
                                    on_click=make_open_handler(block_id, w["number"]),
                                )
                            )
                    content_area.controls.append(ft.Container(height=8))           

        # «Продвинутые» — один раскрывающийся блок
        advanced_expanded = "advanced_group" in expanded_blocks

        def toggle_advanced_group(e):
            if "advanced_group" in expanded_blocks:
                expanded_blocks.remove("advanced_group")
            else:
                expanded_blocks.add("advanced_group")
            render()

        if advanced_blocks:
            content_area.controls.append(
                ft.Container(
                    content=ft.Row([
                        ft.Text(
                            "Продвинутые (блоки 9+)",
                            size=16, weight=ft.FontWeight.BOLD,
                            color=PRIMARY if advanced_expanded else TEXT,
                            expand=True,
                        ),
                        ft.Icon(
                            ft.Icons.EXPAND_LESS if advanced_expanded else ft.Icons.EXPAND_MORE,
                            color=PRIMARY, size=24,
                        ),
                    ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                    padding=18,
                    margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=16,
                    bgcolor=CARD_SOFT if advanced_expanded else CARD,
                    border=ft.border.all(2, PRIMARY if advanced_expanded else BORDER),
                    on_click=toggle_advanced_group,
                )
            )

        if advanced_expanded:
            for block in advanced_blocks:
                block_id = block["id"]
                is_expanded = block_id in expanded_blocks

                def make_toggle_adv(bid):
                    def toggle(e):
                        if bid in expanded_blocks:
                            expanded_blocks.remove(bid)
                        else:
                            expanded_blocks.add(bid)
                        render()
                    return toggle

                is_current = block.get("is_current", False)

                def make_set_current_adv(bid):
                    def handler(e):
                        ok = server_set_current_block(bid)
                        if ok:
                            new_data = server_get_data()
                            if new_data:
                                data.clear()
                                data.update(new_data)
                                blocks.clear()
                                blocks.extend(new_data.get("blocks", []))
                            snack = ft.SnackBar(ft.Text(f"Блок {bid} — текущий"))
                            page.overlay.append(snack)
                            snack.open = True
                            page.update()
                        render()
                    return handler

                content_area.controls.append(
                    ft.Container(
                        content=ft.Row([
                            ft.Container(
                                content=ft.Container(
                                    width=12, height=12, border_radius=6,
                                    bgcolor=MINT if is_current else BORDER,
                                ),
                                width=20,
                            ),
                            ft.Text(
                                block.get("title", f"Блок {block_id}"),
                                size=17, weight=ft.FontWeight.BOLD,
                                color=MINT if is_current else TEXT,
                                expand=True,
                            ),
                            ft.Icon(
                                ft.Icons.EXPAND_LESS if is_expanded else ft.Icons.EXPAND_MORE,
                                color=PRIMARY, size=24,
                            ),
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN, spacing=8),
                        padding=18,
                        margin=ft.margin.only(left=40, right=20, top=4, bottom=4),
                        border_radius=14,
                        bgcolor=CARD_SOFT if is_expanded else CARD,
                        border=ft.border.all(2, MINT if is_current else (PRIMARY if is_expanded else BORDER)),
                        on_click=make_toggle_adv(block_id),
                    )
                )

                if not is_current:
                    content_area.controls.append(
                        ft.Container(
                            content=ft.Row([
                                ft.Button(
                                    content=ft.Text("Сделать текущим", size=12, weight=ft.FontWeight.BOLD),
                                    on_click=make_set_current_adv(block_id),
                                    style=ft.ButtonStyle(
                                        bgcolor=CARD_SOFT, color=TEXT,
                                        shape=ft.RoundedRectangleBorder(radius=10),
                                        padding=ft.padding.symmetric(vertical=8, horizontal=14),
                                    ),
                                ),
                            ], alignment=ft.MainAxisAlignment.END),
                            padding=ft.padding.only(right=20, bottom=6),
                        )
                    )

                if is_expanded:
                    workouts_in_block = block.get("workouts", [])

                    if not workouts_in_block:
                        content_area.controls.append(
                            ft.Container(
                                content=ft.Text(
                                    "В этом блоке пока нет тренировок",
                                    size=13, color=TEXT_MUTED,
                                ),
                                padding=ft.padding.only(left=40, right=20, top=4, bottom=8),
                            )
                        )
                    else:
                        sorted_workouts = sorted(workouts_in_block, key=lambda x: x["number"])

                        for w in sorted_workouts:
                            text_short = w.get("text", "")[:60]
                            if len(w.get("text", "")) > 60:
                                text_short += "..."

                            def make_open_handler_adv(block_id, workout_number):
                                def handler(e):
                                    state["new_workout_block"] = block_id
                                    state["new_workout_number"] = workout_number
                                    state["show_workout_form"] = True
                                    render()
                                return handler

                            content_area.controls.append(
                                ft.Container(
                                    content=ft.Column([
                                        ft.Text(
                                            f"Тренировка {w['number']}",
                                            size=15, weight=ft.FontWeight.BOLD, color=PRIMARY,
                                        ),
                                        ft.Text(
                                            text_short,
                                            size=13, color=TEXT_MUTED,
                                            max_lines=2,
                                            overflow=ft.TextOverflow.ELLIPSIS,
                                        ),
                                    ], spacing=4),
                                    padding=14,
                                    margin=ft.margin.only(left=40, right=20, top=2, bottom=2),
                                    border_radius=12, bgcolor=CARD, border=ft.border.all(1, BORDER),
                                    width=400,
                                    height=80,
                                    on_click=make_open_handler_adv(block_id, w["number"]),
                                )
                            )
                    content_area.controls.append(ft.Container(height=8))

    def render_admin_intro():
        """Раздел админки: вводная тренировка."""
        intro_data = data.get("intro_workout", {})

        content_area.controls.append(
            ft.Container(
                content=ft.Text(
                    "Вводная тренировка",
                    size=20, weight=ft.FontWeight.BOLD, color=TEXT,
                ),
                padding=ft.padding.only(left=20, right=20, top=10, bottom=10),
            )
        )

        content_area.controls.append(
            ft.Container(
                content=ft.Text(
                    "Отредактируй текст, название и ссылку на видео. "
                    "Изменения увидят все новые пользователи.",
                    size=14, color=TEXT_MUTED,
                ),
                padding=ft.padding.symmetric(horizontal=20, vertical=5),
            )
        )

        title_field = ft.TextField(
            value=intro_data.get("title", "Первая тренировка · Знакомство"),
            hint_text="Название тренировки",
            bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
            hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
            text_size=13,
        )

        text_field = ft.TextField(
            value=intro_data.get("text", ""),
            hint_text="Текст тренировки",
            multiline=True,
            min_lines=6,
            max_lines=12,
            bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
            hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
            text_size=13,
        )

        video_field = ft.TextField(
            value=intro_data.get("video_url", ""),
            hint_text="Ссылка на видео (https://...)",
            bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
            hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12,
            text_size=13,
        )

        def submit(e):
            t = title_field.value.strip()
            txt = text_field.value.strip()
            v = video_field.value.strip()

            if not txt:
                snack = ft.SnackBar(ft.Text("Введите текст тренировки"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return

            ok = server_update_intro(txt, v, t)
            if ok:
                snack = ft.SnackBar(ft.Text("Вводная тренировка сохранена"))
                page.overlay.append(snack)
                snack.open = True
                page.update()

                # Перезагружаем данные
                new_data = server_get_data()
                if new_data:
                    data.clear()
                    data.update(new_data)
                render()
            else:
                snack = ft.SnackBar(ft.Text("Ошибка: не удалось сохранить"))
                page.overlay.append(snack)
                snack.open = True
                page.update()

        content_area.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Text("Название:", size=14, color=TEXT_MUTED),
                    title_field,
                    ft.Container(height=10),
                    ft.Text("Текст тренировки:", size=14, color=TEXT_MUTED),
                    text_field,
                    ft.Container(height=10),
                    ft.Text("Ссылка на видео:", size=14, color=TEXT_MUTED),
                    video_field,
                    ft.Container(height=15),
                    ft.Button(
                        content=ft.Text("Сохранить", size=15, weight=ft.FontWeight.BOLD),
                        on_click=submit,
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY, color=PRIMARY_FG,
                            shape=ft.RoundedRectangleBorder(radius=12),
                            padding=ft.padding.symmetric(vertical=14, horizontal=24),
                        ),
                    ),
                ], spacing=6),
                padding=20,
                margin=ft.margin.symmetric(horizontal=20, vertical=10),
                border_radius=16, bgcolor=CARD, border=ft.border.all(2, PRIMARY),
            )
        )
            
    # ---------- Админ ----------

    def render_admin_inventory():
        """Раздел админки: инвентарь."""
        content_area.controls.append(
            ft.Container(
                content=ft.Text("Инвентарь", size=20, weight=ft.FontWeight.BOLD, color=TEXT),
                padding=ft.padding.only(left=20, right=20, top=10, bottom=10),
            )
        )

        # --- Форма добавления ---
        show_add = state.get("show_inventory_add", False)

        def toggle_add(e):
            state["show_inventory_add"] = not show_add
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Button(
                    content=ft.Text("✕ Закрыть" if show_add else "+ Добавить инвентарь", size=15, weight=ft.FontWeight.BOLD),
                    on_click=toggle_add,
                    style=ft.ButtonStyle(
                        bgcolor=PRIMARY if not show_add else CARD_SOFT,
                        color=PRIMARY_FG if not show_add else TEXT,
                        shape=ft.RoundedRectangleBorder(radius=12),
                        padding=ft.padding.symmetric(vertical=14, horizontal=20),
                    ),
                ),
                padding=ft.padding.symmetric(horizontal=20, vertical=10),
            )
        )

        if show_add:
            label_field = ft.TextField(hint_text="Название", bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT, hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12, text_size=13)

            # Динамические поля ссылок
            add_links = state.get("new_inv_links", [{"url": "", "promo": ""}])

            def add_link_row(e):
                add_links.append({"url": "", "promo": ""})
                state["new_inv_links"] = add_links
                render()

            def remove_link_row(idx):
                if len(add_links) > 1:
                    del add_links[idx]
                    state["new_inv_links"] = add_links
                    render()

            def submit_add(e):
                label = label_field.value.strip()
                if not label:
                    return

                # Собираем ссылки из полей
                links_list = []
                for i, link in enumerate(add_links):
                    url_val = state.get(f"new_inv_url_{i}", "").strip()
                    promo_val = state.get(f"new_inv_promo_{i}", "").strip()
                    if url_val:
                        links_list.append({"url": url_val, "promo": promo_val})

                import re
                key = "inventory_" + re.sub(r'[^a-zа-я0-9]', '', label.lower())[:20]
                inventory_items.append({
                    "label": label,
                    "key": key,
                    "links": links_list,
                })
                inventory_data["items"] = inventory_items
                server_save_inventory(inventory_data)

                # Сбрасываем
                state["show_inventory_add"] = False
                state["new_inv_links"] = [{"url": "", "promo": ""}]
                for i in range(len(add_links)):
                    state.pop(f"new_inv_url_{i}", None)
                    state.pop(f"new_inv_promo_{i}", None)
                render()

            # Формируем поля
            link_fields = []
            for i, link in enumerate(add_links):
                def make_url_handler(idx):
                    def h(e):
                        state[f"new_inv_url_{idx}"] = e.control.value
                    return h

                def make_promo_handler(idx):
                    def h(e):
                        state[f"new_inv_promo_{idx}"] = e.control.value
                    return h

                url_f = ft.TextField(
                    value=state.get(f"new_inv_url_{i}", ""),
                    hint_text=f"Ссылка {i+1}",
                    on_change=make_url_handler(i),
                    bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                    hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12, text_size=13,
                    expand=True,
                )
                promo_f = ft.TextField(
                    value=state.get(f"new_inv_promo_{i}", ""),
                    hint_text="Промокод",
                    on_change=make_promo_handler(i),
                    bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                    hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12, text_size=13,
                    width=120,
                )

                link_fields.append(
                    ft.Row([
                        url_f,
                        promo_f,
                        ft.IconButton(
                            ft.Icons.CLOSE, icon_color=DANGER, icon_size=18,
                            on_click=lambda e, idx=i: remove_link_row(idx),
                        ) if len(add_links) > 1 else ft.Container(),
                    ], spacing=4)
                )

            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text("Название:", size=14, color=TEXT_MUTED),
                        label_field,
                        ft.Container(height=10),
                        ft.Text("Ссылки на покупку:", size=14, color=TEXT_MUTED),
                    ] + link_fields + [
                        ft.Container(height=6),
                        ft.TextButton(
                            content=ft.Text("+ Добавить ещё ссылку", size=13, color=PRIMARY),
                            on_click=add_link_row,
                        ),
                        ft.Container(height=15),
                        ft.Button(
                            content=ft.Text("Сохранить", size=15, weight=ft.FontWeight.BOLD),
                            on_click=submit_add,
                            style=ft.ButtonStyle(bgcolor=PRIMARY, color=PRIMARY_FG, shape=ft.RoundedRectangleBorder(radius=12), padding=ft.padding.symmetric(vertical=14, horizontal=24)),
                        ),
                    ], spacing=4),
                    padding=20,
                    margin=ft.margin.symmetric(horizontal=20, vertical=10),
                    border_radius=16, bgcolor=CARD, border=ft.border.all(2, PRIMARY),
                )
            )

        # --- Список инвентаря ---
        editing_inv_index = state.get("editing_inv_index", None)

        for i, inv in enumerate(inventory_items):
            is_editing = editing_inv_index == i

            if is_editing:
                label_e = ft.TextField(value=inv.get("label", ""), hint_text="Название", bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT, hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12, text_size=13)

                # Ссылки для редактирования
                edit_links = state.get(f"edit_links_{i}", inv.get("links", [{"url": "", "promo": ""}]))

                def add_edit_link_row(e, idx=i):
                    edit_links.append({"url": "", "promo": ""})
                    state[f"edit_links_{idx}"] = edit_links
                    render()

                def remove_edit_link_row(link_idx, idx=i):
                    if len(edit_links) > 1:
                        del edit_links[link_idx]
                        state[f"edit_links_{idx}"] = edit_links
                        render()

                # Создаём поля
                edit_link_fields = []
                for j, link in enumerate(edit_links):
                    def make_edit_url_handler(idx, lidx):
                        def h(e):
                            edit_links[lidx]["url"] = e.control.value
                        return h

                    def make_edit_promo_handler(idx, lidx):
                        def h(e):
                            edit_links[lidx]["promo"] = e.control.value
                        return h

                    url_ef = ft.TextField(
                        value=link.get("url", ""),
                        hint_text=f"Ссылка {j+1}",
                        on_change=make_edit_url_handler(i, j),
                        bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                        hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12, text_size=13,
                        expand=True,
                    )
                    promo_ef = ft.TextField(
                        value=link.get("promo", ""),
                        hint_text="Промокод",
                        on_change=make_edit_promo_handler(i, j),
                        bgcolor=CARD_SOFT, border_color=BORDER, color=TEXT,
                        hint_style=ft.TextStyle(color=TEXT_MUTED), border_radius=12, text_size=13,
                        width=120,
                    )

                    edit_link_fields.append(
                        ft.Row([
                            url_ef,
                            promo_ef,
                            ft.IconButton(
                                ft.Icons.CLOSE, icon_color=DANGER, icon_size=18,
                                on_click=lambda e, lidx=j: remove_edit_link_row(lidx),
                            ) if len(edit_links) > 1 else ft.Container(),
                        ], spacing=4)
                    )

                def make_save_edit(idx, lf):
                    def save(e):
                        # Сохраняем label
                        inventory_items[idx]["label"] = lf.value.strip()

                        # Собираем ссылки
                        links_list = []
                        for link in edit_links:
                            url_val = link.get("url", "").strip()
                            promo_val = link.get("promo", "").strip()
                            if url_val:
                                links_list.append({"url": url_val, "promo": promo_val})

                        inventory_items[idx]["links"] = links_list
                        inventory_data["items"] = inventory_items
                        server_save_inventory(inventory_data)
                        state["editing_inv_index"] = None
                        state.pop(f"edit_links_{idx}", None)
                        render()
                    return save

                def cancel_edit(e, idx=i):
                    state["editing_inv_index"] = None
                    state.pop(f"edit_links_{idx}", None)
                    render()

                content_area.controls.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Text("Название:", size=13, color=TEXT_MUTED),
                            label_e,
                            ft.Container(height=10),
                            ft.Text("Ссылки на покупку:", size=13, color=TEXT_MUTED),
                        ] + edit_link_fields + [
                            ft.Container(height=6),
                            ft.TextButton(
                                content=ft.Text("+ Добавить ещё ссылку", size=13, color=PRIMARY),
                                on_click=add_edit_link_row,
                            ),
                            ft.Container(height=10),
                            ft.Row([
                                ft.Button(
                                    content=ft.Text("Сохранить", size=13, weight=ft.FontWeight.BOLD),
                                    on_click=make_save_edit(i, label_e),
                                    style=ft.ButtonStyle(bgcolor=PRIMARY, color=PRIMARY_FG, shape=ft.RoundedRectangleBorder(radius=10), padding=ft.padding.symmetric(vertical=10, horizontal=16)),
                                ),
                                ft.Button(
                                    content=ft.Text("Отмена", size=13),
                                    on_click=cancel_edit,
                                    style=ft.ButtonStyle(bgcolor=CARD_SOFT, color=TEXT, shape=ft.RoundedRectangleBorder(radius=10), padding=ft.padding.symmetric(vertical=10, horizontal=16)),
                                ),
                            ], spacing=8),
                        ], spacing=4),
                        padding=16,
                        margin=ft.margin.symmetric(horizontal=20, vertical=6),
                        border_radius=14, bgcolor=CARD, border=ft.border.all(2, PRIMARY),
                    )
                )

                def make_save_edit(idx, lf, uf, pf):
                    def save(e):
                        inventory_items[idx]["label"] = lf.value.strip()
                        inventory_items[idx]["links"] = [{"url": uf.value.strip(), "promo": pf.value.strip()}]
                        inventory_data["items"] = inventory_items
                        server_save_inventory(inventory_data)
                        state["editing_inv_index"] = None
                        render()
                    return save

                def cancel_edit(e):
                    state["editing_inv_index"] = None
                    render()

            else:
                def make_delete(idx):
                    def delete(e):
                        del inventory_items[idx]
                        inventory_data["items"] = inventory_items
                        server_save_inventory(inventory_data)
                        render()
                    return delete

                def make_start_edit(idx):
                    def start(e):
                        state["editing_inv_index"] = idx
                        render()
                    return start

                content_area.controls.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Row([
                                ft.Text(inv.get("label", ""), size=16, weight=ft.FontWeight.BOLD, color=TEXT, expand=True),
                                ft.IconButton(ft.Icons.EDIT, icon_color=PRIMARY, icon_size=20, on_click=make_start_edit(i), tooltip="Редактировать"),
                                ft.IconButton(ft.Icons.DELETE_OUTLINE, icon_color=DANGER, icon_size=20, on_click=make_delete(i), tooltip="Удалить"),
                            ]),
                        ] + [
                            ft.Text(
                                f"{link.get('url', '')}" + (f" · промокод {link.get('promo')}" if link.get("promo") else ""),
                                size=12, color=TEXT_MUTED,
                            )
                            for link in inv.get("links", [])
                        ] if inv.get("links") else [
                            ft.Text("Нет ссылок", size=12, color=TEXT_MUTED)
                        ], spacing=4),
                        padding=16,
                        margin=ft.margin.symmetric(horizontal=20, vertical=6),
                        border_radius=14, bgcolor=CARD, border=ft.border.all(1, BORDER),
                    )
                )

    def render_admin():
        content_area.controls.clear()

        content_area.controls.append(
            ft.Container(content=ft.Text("Админ-панель", size=24, weight=ft.FontWeight.BOLD, color=TEXT), padding=ft.padding.only(left=20, right=20, top=20, bottom=10))
        )

        # Переключатель разделов админки
        admin_section = state.get("admin_section", "users")

        def switch_section(section):
            state["admin_section"] = section
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Button(
                        content=ft.Text("Ученицы", size=11, weight=ft.FontWeight.BOLD, no_wrap=True),
                        on_click=lambda e: switch_section("users"),
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY if admin_section == "users" else CARD_SOFT,
                            color=PRIMARY_FG if admin_section == "users" else TEXT,
                            shape=ft.RoundedRectangleBorder(radius=10),
                            padding=ft.padding.symmetric(vertical=8, horizontal=6),
                        ),
                        expand=True,
                    ),
                    ft.Button(
                        content=ft.Text("Упражнения", size=11, weight=ft.FontWeight.BOLD, no_wrap=True),
                        on_click=lambda e: switch_section("exercises"),
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY if admin_section == "exercises" else CARD_SOFT,
                            color=PRIMARY_FG if admin_section == "exercises" else TEXT,
                            shape=ft.RoundedRectangleBorder(radius=10),
                            padding=ft.padding.symmetric(vertical=8, horizontal=6),
                        ),
                        expand=True,
                    ),
                    ft.Button(
                        content=ft.Text("Тренировки", size=11, weight=ft.FontWeight.BOLD, no_wrap=True),
                        on_click=lambda e: switch_section("workouts"),
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY if admin_section == "workouts" else CARD_SOFT,
                            color=PRIMARY_FG if admin_section == "workouts" else TEXT,
                            shape=ft.RoundedRectangleBorder(radius=10),
                            padding=ft.padding.symmetric(vertical=8, horizontal=6),
                        ),
                        expand=True,
                    ),
                    ft.Button(
                        content=ft.Text("Инвентарь", size=11, weight=ft.FontWeight.BOLD, no_wrap=True),
                        on_click=lambda e: switch_section("inventory"),
                        style=ft.ButtonStyle(
                            bgcolor=PRIMARY if admin_section == "inventory" else CARD_SOFT,
                            color=PRIMARY_FG if admin_section == "inventory" else TEXT,
                            shape=ft.RoundedRectangleBorder(radius=10),
                            padding=ft.padding.symmetric(vertical=8, horizontal=6),
                        ),
                        expand=True,
                    ),
                ], spacing=6),
                padding=ft.padding.symmetric(horizontal=10, vertical=10),
            )
        )
        
        # --- Если выбрана вкладка "Упражнения" ---
        if admin_section == "exercises":
            render_admin_exercises()
            return

        # --- Если выбрана вкладка "Тренировки" ---
        if admin_section == "workouts":
            render_admin_workouts()
            return

        # --- Если выбрана вкладка "Инвентарь" ---
        if admin_section == "inventory":
            render_admin_inventory()
            return

        # --- Иначе: список учениц ---
        pending_users = [u for u in users if u.get("payment_request", {}) and u["payment_request"].get("status") == "pending"]

        if pending_users:
            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text(f"🔔 Заявок на оплату: {len(pending_users)}", size=16, weight=ft.FontWeight.BOLD, color=BLUSH),
                    ]),
                    padding=15, margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=14, bgcolor=CARD_SOFT, border=ft.border.all(1, BLUSH),
                )
            )

        # --- Заявки на смену уровня ---
        level_requests = [u for u in users if u.get("level_request")]
        if level_requests:
            content_area.controls.append(
                ft.Container(
                    content=ft.Column([
                        ft.Text(f"🔄 Заявок на смену уровня: {len(level_requests)}", size=16, weight=ft.FontWeight.BOLD, color=PRIMARY),
                    ]),
                    padding=15, margin=ft.margin.symmetric(horizontal=20, vertical=6),
                    border_radius=14, bgcolor=CARD_SOFT, border=ft.border.all(1, PRIMARY),
                )
            )

        for u in users:
            block = get_block(u.get("current_block"))
            workout_num = u.get("current_index", 0) + 1
            level_text = "Начинающий" if u.get("level") == "beginner" else "Продвинутый" if u.get("level") == "advanced" else "—"
            trained = trained_today(u)
            request = u.get("payment_request") or {}
            req_status = request.get("status")

            if u.get("is_active", True) and is_access_active(u):
                status_text = "Активна"
                status_color = MINT
            else:
                status_text = "Заблокирована"
                status_color = DANGER

            # Последний вес
            weights_list = u.get("weights", [])
            last_weight = weights_list[-1]["weight"] if weights_list else "—"

            # Последние замеры
            measures_list = u.get("measures", [])
            if measures_list:
                last_m = measures_list[-1]
                measures_text = f"Грудь: {last_m.get('chest', 0)} · Талия: {last_m.get('waist', 0)} · Руки: {last_m.get('arms', 0)} · Ноги: {last_m.get('legs', 0)}"
            else:
                measures_text = "—"

            # Цели
            goals_list = u.get("goals", [])
            goals_text = ", ".join(goals_list) if goals_list else "—"

            info_lines = [
                ft.Text(f"{u['first_name']} {u['last_name']}", size=16, weight=ft.FontWeight.BOLD, color=TEXT),
                ft.Text(f"Уровень: {level_text} · {status_text}", size=13, color=status_color),
                ft.Text(f"Блок: {block['title'] if block else '—'} · Тренировка {workout_num}", size=13, color=TEXT_MUTED),
                ft.Text(f"Сегодня: {'✅ тренировка выполнена' if trained else '— не отмечено'}", size=13, color=MINT if trained else TEXT_MUTED),
                ft.Text(f"Оплата до: {u.get('payment_due_date', '—')}", size=13, color=TEXT_MUTED),
                ft.Divider(color=BORDER),
                ft.Text("📋 Анкета:", size=13, weight=ft.FontWeight.BOLD, color=PRIMARY),
                ft.Text(f"Цели: {goals_text}", size=12, color=TEXT_MUTED),
                ft.Text(f"Частота: {u.get('frequency', '—')}", size=12, color=TEXT_MUTED),
                ft.Text(f"Активность: {u.get('activity', '—')}", size=12, color=TEXT_MUTED),
                ft.Text(f"Время: {u.get('time_pref', '—')}", size=12, color=TEXT_MUTED),
                ft.Text(f"Увлечения: {u.get('hobbies', '—') or '—'}", size=12, color=TEXT_MUTED),
                ft.Divider(color=BORDER),
                ft.Text("⚖️ Прогресс:", size=13, weight=ft.FontWeight.BOLD, color=PRIMARY),
                ft.Text(f"Последний вес: {last_weight} кг", size=12, color=TEXT_MUTED),
                ft.Text(f"Замеры: {measures_text}", size=12, color=TEXT_MUTED),
            ]

            # Заявка на смену уровня
            level_req = u.get("level_request")
            if level_req:
                req_to = "Продвинутый" if level_req.get("to") == "advanced" else "Начинающий"
                info_lines.append(
                    ft.Text(f"🔄 Заявка: перейти на «{req_to}»", size=13, color=PRIMARY, weight=ft.FontWeight.BOLD)
                )

            if req_status == "pending":
                info_lines.append(ft.Text("🔔 Заявка на оплату — ожидает подтверждения", size=13, color=BLUSH, weight=ft.FontWeight.BOLD))

            buttons = []

            if req_status == "pending":
                def approve(e, user=u):
                    now = datetime.now()
                    user["last_payment_date"] = now.strftime("%Y-%m-%d")
                    user["payment_due_date"] = (now + timedelta(days=30)).strftime("%Y-%m-%d")
                    user["is_active"] = True
                    user["payment_request"] = None
                    server_save_users(users_data)
                    render()

                def reject(e, user=u):
                    user["payment_request"] = None
                    server_save_users(users_data)
                    render()

                buttons.append(ft.Button(
                    content=ft.Text("Подтвердить оплату", size=13, weight=ft.FontWeight.BOLD),
                    on_click=approve,
                    style=ft.ButtonStyle(bgcolor=PRIMARY, color=PRIMARY_FG, shape=ft.RoundedRectangleBorder(radius=10)),
                ))
                buttons.append(ft.Button(
                    content=ft.Text("Отклонить", size=13, weight=ft.FontWeight.BOLD),
                    on_click=reject,
                    style=ft.ButtonStyle(bgcolor=CARD_SOFT, color=TEXT, shape=ft.RoundedRectangleBorder(radius=10)),
                ))

            if level_req:
                def approve_level(e, user=u):
                    req = user.get("level_request") or {}
                    to_level = req.get("to")
                    if to_level not in ("beginner", "advanced"):
                        user["level_request"] = None
                        server_save_users(users_data)
                        render()
                        return

                    user["level"] = to_level
                    user["current_block"] = get_block_for_level(to_level) 
                    user["current_index"] = 0
                    user["level_request"] = None
                    server_save_users(users_data)
                    render()

                def reject_level(e, user=u):
                    user["level_request"] = None
                    server_save_users(users_data)
                    render()

                buttons.append(ft.Button(
                    content=ft.Text("Принять смену уровня", size=13, weight=ft.FontWeight.BOLD),
                    on_click=approve_level,
                    style=ft.ButtonStyle(bgcolor=PRIMARY, color=PRIMARY_FG, shape=ft.RoundedRectangleBorder(radius=10)),
                ))
                buttons.append(ft.Button(
                    content=ft.Text("Отклонить смену", size=13, weight=ft.FontWeight.BOLD),
                    on_click=reject_level,
                    style=ft.ButtonStyle(bgcolor=CARD_SOFT, color=TEXT, shape=ft.RoundedRectangleBorder(radius=10)),
                ))

            def toggle_block(e, user=u):
                user["is_active"] = not user.get("is_active", True)
                server_save_users(users_data)
                render()

            buttons.append(ft.Button(
                content=ft.Text("Разблокировать" if not u.get("is_active", True) else "Заблокировать", size=13),
                on_click=toggle_block,
                style=ft.ButtonStyle(bgcolor=CARD_SOFT, color=TEXT, shape=ft.RoundedRectangleBorder(radius=10)),
            ))
            
            def delete_user(e, user=u):
                if user in users:
                    users.remove(user)
                if users_data.get("current_user") == user["id"]:
                    users_data["current_user"] = None
                server_save_users(users_data)
                render()

            buttons.append(ft.Button(
                content=ft.Text("Удалить", size=13, weight=ft.FontWeight.BOLD),
                on_click=delete_user,
                style=ft.ButtonStyle(bgcolor=CARD_SOFT, color=DANGER, shape=ft.RoundedRectangleBorder(radius=10)),
            ))            

            # Формируем subtitle для свёрнутого вида
            subtitle_parts = [f"{level_text} · {status_text}"]
            if level_req:
                req_to = "Продвинутый" if level_req.get("to") == "advanced" else "Начинающий"
                subtitle_parts.append(f"🔄 Заявка: {req_to}")
            if req_status == "pending":
                subtitle_parts.append("🔔 Оплата")
            subtitle_text = " · ".join(subtitle_parts)

            content_area.controls.append(
                ft.ExpansionTile(
                    title=ft.Text(
                        f"{u['first_name']} {u['last_name']}",
                        size=16, weight=ft.FontWeight.BOLD, color=TEXT,
                    ),
                    subtitle=ft.Text(
                        subtitle_text,
                        size=13, color=status_color,
                    ),
                    controls=[
                        ft.Container(
                            content=ft.Column(info_lines[2:] + [ft.Container(height=8), ft.Row(buttons, spacing=8, wrap=True)]),
                            padding=ft.padding.only(left=10, right=10, bottom=10),
                        )
                    ],
                    bgcolor=CARD,
                    collapsed_bgcolor=CARD,
                    text_color=TEXT,
                    collapsed_text_color=TEXT,
                    tile_padding=ft.padding.symmetric(horizontal=20, vertical=8),
                    controls_padding=ft.padding.symmetric(horizontal=10, vertical=6),
                )
            )

        # --- Кнопка выхода из админки ---
        def admin_logout(e):
            users_data["current_user"] = None
            server_save_users(users_data)
            state["is_admin"] = False
            state["user"] = None
            state["logged_in"] = False
            state["tab"] = "home"
            state["screen"] = "auto"
            state["admin_section"] = "users"
            render()

        content_area.controls.append(
            ft.Container(
                content=ft.TextButton(
                    content=ft.Text("← Выйти из админки", size=14, color=BLUSH),
                    on_click=admin_logout,
                ),
                padding=ft.padding.only(left=20, right=20, top=10, bottom=20),
            )
        )

    # ---------- Рендер ----------

    def render():
        current_screen = state.get("screen", "auto")
        current_tab = state.get("tab", "home")
        prev_screen = state.get("_prev_screen")
        prev_tab = state.get("_prev_tab")

        screen_changed = (current_screen != prev_screen) or (current_tab != prev_tab)
        force_scroll = state.get("force_scroll", False)

        if state.get("is_admin"):
            render_admin()
            nav_area.content = ft.Container()
            page.update()
            return

        user = state["user"]
        if user is None:
            render_registration()
            nav_area.content = ft.Container()
            page.update()
            return

        screen = state.get("screen", "auto")

        if screen == "warmup":
            render_warmup(user)
        elif screen == "questions":
            render_questions(user)
        elif screen == "recommendations":
            render_recommendations(user)
        elif screen == "inventory":
            render_inventory(user)
        elif screen == "onboarding":
            render_onboarding(user)
        elif screen == "welcome":
            render_welcome(user)
        elif screen == "intro":
            render_intro(user)
        elif screen == "level_question":
            render_level_question(user)
        elif screen == "bonus_stretch":              # ← добавили
            render_bonus_stretch(user)               # ← добавили
        elif screen == "bonus_view":                 # ← добавили
            render_bonus_view(user)                  # ← добавили
        elif screen == "rating":
            render_rating(user)    
        elif screen == "weight":
            render_weight(user)            
        elif screen == "calculator":
            render_calculator(user)   
        elif screen == "theory_item":
            render_theory_item(user)            
        elif screen == "profile":
            render_profile(user)    
        elif screen == "missed":
            render_missed_workouts(user)            
        elif screen == "measures":
            render_measures(user)   
        elif screen == "level_change":
            render_level_change(user)            
        elif screen == "photos":
            render_photos(user)     
        elif screen == "video_view":
            render_video_view(user)            
        elif screen == "block_detail":
            render_block_detail(user)
        else:
            if state["tab"] == "home":
                render_home(user)
            elif state["tab"] == "workouts":
                render_workouts_tab(user)
            elif state["tab"] == "bonus":
                render_bonus_tab(user)                
            elif state["tab"] == "chat":
                render_chat_tab(user)
            elif state["tab"] == "theory":
                render_theory_tab(user)

        # Обновляем навигацию
        show_nav = (
            state.get("logged_in", False)
            and not state.get("is_admin")
            and screen == "auto"
        )

        if show_nav:
            page.bottom_appbar = ft.BottomAppBar(
                bgcolor=CARD,
                content=ft.Row([
                    nav_button("Главная", ft.Icons.HOME_ROUNDED, "home"),
                    nav_button("Тренировки", ft.Icons.PLAY_CIRCLE_OUTLINE, "workouts"),
                    nav_button("Бонус", ft.Icons.STAR_OUTLINE, "bonus"),
                    nav_button("Чат", ft.Icons.CHAT_BUBBLE_OUTLINE, "chat"),
                    nav_button("Теория", ft.Icons.MENU_BOOK, "theory"),
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            )
        else:
            page.bottom_appbar = None

        page.update()

        if screen_changed or force_scroll:
            try:
                page.scroll_to(offset=0)
            except Exception as e:
                print(f"[SCROLL PAGE ERROR] {e}")
            state["_prev_screen"] = current_screen
            state["_prev_tab"] = current_tab
            state["force_scroll"] = False

    current_id = users_data.get("current_user")
    current_user = None
    if current_id is not None:
        for u in users:
            if u["id"] == current_id:
                current_user = u
                break
    state["user"] = current_user

    # Автологин: если пользователь уже прошёл вводную — сразу на Главную
    if current_user is not None:
        state["logged_in"] = True
        state["tab"] = "home"
        if current_user.get("intro_done"):
            state["screen"] = "auto"
        else:
            state["screen"] = "welcome"
    else:
        state["screen"] = "auto"


    page.add(
        ft.Stack([
            ft.Image(
                src=f"{ASSETS_PREFIX}images/background.jpg",
                fit=ft.ImageFit.COVER,
                opacity=0.15,
                expand=True,
            ),
            ft.Container(
                content=content_area,
                expand=True,
                padding=ft.padding.only(bottom=10),
            ),
        ], expand=True)
    )
    render()


ft.app(target=main)