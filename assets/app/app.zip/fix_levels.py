import json

with open("data.json", "r", encoding="utf-8") as f:
    data = json.load(f)

for block in data.get("blocks", []):
    if 1 <= block["id"] <= 8:
        block["level"] = "beginner"
    else:
        block["level"] = "advanced"

with open("data.json", "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

print("Готово! Уровни проставлены.")